/* 3D renderer (Three.js): extruded map, animated soldiers with visible guns, effects, fog-of-war overlay, storm, hub showroom. World unit = 1 tile (32 sim px). */
(()=>{
const T=THREE,TAU=Math.PI*2,SC=32;
let renderer,canvas,fx,fctx,W=0,H=0,dpr=1,ok=false,qual={dpr:1.5,shadows:false,aa:true};
let scene,camera,sun,hemi,mapGrp,entGrp,fxGrp;
let hub={scene:null,camera:null,char:null,key:'',spin:0,drag:false,t:0,on:false,parts:null,wid:'rifle',tryOn:null,opId:'',lk:null};
const cam={x:0,z:0,snap:true};
const ents=new Map(),dying=[],pk=new Map();
const P={wall:null,cap:null,cont:null,crate:null,trunk:null,leaf:null,water:null};
let storm=null,nextRing=null,zoneMesh=null,groundTex=null,mapTheme='neon';
const tmp=new T.Vector3(),tmp2=new T.Vector3(),ray=new T.Raycaster(),plane=new T.Plane(new T.Vector3(0,1,0),-.55);
const hash=(x,y)=>((x*73856093)^(y*19349663))>>>0;
function rng(seed){let s=seed>>>0||1;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
const QUAL={low:{dpr:1,shadows:false,aa:false},med:{dpr:1.5,shadows:false,aa:true},high:{dpr:2,shadows:true,aa:true}};
const glowTex=(()=>{let t=null;return()=>{if(t)return t;const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d'),g=x.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.35,'rgba(255,255,255,.55)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);t=new T.CanvasTexture(c);return t;};})();
const dotTex=(()=>{let t=null;return()=>{if(t)return t;const c=document.createElement('canvas');c.width=c.height=32;const x=c.getContext('2d'),g=x.createRadialGradient(16,16,0,16,16,16);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.6,'rgba(255,255,255,.8)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,32,32);t=new T.CanvasTexture(c);return t;};})();
function canvasTex(w,h,draw,rep){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=4;if(rep)t.repeat.set(rep[0],rep[1]);return t;}
const PAL={
  neon:{floor:'#16264a',grid:'rgba(80,150,255,.22)',water:'#07263a',wall:'#31497a',cap:'#4f6fae',edge:'#19e6ff',fog:'#06101e',sky:'#07101f'},
  dock:{floor:'#18292f',grid:'rgba(120,200,255,.10)',water:'#06293a',wall:'#46556c',cap:'#6b7f9c',edge:'#ff9d1a',fog:'#07131a',sky:'#07131a'},
  city:{floor:'#201f36',grid:'rgba(200,160,255,.10)',water:'#101a30',wall:'#46385f',cap:'#6b5a8c',edge:'#c9a7ff',fog:'#0b0914',sky:'#0b0914'},
  bridge:{floor:'#14263a',grid:'rgba(143,240,195,.10)',water:'#052a3d',wall:'#3a4f68',cap:'#5d7ba0',edge:'#8ff0c3',fog:'#06111a',sky:'#06111a'},
  open:{floor:'#4a5a34',grid:'rgba(0,0,0,0)',water:'#0b4a6b',wall:'#9a8570',cap:'#b8a088',edge:'#ffb02e',fog:'#7d93b5',sky:'#5f82b8'}};
/* ================= init ================= */
R3.init=()=>{
  canvas=$('#gl');fx=$('#fx');fctx=fx.getContext('2d');
  try{renderer=new T.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance',alpha:false});}catch(e){try{renderer=new T.WebGLRenderer({canvas,antialias:false});}catch(e2){renderer=null;}}
  if(!renderer){ok=false;return false;}
  ok=true;renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;
  scene=new T.Scene();scene.background=new T.Color('#05070d');scene.fog=new T.Fog('#05070d',26,70);
  camera=new T.PerspectiveCamera(45,1,.1,200);
  hemi=new T.HemisphereLight('#8aa8ff','#141018',.95);scene.add(hemi);
  sun=new T.DirectionalLight('#cfe0ff',1.15);sun.position.set(-8,16,9);scene.add(sun,sun.target);
  mapGrp=new T.Group();entGrp=new T.Group();fxGrp=new T.Group();scene.add(mapGrp,entGrp,fxGrp);
  initFx();scorchTex=puffTex('scorch');fireTex=puffTex('fire');smokeTex=puffTex('smoke');boomLight=new T.PointLight('#ff8a3a',0,14,1.6);scene.add(boomLight);buildHub();R3.setQuality(S.quality);R3.resize();addEventListener('resize',R3.resize);
  canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();UI.toast&&UI.toast('Graphics were interrupted. Reload the page.','bad');});
  return true;
};
R3.ok=()=>ok;
R3.setQuality=q=>{
  let k=q;if(k==='auto'){const touch=matchMedia('(pointer:coarse)').matches;k=touch?(Math.min(screen.width,screen.height)<500?'low':'med'):'high';if(window.__lowfps)k='med';}
  qual=Object.assign({},QUAL[k]||QUAL.med);if(!S.shadows)qual.shadows=false;
  if(!renderer)return;renderer.shadowMap.enabled=qual.shadows;renderer.shadowMap.type=T.PCFSoftShadowMap;sun.castShadow=qual.shadows;
  if(qual.shadows){sun.shadow.mapSize.set(1024,1024);const c=sun.shadow.camera;c.left=-14;c.right=14;c.top=14;c.bottom=-14;c.near=1;c.far=50;sun.shadow.bias=-.0004;}
  scene.traverse(o=>{if(o.isMesh&&o.material)o.material.needsUpdate=true;});
  R3.resize();
};
R3._dbg=()=>({scene,camera,renderer,fxGrp,entGrp});
R3.resize=()=>{
  if(!renderer)return;W=innerWidth;H=innerHeight;dpr=Math.min(window.devicePixelRatio||1,qual.dpr);
  renderer.setPixelRatio(dpr);renderer.setSize(W,H,false);canvas.style.width=W+'px';canvas.style.height=H+'px';
  fx.width=W;fx.height=H;camera.aspect=W/H;camera.updateProjectionMatrix();
  hub.camera.aspect=W/H;hub.camera.updateProjectionMatrix();placeHubChar();
};
/* adaptive quality: if the average frame is slow for a while, step down once */
let slow=0,fcount=0,facc=0;
function watchPerf(dt){if(dt>.2)return;facc+=dt;fcount++;if(fcount>=90){const avg=facc/fcount;fcount=0;facc=0;
  if(avg>.034&&S.quality==='auto'&&!window.__lowfps){slow++;if(slow>=2){window.__lowfps=true;qual=Object.assign({},QUAL.low);renderer.shadowMap.enabled=false;sun.castShadow=false;R3.resize();}}else slow=0;}}
/* ================= map ================= */
function disposeGrp(g){g.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.material){const ms=Array.isArray(o.material)?o.material:[o.material];ms.forEach(m=>{if(m.map&&m.map!==groundTex)m.map.dispose();m.dispose();});}});while(g.children.length)g.remove(g.children[0]);}
function paintGround(m,theme,ppt){
  const pal=PAL[theme]||PAL.neon,c=document.createElement('canvas');c.width=m.w*ppt;c.height=m.h*ppt;const x=c.getContext('2d'),rows=m.rows,R=rng(11);
  x.fillStyle=pal.floor;x.fillRect(0,0,c.width,c.height);
  const at=(tx,ty)=>(tx<0||ty<0||tx>=m.w||ty>=m.h)?'#':rows[ty][tx];
  const indoor=(tx,ty)=>{if(theme!=='open')return false;let n=0;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){for(let k=1;k<=9;k++){const ch=at(tx+dx*k,ty+dy*k);if(ch==='#'){n++;break;}}}return n===4;};
  for(let ty=0;ty<m.h;ty++)for(let tx=0;tx<m.w;tx++){
    const ch=rows[ty][tx],px=tx*ppt,py=ty*ppt,h=hash(tx,ty);
    if(ch==='~'){const g=x.createLinearGradient(px,py,px,py+ppt);g.addColorStop(0,pal.water);g.addColorStop(1,'#041a28');x.fillStyle=g;x.fillRect(px,py,ppt,ppt);continue;}
    if(ch==='#')continue;
    if(theme==='open'){
      const inn=indoor(tx,ty);
      if(inn){x.fillStyle=(tx+ty)&1?'#2b2722':'#262320';x.fillRect(px,py,ppt,ppt);}
      else{const v=h%5;x.fillStyle=['#1a2418','#1c2719','#18211a','#1f2a1b','#182016'][v];x.fillRect(px,py,ppt,ppt);if(h%9===0){x.fillStyle='rgba(120,160,70,.12)';x.fillRect(px+2,py+3,ppt*.5,ppt*.3);}if(h%13===0){x.fillStyle='rgba(0,0,0,.18)';x.fillRect(px+ppt*.3,py+ppt*.4,ppt*.35,ppt*.25);}}
    }else{
      const v=(h%7)*1.6;x.fillStyle=`rgb(${Math.min(255,22+v)},${Math.min(255,36+v)},${Math.min(255,66+v*1.4)})`;x.fillRect(px,py,ppt,ppt);
      x.strokeStyle=pal.grid;x.lineWidth=1;x.strokeRect(px+.5,py+.5,ppt-1,ppt-1);
      if(h%17===0){x.fillStyle='rgba(255,255,255,.04)';x.fillRect(px+ppt*.2,py+ppt*.45,ppt*.6,2);}
    }
    if(ch==='A'||ch==='B'){x.fillStyle=ch==='A'?'rgba(25,230,255,.16)':'rgba(255,157,26,.16)';x.fillRect(px,py,ppt,ppt);x.strokeStyle=ch==='A'?'rgba(25,230,255,.5)':'rgba(255,157,26,.5)';x.strokeRect(px+2,py+2,ppt-4,ppt-4);}
    if(ch==='Z'){x.fillStyle='rgba(255,255,255,.1)';x.beginPath();x.arc(px+ppt/2,py+ppt/2,ppt*.32,0,7);x.fill();}
    if('hawc'.includes(ch)){x.fillStyle='rgba(255,255,255,.07)';x.beginPath();x.arc(px+ppt/2,py+ppt/2,ppt*.4,0,7);x.fill();}
    /* soft darkening next to walls */
    if(at(tx,ty-1)==='#'||at(tx,ty-1)==='X'){const g=x.createLinearGradient(px,py,px,py+ppt*.5);g.addColorStop(0,'rgba(0,0,0,.4)');g.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=g;x.fillRect(px,py,ppt,ppt*.5);}
  }
  const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;t.anisotropy=8;t.minFilter=T.LinearMipmapLinearFilter;return t;
}
const facadeTex=(base,edge)=>canvasTex(128,128,(x,w)=>{
  x.fillStyle=base;x.fillRect(0,0,w,w);x.fillStyle='rgba(0,0,0,.18)';x.fillRect(0,w-14,w,14);
  const R=rng(5);for(let i=0;i<2;i++)for(let j=0;j<2;j++){const lit=R()<.45;x.fillStyle=lit?'rgba(255,214,130,.9)':'rgba(10,16,28,.8)';x.fillRect(16+i*54,22+j*46,36,26);if(lit){x.fillStyle='rgba(255,255,255,.35)';x.fillRect(16+i*54,22+j*46,36,5);}}
  x.fillStyle=edge;x.globalAlpha=.55;x.fillRect(0,0,w,4);x.globalAlpha=1;});
const crateTex=()=>canvasTex(64,64,(x,w)=>{x.fillStyle='#7a6842';x.fillRect(0,0,w,w);x.strokeStyle='#e0b13a';x.lineWidth=6;x.beginPath();for(let i=-w;i<w*2;i+=16){x.moveTo(i,w);x.lineTo(i+w,0);}x.stroke();x.strokeStyle='rgba(0,0,0,.6)';x.lineWidth=4;x.strokeRect(2,2,w-4,w-4);});
const contTex=()=>canvasTex(64,64,(x,w)=>{x.fillStyle='#fff';x.fillRect(0,0,w,w);x.fillStyle='rgba(0,0,0,.28)';for(let i=3;i<w;i+=6)x.fillRect(i,0,2.5,w);x.fillStyle='rgba(255,255,255,.4)';x.fillRect(0,0,w,3);});
R3.buildMap=()=>{
  if(!ok)return;
  disposeGrp(mapGrp);disposeGrp(fxGrp);for(const e of ents.values()){entGrp.remove(e.C.root);e.C.dispose();}ents.clear();dying.length=0;pk.clear();disposeGrp(entGrp);vehEnts.clear();projEnts.clear();tagEnts.clear();decals.length=0;fxs.length=0;tracers.length=0;flashes.length=0;rings.length=0;CS.snap=true;CS.zv=null;vm&&(vm.dispose(),vm=null);vmKey='';
  const m=G.map,theme=G.mapDef.theme||'neon',pal=PAL[theme]||PAL.neon;mapTheme=theme;
  scene.background=new T.Color(pal.sky);scene.fog.color.set(pal.fog);
  hemi.color.set(theme==='open'?'#9fb6ff':'#8aa8ff');hemi.intensity=theme==='open'?1.5:1.1;sun.intensity=theme==='open'?2.1:1.4;if(theme==='open')sun.color.set('#ffe2b0');
  const ppt=Math.min(32,Math.floor(2048/Math.max(m.w,m.h)));
  groundTex=paintGround(m,theme,ppt);
  const gp=new T.Mesh(new T.PlaneGeometry(m.w,m.h),new T.MeshStandardMaterial({map:groundTex,roughness:.92,metalness:.02}));
  gp.rotation.x=-Math.PI/2;gp.position.set(m.w/2,0,m.h/2);gp.receiveShadow=true;mapGrp.add(gp);groundMesh=gp;
  /* outer void so the world doesn't look like a floating rectangle */
  const vp=new T.Mesh(new T.PlaneGeometry(m.w*4,m.h*4),new T.MeshBasicMaterial({color:pal.sky}));vp.rotation.x=-Math.PI/2;vp.position.set(m.w/2,-.08,m.h/2);mapGrp.add(vp);
  const rows=m.rows,list={w:[],b:[],x:[],c:[],t:[],wa:[]};
  for(let ty=0;ty<m.h;ty++)for(let tx=0;tx<m.w;tx++){const ch=rows[ty][tx],border=tx===0||ty===0||tx===m.w-1||ty===m.h-1;
    if(ch==='#')(border?list.b:list.w).push([tx,ty]);else if(ch==='X')(theme==='open'?list.t:list.c).push([tx,ty]);else if(ch==='x')list.x.push([tx,ty]);else if(ch==='~')list.wa.push([tx,ty]);}
  const mk=(geo,mat,arr,place,color)=>{if(!arr.length)return null;const im=new T.InstancedMesh(geo,mat,arr.length),M4=new T.Matrix4(),col=new T.Color();
    arr.forEach(([tx,ty],i)=>{place(M4,tx,ty,hash(tx,ty));im.setMatrixAt(i,M4);if(color){color(col,hash(tx,ty));im.setColorAt(i,col);}});
    im.instanceMatrix.needsUpdate=true;if(im.instanceColor)im.instanceColor.needsUpdate=true;im.castShadow=qual.shadows;im.receiveShadow=true;mapGrp.add(im);return im;};
  const WH=theme==='open'?1.35:1.5;
  const wallMat=new T.MeshStandardMaterial({map:facadeTex(pal.wall,pal.edge),roughness:.85,metalness:.05});
  const BOX=new T.BoxGeometry(1,1,1);
  mk(BOX,wallMat,list.w,(M4,tx,ty,h)=>{const hh=WH+(h%5)*.04;M4.compose(new T.Vector3(tx+.5,hh/2,ty+.5),new T.Quaternion(),new T.Vector3(1,hh,1));},(c,h)=>c.setScalar(.82+(h%9)*.03));
  mk(BOX,new T.MeshStandardMaterial({color:pal.cap,roughness:.6,metalness:.1,emissive:new T.Color(pal.edge),emissiveIntensity:.08}),list.w,(M4,tx,ty,h)=>{const hh=WH+(h%5)*.04;M4.compose(new T.Vector3(tx+.5,hh+.04,ty+.5),new T.Quaternion(),new T.Vector3(1.02,.08,1.02));});
  mk(BOX,new T.MeshStandardMaterial({color:'#1b2740',roughness:.9,emissive:new T.Color('#16223a'),emissiveIntensity:.6}),list.b,(M4,tx,ty,h)=>{const hh=2.6+(h%7)*.3;M4.compose(new T.Vector3(tx+.5,hh/2,ty+.5),new T.Quaternion(),new T.Vector3(1,hh,1));});
  mk(BOX,new T.MeshStandardMaterial({map:contTex(),roughness:.55,metalness:.35}),list.c,(M4,tx,ty,h)=>{M4.compose(new T.Vector3(tx+.5,.55,ty+.5),new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),(h%4)*.02),new T.Vector3(.98,1.1,.98));},(c,h)=>c.set(['#c4562a','#2a77b3','#3b9a5c','#c19a2e','#8a8f99'][h%5]));
  mk(BOX,new T.MeshStandardMaterial({map:crateTex(),roughness:.8}),list.x,(M4,tx,ty,h)=>{M4.compose(new T.Vector3(tx+.5,.27,ty+.5),new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),((h%7)-3)*.04),new T.Vector3(.92,.54,.92));},(c,h)=>c.setScalar(.8+(h%5)*.07));
  if(list.t.length){
    mk(new T.CylinderGeometry(.09,.13,1,7),new T.MeshStandardMaterial({color:'#4a3322',roughness:.9}),list.t,(M4,tx,ty,h)=>{M4.compose(new T.Vector3(tx+.5,.5,ty+.5),new T.Quaternion(),new T.Vector3(1,1,1));});
    mk(new T.IcosahedronGeometry(.55,1),new T.MeshStandardMaterial({color:'#2f6b32',roughness:.9,flatShading:true}),list.t,(M4,tx,ty,h)=>{const s=.85+(h%5)*.1;M4.compose(new T.Vector3(tx+.5,1.15+(h%3)*.05,ty+.5),new T.Quaternion(),new T.Vector3(s,s*.95,s));},(c,h)=>c.setHSL(.27+((h%7)-3)*.01,.45,.22+(h%5)*.02));
  }
  if(list.wa.length){
    P.water=new T.MeshStandardMaterial({color:'#0b4766',transparent:true,opacity:.62,roughness:.15,metalness:.4,emissive:new T.Color('#0a3550'),emissiveIntensity:.5});
    const wm=new T.InstancedMesh(new T.PlaneGeometry(1,1),P.water,list.wa.length),M4=new T.Matrix4(),q=new T.Quaternion().setFromAxisAngle(new T.Vector3(1,0,0),-Math.PI/2);
    list.wa.forEach(([tx,ty],i)=>{M4.compose(new T.Vector3(tx+.5,.02,ty+.5),q,new T.Vector3(1,1,1));wm.setMatrixAt(i,M4);});wm.instanceMatrix.needsUpdate=true;mapGrp.add(wm);
  }
  /* neon edge strips on arena boundary for atmosphere */
  const spawnLights=[];if(theme!=='open'){for(const [ch,col] of [['A',pal.edge],['B','#ff9d1a']]){let n=0;m.rows.forEach((r,y)=>{for(let x=0;x<m.w;x++)if(r[x]===ch&&n++%3===0)spawnLights.push([x,y,col]);});}}
  const spr=new T.SpriteMaterial({map:glowTex(),color:'#ffffff',blending:T.AdditiveBlending,depthWrite:false,transparent:true,opacity:.5});
  {const pg=new T.PlaneGeometry(2.6,2.6);pg.rotateX(-Math.PI/2);const pm=new T.MeshBasicMaterial({map:glowTex(),color:'#ffffff',blending:T.AdditiveBlending,depthWrite:false,transparent:true,opacity:.4});for(const [x,y,col] of spawnLights){const s=new T.Mesh(pg,pm.clone());s.material.color.set(col);s.position.set(x+.5,.04,y+.5);mapGrp.add(s);}}
  /* pickups */
  for(const k of G.pickups)buildPickup(k);
  /* storm + zone */
  if(G.map.br){
    const sm=new T.ShaderMaterial({uniforms:{uTime:{value:0}},transparent:true,side:T.DoubleSide,depthWrite:false,blending:T.AdditiveBlending,fog:false,
      vertexShader:'varying vec3 vP;void main(){vP=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
      fragmentShader:'varying vec3 vP;uniform float uTime;float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1.,0.)),f.x),mix(h(i+vec2(0.,1.)),h(i+vec2(1.,1.)),f.x),f.y);}void main(){float ang=atan(vP.z,vP.x),y=(vP.y+6.)/12.;float bands=n(vec2(ang*9.+uTime*.6,y*6.-uTime*1.4))*.7+n(vec2(ang*23.-uTime*.4,y*14.))*.3;float edge=pow(1.-y,1.6),core=smoothstep(.0,.16,1.-y);vec3 col=mix(vec3(.1,.45,1.),vec3(.6,.92,1.),bands);float a=(edge*(.3+bands*.9)+core*.5)*.8;gl_FragColor=vec4(col*a*1.5,a);}'});
    storm=new T.Mesh(new T.CylinderGeometry(1,1,12,96,1,true),sm);storm.position.y=6;storm.visible=false;fxGrp.add(storm);
    nextRing=new T.Mesh(new T.RingGeometry(.985,1,96),new T.MeshBasicMaterial({color:'#9fd0ff',transparent:true,opacity:.7,side:T.DoubleSide,depthWrite:false,fog:false}));nextRing.rotation.x=-Math.PI/2;nextRing.position.y=.06;nextRing.visible=false;fxGrp.add(nextRing);
  }else{storm=null;nextRing=null;}
  if(modeType()==='zone'||m.zones.length){
    zoneMesh=new T.Group();const mat=new T.MeshBasicMaterial({color:'#ffffff',transparent:true,opacity:.14,depthWrite:false,side:T.DoubleSide}),rg=new T.MeshBasicMaterial({color:'#ffffff',transparent:true,opacity:.9,side:T.DoubleSide,depthWrite:false});
    const disc=new T.Mesh(new T.CircleGeometry(1,48),mat),ring=new T.Mesh(new T.RingGeometry(.96,1,64),rg);disc.rotation.x=ring.rotation.x=-Math.PI/2;disc.position.y=.04;ring.position.y=.05;zoneMesh.add(disc,ring);zoneMesh.visible=false;fxGrp.add(zoneMesh);zoneMesh.userData={mat,rg};
  }else zoneMesh=null;
  cam.snap=true;
};
/* ---------- pickups ---------- */
function buildPickup(k){
  const g=new T.Group(),col=k.type==='h'?'#ff4d6d':k.type==='a'?'#19e6ff':k.type==='w'?'#ffd166':'#c9a7ff';
  const base=new T.Mesh(new T.CylinderGeometry(.36,.4,.05,20),new T.MeshStandardMaterial({color:'#0b1220',emissive:new T.Color(col),emissiveIntensity:.5}));base.position.y=.03;g.add(base);
  const item=new T.Group();item.position.y=.5;g.add(item);
  const em=c=>new T.MeshStandardMaterial({color:c,emissive:new T.Color(c),emissiveIntensity:.7,roughness:.4});
  if(k.type==='h'){const a=new T.Mesh(new T.BoxGeometry(.4,.13,.13),em('#ff4d6d')),b=new T.Mesh(new T.BoxGeometry(.13,.13,.4),em('#ff4d6d'));const cs=new T.Mesh(new T.BoxGeometry(.5,.2,.5),new T.MeshStandardMaterial({color:'#f5f5f5',roughness:.5}));cs.scale.y=.6;item.add(cs,a,b);a.position.y=.12;b.position.y=.12;}
  else if(k.type==='a'){const s=new T.Mesh(new T.OctahedronGeometry(.27),em('#19e6ff'));s.scale.set(1,1.3,.6);item.add(s);}
  else if(k.type==='w'){const wl=Object.values(G.cfg.weapons),w=wl[k.id%wl.length],bg=MD.buildGun(w.model,w.color,null);bg.g.scale.setScalar(.8);bg.g.position.x=-.25;item.add(bg.g);const ring=new T.Mesh(new T.TorusGeometry(.4,.02,6,24),em('#ffd166'));ring.rotation.x=Math.PI/2;item.add(ring);}
  else{const b=new T.Mesh(new T.OctahedronGeometry(.22),em('#c9a7ff'));item.add(b);}
  const gl=new T.Sprite(new T.SpriteMaterial({map:glowTex(),color:col,blending:T.AdditiveBlending,depthWrite:false,transparent:true,opacity:.6}));gl.scale.set(1.6,1.6,1);gl.position.y=.35;g.add(gl);
  g.position.set(k.x/SC,0,k.y/SC);g.visible=!!k.up;g.userData={item,gl,seed:k.id*.7};mapGrp.add(g);pk.set(k.id,g);
}
R3.pickup=(k,e)=>{const g=pk.get(k.id);if(g)g.visible=!!k.up;if(!k.up)ring(k.x/SC,k.y/SC,'#8ff0c3',1.2,.45);};
/* ================= characters ================= */
function lookFor(id,cls){const r=G.roster.get(id);return MD.resolveLook(r&&r.c||cls,r&&r.lk,G.cfg);}
function getEnt(id,clsHint){
  const r=G.roster.get(id),opId=(r&&r.c)||clsHint||'ronin',look=lookFor(id,opId);
  let e=ents.get(id);
  if(e&&e.key===look.key)return e;
  if(e){entGrp.remove(e.C.root);e.C.dispose();}
  const C=MD.buildChar(look,G.cfg.weapons);C.setWeapon('pistol',G.cfg);entGrp.add(C.root);
  C.root.traverse(o=>{if(o.isMesh){o.castShadow=qual.shadows;}});
  const blob=new T.Mesh(new T.CircleGeometry(.42,20),new T.MeshBasicMaterial({map:glowTex(),color:'#000',transparent:true,opacity:.55,depthWrite:false}));blob.rotation.x=-Math.PI/2;blob.position.y=.015;C.root.add(blob);
  const rg=new T.Mesh(new T.RingGeometry(.44,.52,28),new T.MeshBasicMaterial({color:'#fff',transparent:true,opacity:.85,side:T.DoubleSide,depthWrite:false}));rg.rotation.x=-Math.PI/2;rg.position.y=.02;C.root.add(rg);
  e={id,C,key:look.key,ring:rg,blob,wid:'',seen:0,aim:0,dead:0,px:0,pz:0,t0:0,cls:opId};ents.set(id,e);return e;
}
function setRing(e,col,op){e.ring.material.color.set(col);e.ring.material.opacity=op;}
R3.rosterChanged=()=>{/* looks may have changed: getEnt rebuilds on next frame when the key differs */};
R3.kill=e=>{
  const v=ents.get(e.v);const now=performance.now()/1000;
  burst(e.x/SC,.5,e.y/SC,e.v===G.you?'#ff4d6d':'#ffb0b0',22);
  ring(e.x/SC,e.y/SC,'#ff4d6d',1.3,.5);
  if(v){v.dead=1;v.t0=now;v.fallDir=(v.id%2?1:-1);dying.push(v);ents.delete(e.v);}
};
R3.spawnFx=e=>{ring(e.x/SC,e.y/SC,'#19e6ff',1.6,.6);burst(e.x/SC,.2,e.y/SC,'#19e6ff',14);};
R3.ability=e=>{const col=e.k==='scan'?'#8ff0c3':e.k==='cloak'?'#c9a7ff':e.k==='surge'?'#ff9d1a':'#19e6ff';
  const rad=e.k==='scan'?(G.cfg.classes[G.roster.get(e.i)&&G.roster.get(e.i).c]||{}).radius/SC||17:e.k==='dash'?1.4:2;ring(e.x/SC,e.y/SC,col,rad,e.k==='scan'?1:.5);};
R3.localKick=()=>{const e=ents.get(G.you);if(e)e.C.kick();if(vm&&CS.mode==='fps')vm.kick();};
R3.snapCam=()=>{cam.snap=true;};
/* ================= effects pools ================= */
let tracers=[],flashes=[],rings=[],parts=null,pdat=null;
const NP=1500;
function initFx(){
  const geo=new T.BufferGeometry();pdat={pos:new Float32Array(NP*3),col:new Float32Array(NP*3),vel:new Float32Array(NP*3),life:new Float32Array(NP),max:new Float32Array(NP),i:0};
  geo.setAttribute('position',new T.BufferAttribute(pdat.pos,3));geo.setAttribute('color',new T.BufferAttribute(pdat.col,3));
  for(let i=0;i<NP;i++)pdat.pos[i*3+1]=-100;
  parts=new T.Points(geo,new T.PointsMaterial({size:.13,map:dotTex(),vertexColors:true,transparent:true,blending:T.AdditiveBlending,depthWrite:false,sizeAttenuation:true,fog:false}));parts.frustumCulled=false;
}
const _c=new T.Color();
function burst(x,y,z,col,n,spd=3.2){_c.set(col);for(let k=0;k<n;k++){const i=pdat.i=(pdat.i+1)%NP,a=Math.random()*TAU,u=Math.random()*2-.4,s=spd*(.4+Math.random());
  pdat.pos[i*3]=x;pdat.pos[i*3+1]=y;pdat.pos[i*3+2]=z;pdat.vel[i*3]=Math.cos(a)*s*(1-Math.abs(u)*.3);pdat.vel[i*3+1]=Math.max(.3,u*s*.9);pdat.vel[i*3+2]=Math.sin(a)*s*(1-Math.abs(u)*.3);
  pdat.col[i*3]=_c.r;pdat.col[i*3+1]=_c.g;pdat.col[i*3+2]=_c.b;pdat.max[i]=pdat.life[i]=.25+Math.random()*.45;}}
function stepParts(dt){
  for(let i=0;i<NP;i++){if(pdat.life[i]<=0){pdat.pos[i*3+1]=-100;continue;}pdat.life[i]-=dt;
    pdat.vel[i*3+1]-=9*dt;pdat.pos[i*3]+=pdat.vel[i*3]*dt;pdat.pos[i*3+1]=Math.max(.02,pdat.pos[i*3+1]+pdat.vel[i*3+1]*dt);pdat.pos[i*3+2]+=pdat.vel[i*3+2]*dt;
    const k=Math.max(0,pdat.life[i]/pdat.max[i]);pdat.col[i*3]*=.97;pdat.col[i*3+1]*=.97;pdat.col[i*3+2]*=.97;if(k<=0)pdat.pos[i*3+1]=-100;}
  parts.geometry.attributes.position.needsUpdate=true;parts.geometry.attributes.color.needsUpdate=true;
}
function ring(x,z,col,r,dur){const m=new T.Mesh(new T.RingGeometry(.9,1,40),new T.MeshBasicMaterial({color:col,transparent:true,opacity:.9,side:T.DoubleSide,depthWrite:false,blending:T.AdditiveBlending,fog:false}));m.rotation.x=-Math.PI/2;m.position.set(x,.07,z);fxGrp.add(m);rings.push({m,t:0,dur,r});}
const TRG=new T.BoxGeometry(1,1,1);
R3.shot=(e,mine)=>{
  const col=wcol(e.w),now=performance.now()/1000,ent=ents.get(e.i);
  let ox=e.x/SC,oz=e.y/SC,oy=.62;
  if(ent){ent.C.kick();ent.C.root.updateMatrixWorld(true);if(ent.C.muzzle){ent.C.muzzle.getWorldPosition(tmp);ox=tmp.x;oy=tmp.y;oz=tmp.z;}}
  if(mine&&CS.mode==='fps'&&vm&&vm.muzzle){vm.muzzleWorld(tmp);camera.localToWorld(tmp);ox=tmp.x;oy=tmp.y;oz=tmp.z;}
  for(const [a,l] of e.ls){const m=new T.Mesh(TRG,new T.MeshBasicMaterial({color:col,transparent:true,blending:T.AdditiveBlending,depthWrite:false,fog:false}));fxGrp.add(m);
    tracers.push({m,ox,oy,oz,a,l:l/SC,t:0});
    const range=(G.cfg.weapons[e.w]||{}).range||800;if(l<range-3){const ex=e.x/SC+Math.cos(a)*l/SC,ez=e.y/SC+Math.sin(a)*l/SC;burst(ex,.5,ez,col,6,2.2);}}
  const sp=new T.Sprite(new T.SpriteMaterial({map:glowTex(),color:col,blending:T.AdditiveBlending,depthWrite:false,transparent:true,fog:false}));sp.position.set(ox,oy,oz);sp.scale.set(1.3,1.3,1);fxGrp.add(sp);flashes.push({sp,t:0});
};
function stepFx(dt){
  for(let i=tracers.length-1;i>=0;i--){const q=tracers[i];q.t+=dt;const age=q.t/.13;if(age>=1){fxGrp.remove(q.m);q.m.material.dispose();tracers.splice(i,1);continue;}
    const head=Math.min(q.l,q.t*140),tail=Math.max(0,head-2.2-age*3),len=Math.max(.01,head-tail),mid=(head+tail)/2,dx=Math.cos(q.a),dz=Math.sin(q.a);
    q.m.position.set(q.ox+dx*mid,q.oy,q.oz+dz*mid);q.m.rotation.set(0,-q.a,0);q.m.scale.set(len,.035,.035);q.m.material.opacity=1-age;}
  for(let i=flashes.length-1;i>=0;i--){const f=flashes[i];f.t+=dt;if(f.t>.07){fxGrp.remove(f.sp);f.sp.material.dispose();flashes.splice(i,1);continue;}f.sp.material.opacity=1-f.t/.07;const s=1.3+f.t*8;f.sp.scale.set(s,s,1);}
  for(let i=rings.length-1;i>=0;i--){const r=rings[i];r.t+=dt;const k=r.t/r.dur;if(k>=1){fxGrp.remove(r.m);r.m.geometry.dispose();r.m.material.dispose();rings.splice(i,1);continue;}const s=r.r*(.15+.85*k);r.m.scale.set(s,s,s);r.m.material.opacity=.9*(1-k);}
  stepParts(dt);
}
/* ================= camera ================= */
const PITCH=56*Math.PI/180;
function camDist(){const ppu=Math.max(38,Math.min(62,H/8.6))/Math.max(.6,Math.min(1.6,S.cam)),fov=camera.fov*Math.PI/180;return Math.max(7,Math.min(20,H/ppu/(2*Math.tan(fov/2))));}
R3.pointerToWorld=(sx,sy)=>{
  ray.setFromCamera({x:sx/W*2-1,y:-(sy/H)*2+1},camera);const hit=ray.ray.intersectPlane(plane,tmp2);
  return hit?{x:hit.x*SC,y:hit.z*SC}:null;
};
R3.project=(wx,wy,wz,out)=>{tmp.set(wx,wy,wz).project(camera);out[0]=(tmp.x*.5+.5)*W;out[1]=(-tmp.y*.5+.5)*H;out[2]=tmp.z;return out;};
/* ================= HAVOC: vehicles, projectiles, dog tags, explosions, cameras ================= */
const SQC=['#3ea6ff','#4cd964','#ffd60a','#ff9500'];   /* teammate 1..4: blue, green, yellow, orange */
R3.sqColor=si=>SQC[(si|0)&3];
const siOf=id=>{const r=G.roster.get(id);if(r&&r.si!=null)return r.si;const q=G.sqd.find(m=>m.i===id);return q?q.si:0;};
const mateOf=id=>{if(id===G.you)return true;const r=G.roster.get(id);if(!r)return false;if(modeIsTeam())return r.t===G.team;if(roomIsBR()&&G.me.sq>=0)return r.sq===G.me.sq;return false;};
const vehEnts=new Map(),projEnts=new Map(),tagEnts=new Map(),decals=[],fxs=[];
let vm=null,vmKey='',boomLight=null,groundMesh=null,scorchTex=null,fireTex=null,smokeTex=null,spark=null,CS={x:0,y:0,z:0,eye:1,fov:70,snap:true,dist:2.4,yaw:0,pitch:.12,mode:'top',emoteCam:null,lastMode:'top'};
const puffTex=(kind)=>{const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d'),g=x.createRadialGradient(32,32,0,32,32,32);
  if(kind==='fire'){g.addColorStop(0,'rgba(255,250,200,1)');g.addColorStop(.25,'rgba(255,190,60,.95)');g.addColorStop(.6,'rgba(255,90,20,.55)');g.addColorStop(1,'rgba(120,20,0,0)');}
  else if(kind==='smoke'){g.addColorStop(0,'rgba(190,190,190,.85)');g.addColorStop(.55,'rgba(120,120,120,.5)');g.addColorStop(1,'rgba(70,70,70,0)');}
  else{g.addColorStop(0,'rgba(0,0,0,.95)');g.addColorStop(.55,'rgba(0,0,0,.7)');g.addColorStop(1,'rgba(0,0,0,0)');}
  x.fillStyle=g;x.fillRect(0,0,64,64);
  if(kind!=='fire'){const R=rng(kind==='smoke'?5:9);for(let i=0;i<26;i++){x.fillStyle=kind==='smoke'?'rgba(255,255,255,.05)':'rgba(0,0,0,.35)';x.beginPath();x.arc(8+R()*48,8+R()*48,2+R()*6,0,7);x.fill();}}
  const t=new T.CanvasTexture(c);t.colorSpace=T.SRGBColorSpace;return t;};
function fxSprite(tex,col,x,y,z,s0,s1,dur,vel,op,add,drag=0){
  const mat=new T.SpriteMaterial({map:tex,color:col,transparent:true,opacity:op,depthWrite:false,blending:add?T.AdditiveBlending:T.NormalBlending,fog:!add});
  const sp=new T.Sprite(mat);sp.position.set(x,y,z);sp.scale.set(s0,s0,1);fxGrp.add(sp);fxs.push({sp,t:0,dur,vel,s0,s1,op,add,drag,spin:(Math.random()-.5)*2});
}
function stepFxs(dt){
  for(let i=fxs.length-1;i>=0;i--){const f=fxs[i];f.t+=dt;const k=f.t/f.dur;
    if(k>=1){fxGrp.remove(f.sp);if(f.mesh||f.beam)f.sp.geometry.dispose();f.sp.material.dispose();fxs.splice(i,1);continue;}
    if(f.debris){f.vel[1]-=14*dt;const p=f.sp.position;p.x+=f.vel[0]*dt;p.y+=f.vel[1]*dt;p.z+=f.vel[2]*dt;if(p.y<.04){p.y=.04;f.vel[0]*=.6;f.vel[2]*=.6;f.vel[1]=Math.abs(f.vel[1])*.3;}f.sp.rotation.x+=dt*9;f.sp.rotation.z+=dt*7;continue;}
    if(f.beam){f.sp.material.opacity=f.op*(1-k);continue;}
    if(f.mesh){const s=f.s0+(f.s1-f.s0)*Math.sqrt(k);f.sp.scale.setScalar(s);f.sp.material.opacity=f.op*Math.pow(1-k,1.3);continue;}
    const d=Math.max(0,1-f.drag*dt);f.vel[0]*=d;f.vel[1]*=d;f.vel[2]*=d;
    f.sp.position.x+=f.vel[0]*dt;f.sp.position.y+=f.vel[1]*dt;f.sp.position.z+=f.vel[2]*dt;
    const s=f.s0+(f.s1-f.s0)*(f.add?Math.sqrt(k):k);f.sp.scale.set(s,s,1);f.sp.material.rotation+=f.spin*dt;
    f.sp.material.opacity=f.op*(f.add?Math.pow(1-k,1.4):(k<.12?k/.12:1)*(1-k));}
  if(boomLight&&boomLight.intensity>0){boomLight.intensity=Math.max(0,boomLight.intensity-dt*90);}
}
R3.sparks=(x,y,col,n=12)=>burst(x/SC,.4,y/SC,col||'#ffcf70',n,4.5);
R3.dust=(x,y)=>{for(let i=0;i<6;i++){const a=Math.random()*TAU;fxSprite(smokeTex,'#b9a98a',x/SC,.12,y/SC,.3,1.0,.7,[Math.cos(a)*1.1,.25,Math.sin(a)*1.1],.45,false,2);}ring(x/SC,y/SC,'#d8c8a8',1,.35);};
R3.beam=(x,y,col)=>{const m=new T.Mesh(new T.CylinderGeometry(.35,.35,14,16,1,true),new T.MeshBasicMaterial({color:col,transparent:true,opacity:.5,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide,fog:false}));m.position.set(x/SC,7,y/SC);fxGrp.add(m);
  fxs.push({sp:m,t:0,dur:1.6,vel:[0,0,0],s0:1,s1:1,op:.5,add:true,drag:0,spin:0,beam:true});};
/* the explosion engine: shockwave sphere, flash, hundreds of sparks, fire billboards, rising smoke, debris, scorch decal, light pulse */
R3.explode=e=>{
  if(!ok)return;const x=e.x/SC,z=e.y/SC,rad=Math.max(1.6,e.r/SC),big=e.k==='veh'||e.k==='rocket',K=big?1:.6;
  /* shockwave */
  const sw=new T.Mesh(new T.SphereGeometry(1,28,18),new T.MeshBasicMaterial({color:'#ffd9a0',transparent:true,opacity:.55,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide,fog:false}));sw.position.set(x,.5,z);sw.scale.setScalar(.2);fxGrp.add(sw);
  fxs.push({sp:sw,t:0,dur:.5,vel:[0,0,0],s0:.2,s1:rad*1.25,op:.55,add:true,drag:0,spin:0,mesh:true});
  ring(x,z,'#ffb347',rad*1.5,.5);ring(x,z,'#ffffff',rad,.28);
  fxSprite(fireTex,'#fff2c0',x,.6,z,rad*.4,rad*2.6,.18,[0,0,0],1,true);
  /* sparks */
  burst(x,.5,z,'#ffd070',Math.round(150*K),7);burst(x,.4,z,'#ff7a2a',Math.round(90*K),5);
  /* fire billboards */
  for(let i=0;i<Math.round(20*K);i++){const a=Math.random()*TAU,u=Math.random(),sp=(1+u*3.4)*rad*.9;
    fxSprite(fireTex,i%3?'#ff9a2a':'#ffd23a',x+Math.cos(a)*.2,.3+Math.random()*.4,z+Math.sin(a)*.2,rad*(.5+Math.random()*.5),rad*.08,.55+Math.random()*.55,[Math.cos(a)*sp,1.2+Math.random()*2.6,Math.sin(a)*sp],1,true,3.2);}
  /* smoke */
  for(let i=0;i<Math.round(16*K);i++){const a=Math.random()*TAU,sp=Math.random()*rad*.9;
    fxSprite(smokeTex,i%2?'#4a4a4a':'#6e6e6e',x+Math.cos(a)*rad*.3,.5+Math.random()*.4,z+Math.sin(a)*rad*.3,rad*.4,rad*(1.6+Math.random()*1.2),2+Math.random()*1.6,[Math.cos(a)*sp*.4,.9+Math.random()*1.2,Math.sin(a)*sp*.4],.7,false,.6);}
  /* debris */
  for(let i=0;i<Math.round(10*K);i++){const a=Math.random()*TAU,s=(2+Math.random()*4)*rad*.5;
    const d=new T.Mesh(TRG,new T.MeshStandardMaterial({color:'#2a2622',roughness:.9}));d.scale.setScalar(.05+Math.random()*.08);d.position.set(x,.4,z);fxGrp.add(d);
    fxs.push({sp:d,t:0,dur:1.1+Math.random()*.6,vel:[Math.cos(a)*s,3+Math.random()*4,Math.sin(a)*s],s0:1,s1:1,op:1,add:false,drag:0,spin:0,debris:true});}
  /* light pulse */
  if(boomLight){boomLight.position.set(x,1.2,z);boomLight.intensity=Math.max(boomLight.intensity,60*K);}
  /* scorch decal: raycast straight down onto the terrain */
  if(groundMesh){ray.set(new T.Vector3(x,3,z),new T.Vector3(0,-1,0));const hit=ray.intersectObject(groundMesh,false)[0],y=hit?hit.point.y:0;
    const dm=new T.Mesh(new T.CircleGeometry(rad*.62,24),new T.MeshBasicMaterial({map:scorchTex,transparent:true,opacity:.9,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2}));
    dm.rotation.x=-Math.PI/2;dm.rotation.z=Math.random()*TAU;dm.position.set(x,y+.014,z);mapGrp.add(dm);decals.push(dm);
    while(decals.length>28){const o=decals.shift();mapGrp.remove(o);o.geometry.dispose();o.material.dispose();}}
};
R3.rocket=e=>{const ent=ents.get(e.i);fxSprite(smokeTex,'#cfcfcf',e.x/SC+Math.cos(e.a)*.5,.6,e.y/SC+Math.sin(e.a)*.5,.4,1.4,.9,[0,.2,0],.6,false,.5);burst(e.x/SC+Math.cos(e.a)*.5,.6,e.y/SC+Math.sin(e.a)*.5,'#ffb36a',18,3);if(ent)ent.C.kick();};
function updVehicles(dt,ts,lit){
  const seen=new Set();
  for(const v of G.veh){
    let E=vehEnts.get(v.i);
    if(!E){const pal=[['#0c0d12','#ff6a1a'],['#b3261e','#161616'],['#16307a','#ffd23a'],['#1d1d22','#19e6ff']][v.i%4];
      const B=v.k==='heli'?HX.heli(['#3a7a55','#4a6fa5','#a53a3a'][v.i%3],'#ffcf40'):v.k==='atv'?HX.atv(['#b3261e','#1d6b3a','#c2851a','#2457c5'][v.i%4]):HX.car(['#c8281e','#1f5fd0','#d9a21b','#e8e8ee','#7b2fd0','#16a34a'][v.i%6],pal[1]);
      entGrp.add(B.root);B.root.traverse(o=>{if(o.isMesh)o.castShadow=qual.shadows;});E={B,x:v.x,y:v.y,a:v.a,z:v.z,r:v.r,vf:v.vf,vl:v.vl,smokeT:0,fireT:0};vehEnts.set(v.i,E);}
    const k=1-Math.exp(-dt*20);E.x+=(v.x+v.vx*.04-E.x)*k;E.y+=(v.y+v.vy*.04-E.y)*k;let da=v.a-E.a;while(da>Math.PI)da-=TAU;while(da<-Math.PI)da+=TAU;E.a+=da*k;E.z+=(v.z-E.z)*k;E.r+=(v.r-E.r)*k;E.vf+=(v.vf-E.vf)*k;E.vl+=(v.vl-E.vl)*k;
    E.B.root.position.set(E.x/SC,0,E.y/SC);E.B.root.rotation.y=-E.a;E.B.update({a:E.a,vf:E.vf,vl:E.vl,z:E.z,r:E.r,h:v.h,night:false},dt,ts);
    seen.add(v.i);E.h=v.h;E.live=true;E.seatsFull=v.s.every(s=>s);
    /* damage smoke + fire */
    if(v.h<45){E.smokeT-=dt;if(E.smokeT<=0){E.smokeT=v.h<20?.07:.16;const hy=(v.k==='heli'?E.z/SC+.9:.6);fxSprite(smokeTex,v.h<20?'#222':'#555',E.x/SC,hy,E.y/SC,.3,1.2,1.4,[(Math.random()-.5)*.4,1.1,(Math.random()-.5)*.4],.65,false,.5);}}
    if(v.h<20){E.fireT-=dt;if(E.fireT<=0){E.fireT=.1;fxSprite(fireTex,'#ff8a2a',E.x/SC+(Math.random()-.5)*.3,(v.k==='heli'?E.z/SC+.9:.6),E.y/SC+(Math.random()-.5)*.3,.5,.1,.45,[0,1.4,0],.9,true);}}
    if(v.k==='heli'&&v.r>.5&&E.z<40){E.dustT=(E.dustT||0)-dt;if(E.dustT<=0){E.dustT=.12;const a=Math.random()*TAU;fxSprite(smokeTex,'#b9a98a',E.x/SC+Math.cos(a)*1.2,.15,E.y/SC+Math.sin(a)*1.2,.4,1.2,.9,[Math.cos(a)*2.2,.2,Math.sin(a)*2.2],.35,false,1);}}
  }
  for(const [id,E] of vehEnts)if(!seen.has(id)){entGrp.remove(E.B.root);HX.dispose(E.B.root);vehEnts.delete(id);}
}
function updProj(dt,ts){
  const seen=new Set();
  for(const q of G.pr){let E=projEnts.get(q.i);
    if(!E){const g=new T.Group();
      if(q.k==='g'){g.add(new T.Mesh(new T.SphereGeometry(.07,10,8),new T.MeshStandardMaterial({color:'#3f4a2c',roughness:.6,metalness:.4})),new T.Mesh(new T.TorusGeometry(.045,.01,5,10),new T.MeshStandardMaterial({color:'#bbb',metalness:.9,roughness:.3})));g.children[1].position.y=.07;const bl=new T.Sprite(new T.SpriteMaterial({map:glowTex(),color:'#ff2a2a',blending:T.AdditiveBlending,depthWrite:false,transparent:true,fog:false}));bl.scale.set(.25,.25,1);bl.position.y=.04;g.add(bl);g.userData.bl=bl;}
      else{const b=new T.Mesh(new T.CylinderGeometry(.05,.05,.5,10),new T.MeshStandardMaterial({color:'#8a8f99',metalness:.7,roughness:.35}));b.rotation.z=Math.PI/2;const n=new T.Mesh(new T.ConeGeometry(.05,.14,10),new T.MeshStandardMaterial({color:'#c0392b'}));n.rotation.z=-Math.PI/2;n.position.x=.32;const fl=new T.Sprite(new T.SpriteMaterial({map:glowTex(),color:'#ff9a2a',blending:T.AdditiveBlending,depthWrite:false,transparent:true,fog:false}));fl.scale.set(.7,.7,1);fl.position.x=-.3;g.add(b,n,fl);}
      fxGrp.add(g);E={g,x:q.x,y:q.y,a:q.a,t:0,trail:0};projEnts.set(q.i,E);}
    const k=1-Math.exp(-dt*28);E.x+=(q.x-E.x)*k;E.y+=(q.y-E.y)*k;E.a=q.a;E.t+=dt;
    if(q.k==='g'){g_pos(E,.12+Math.abs(Math.sin(E.t*4))*.0);E.g.userData.bl.material.opacity=Math.sin(E.t*14)>0?1:.15;E.g.rotation.y+=dt*6;}
    else{g_pos(E,.62);E.g.rotation.y=-E.a;E.trail-=dt;if(E.trail<=0){E.trail=.02;fxSprite(smokeTex,'#d8d8d8',E.x/SC,.62,E.y/SC,.18,.8,.7,[0,.1,0],.55,false,.3);fxSprite(fireTex,'#ffb347',E.x/SC-Math.cos(E.a)*.25,.62,E.y/SC-Math.sin(E.a)*.25,.3,.05,.18,[0,0,0],.9,true);}}
    seen.add(q.i);}
  for(const [id,E] of projEnts)if(!seen.has(id)){fxGrp.remove(E.g);HX.dispose(E.g);projEnts.delete(id);}
}
function g_pos(E,y){E.g.position.set(E.x/SC,y,E.y/SC);}
function updTags(dt,ts){
  const seen=new Set();
  for(const t of G.tgs){let E=tagEnts.get(t.i);const si=siOf(t.o);
    if(!E||E.si!==si){if(E){entGrp.remove(E.root);HX.dispose(E.root);}const root=HX.tag(R3.sqColor(si));entGrp.add(root);E={root,si,seed:t.i*.9};tagEnts.set(t.i,E);}
    E.root.position.set(t.x/SC,0,t.y/SC);E.root.userData.g.rotation.y=ts*2.2+E.seed;E.root.userData.g.position.y=.55+Math.sin(ts*2.6+E.seed)*.07;E.root.userData.pad.rotation.z=ts;E.root.userData.pad.scale.setScalar(1+.08*Math.sin(ts*5));
    seen.add(t.i);}
  for(const [id,E] of tagEnts)if(!seen.has(id)){entGrp.remove(E.root);HX.dispose(E.root);tagEnts.delete(id);}
}
/* emotes */
R3.emote=(id,k)=>{const def=MD.EMOTES[k];if(!def)return;const e=ents.get(id);if(!e)return;e.emote={k,t:0,dur:def.dur};
  if(id===G.you)CS.emoteCam={t:0,dur:def.dur,a0:Math.random()<.5?-1:1};};
R3.emoteActive=()=>!!CS.emoteCam;
R3.cancelEmote=()=>{CS.emoteCam=null;const e=ents.get(G.you);if(e)e.emote=null;};
const viewMode=()=>{const me=G.me;if(S.view==='top')return 'top';if(G.sp||!me.al)return 'tps';if(S.view==='fps'&&!me.vh&&!CS.emoteCam&&!me.pa)return 'fps';return 'tps';};
R3.viewMode=viewMode;
R3.camYaw=()=>CS.yaw;
R3.fpActive=()=>CS.mode==='fps';
/* ================= frame ================= */
const _o=[0,0,0],_p=[0,0,0],_dir=new T.Vector3(),_cp=new T.Vector3(),_look=new T.Vector3();
const wrapA=a=>{while(a>Math.PI)a-=TAU;while(a<-Math.PI)a+=TAU;return a;};
function charState(x,y,aim,vx,vy,flags,t,alpha,ex){
  const sp=Math.hypot(vx,vy)/SC;
  return{x:x/SC,y:(ex.z||0)/SC,z:y/SC,aim,speed:sp,moveAng:Math.atan2(vy,vx),reload:!!(flags&128),dash:!!(flags&8),alpha,t,stance:ex.s||0,air:(ex.z||0)>3,para:!!(flags&256),emote:ex.emote};
}
R3.frame=(dt,t)=>{
  if(!ok)return;watchPerf(dt);
  if(G.state!=='play'){if(hub.on)hubFrame(dt,t);else{renderer.clear();}fctx.clearRect(0,0,W,H);CS.snap=true;return;}
  const me=G.me,ts=t/1000,spec=G.sp,vp=spec||me;
  const mode=viewMode();CS.mode=mode;const fp=mode==='fp'||mode==='fps';
  const others=viewOthers();
  MD.uTime.value=ts;
  /* --- characters --- */
  const seen=new Set();
  const upd=(id,e,isMe)=>{
    const ent=getEnt(id,isMe?me.cls:undefined);seen.add(id);
    const wid=isMe?me.wid:(e.w||'pistol');if(ent.wid!==wid){ent.C.setWeapon(wid,G.cfg);ent.wid=wid;}
    const r=G.roster.get(id),mate=!isMe&&mateOf(id);
    const cloak=!isMe&&(e.f&2),al=cloak?(mate?.4:.16):(isMe&&me.at>0&&(G.cfg.classes[me.cls]||{}).ability==='cloak'?.5:1);
    const x=isMe?me.x:e.x,y=isMe?me.y:e.y,vx=isMe?me.vx:(e.vx||0),vy=isMe?me.vy:(e.vy||0);
    const aim=isMe?(spec?me.a:INP.a):e.a,fl=isMe?(me.rl>0?128:0)|(me.dashT>0?8:0)|(me.pa?256:0):e.f;
    const z=isMe?me.z:(e.z||0),inVeh=isMe?me.vh:e.vh,stc=isMe?me.st:(e.f&512?2:(e.s||0));
    if(ent.emote){ent.emote.t+=dt;if(ent.emote.t>=ent.emote.dur){ent.emote=null;if(isMe)CS.emoteCam=null;}}
    ent.C.update(dt,charState(x,y,aim,vx,vy,fl,ts,al,{z:isMe?me.z:z,s:stc,emote:ent.emote}));
    ent.C.root.visible=!inVeh&&!(isMe&&(fp||(CS.mode==='tps'&&CS.tight)));
    /* parachute canopy */
    const para=!!(fl&256);
    if(para&&!ent.chute){ent.chute=HX.chute(R3.sqColor(roomIsBR()?siOf(id):(r&&r.t>=0?r.t:0)));ent.C.root.add(ent.chute);}
    if(ent.chute)ent.chute.visible=para;
    /* ring colour: squad colour for squadmates, team colour, red for enemies */
    if(isMe)setRing(ent,roomIsBR()&&me.sq>=0?R3.sqColor(me.si):'#ffffff',.6);
    else if(roomIsBR()&&mate)setRing(ent,R3.sqColor(siOf(id)),.95);
    else setRing(ent,modeIsTeam()?teamCol(r?r.t:-1):'#ff4d6d',mate?.8:.55);
    ent.sx=x;ent.sy=y;ent.vis=al;ent.z=z;
  };
  if(me.al&&!spec)upd(G.you,null,true);
  for(const [id,e] of others){if(e.f&16)continue;upd(id,e,false);}
  for(const [id,ent] of ents){if(!seen.has(id)){ent.C.root.visible=false;ent.seen+=dt;if(ent.seen>2.5){entGrp.remove(ent.C.root);ent.C.dispose();ents.delete(id);}}else ent.seen=0;}
  for(let i=dying.length-1;i>=0;i--){const d=dying[i],age=ts-d.t0;
    d.C.root.rotation.x=Math.min(1.5,age*5)*d.fallDir;d.C.root.position.y=Math.min(.12,age*.4);
    if(age>1.2){const a=Math.max(0,1-(age-1.2)/.8);for(const m of d.C.mats)if(m.transparent!==true){m.transparent=true;}for(const m of d.C.mats)m.opacity=a;}
    if(age>2.1){entGrp.remove(d.C.root);d.C.dispose();dying.splice(i,1);}}
  updVehicles(dt,ts);updProj(dt,ts);updTags(dt,ts);
  /* --- pickups --- */
  for(const [id,g] of pk){if(!g.visible)continue;const u=g.userData;u.item.rotation.y=ts*1.6+u.seed;u.item.position.y=.5+Math.sin(ts*2.4+u.seed)*.07;u.gl.material.opacity=.45+.2*Math.sin(ts*3+u.seed);}
  /* --- storm / zone --- */
  const b=G.br;
  if(storm&&b){storm.visible=true;const r=b.r/SC;storm.scale.set(r,1,r);storm.position.set(b.x/SC,6,b.y/SC);if(storm.material.uniforms)storm.material.uniforms.uTime.value=ts;
    nextRing.visible=b.nr>0&&(b.nx!==b.x||b.nr!==b.r);nextRing.position.set(b.nx/SC,.06,b.ny/SC);nextRing.scale.set(b.nr/SC,b.nr/SC,1);}
  if(zoneMesh){const z=G.map.zones[G.zi];zoneMesh.visible=!!z&&modeType()==='zone';if(z){zoneMesh.position.set(z.x/SC,0,z.y/SC);const R=(G.cfg.modes[G.modeId].zoneRadius||96)/SC;zoneMesh.scale.set(R,1,R);
      const col=G.zs===-2?'#ff4d6d':G.zs>=0?teamCol(G.zs):'#e8f2ff';zoneMesh.userData.mat.color.set(col);zoneMesh.userData.rg.color.set(col);zoneMesh.userData.rg.opacity=.6+.3*Math.sin(ts*4);}}
  if(P.water)P.water.emissiveIntensity=.4+.15*Math.sin(ts*1.3);
  /* --- camera --- */
  G.shake=Math.max(0,G.shake-dt*28);const shk=G.shake*.012,sx=(Math.random()-.5)*shk,sz=(Math.random()-.5)*shk,sy=(Math.random()-.5)*shk;
  const inVeh=!!me.vh&&!spec;
  if(mode==='top'){
    const dist=camDist(),la=matchMedia('(pointer:coarse)').matches?1.2:2.2;
    const px=vp.x/SC,pz=vp.y/SC,aimA=spec?spec.a:me.a;
    let tx=px+Math.cos(aimA)*la,tz=pz+Math.sin(aimA)*la;
    if(cam.snap){cam.x=tx;cam.z=tz;cam.snap=false;}
    const k=Math.min(1,dt*7);cam.x+=(tx-cam.x)*k;cam.z+=(tz-cam.z)*k;
    camera.fov+=(45-camera.fov)*Math.min(1,dt*8);camera.updateProjectionMatrix();
    camera.position.set(cam.x+sx,Math.sin(PITCH)*dist,cam.z+Math.cos(PITCH)*dist+sz);camera.lookAt(cam.x+sx,.2,cam.z+sz);
    G.yaw=INP.a;
    scene.fog.near=26;scene.fog.far=70;
  }else{
    /* hot-swappable first / third person camera */
    if(CS.lastMode==='top'||CS.snap){CS.x=vp.x;CS.y=vp.y;CS.snap=false;}
    const k=1-Math.exp(-dt*(inVeh||me.pa?38:26));CS.x+=(vp.x-CS.x)*k;CS.y+=(vp.y-CS.y)*k;
    if(Math.hypot(vp.x-CS.x,vp.y-CS.y)>200){CS.x=vp.x;CS.y=vp.y;}
    let alt=0;if(inVeh){const v=G.veh.find(q=>q.i===me.vh);alt=v?v.z/SC:0;}else alt=(spec?(spec.z||0):me.z)/SC;
    CS.zv=(CS.zv==null?alt:CS.zv+(alt-CS.zv)*Math.min(1,dt*18));
    let yaw=spec&&!G.yawFree?spec.a:G.yaw,pitch=G.pitch;
    if(G.yawTarget==='veh'){const v=G.veh.find(q=>q.i===me.vh);if(v){G.yaw=v.a;yaw=v.a;}G.yawTarget=null;}
    /* driving: the camera drifts back behind the vehicle when you are not looking around */
    if(inVeh&&me.sat===0&&performance.now()-(G.lookT||0)>1100){const v=G.veh.find(q=>q.i===me.vh);if(v){G.yaw=yaw=G.yaw+wrapA(v.a-G.yaw)*Math.min(1,dt*2.2);}}
    if(spec&&!G.yawFree){G.yaw=spec.a;}
    const stand=me.st===1?.78:me.st===2?.5:1.0,eyeT=stand,ads=INP.ads&&!inVeh&&me.al&&!me.pa&&!CS.emoteCam;
    CS.eye+=(eyeT-CS.eye)*Math.min(1,dt*12);
    const w=G.cfg.weapons[me.wid]||{},isSn=(w.model||me.wid)==='sniper';
    const fovT=mode==='fps'?(ads?(isSn?24:S.fov*.68):S.fov):(ads?S.fov*.8:S.fov+(inVeh?8:0));
    CS.fov+=(fovT-CS.fov)*Math.min(1,dt*10);camera.fov=CS.fov;camera.updateProjectionMatrix();
    const cy=Math.cos(yaw),sy2=Math.sin(yaw),cp=Math.cos(pitch),sp2=Math.sin(pitch);_dir.set(cy*cp,sp2,sy2*cp);
    const px=CS.x/SC,pz=CS.y/SC;
    if(mode==='fps'){
      _cp.set(px+sx,CS.zv+CS.eye+sy,pz+sz);camera.position.copy(_cp);_look.copy(_cp).add(_dir);camera.lookAt(_look);
      INP.a=yaw;
    }else if(CS.emoteCam){
      const ec=CS.emoteCam;ec.t+=dt;const u=ec.t/ec.dur,ang=yaw+Math.PI+ec.a0*(-.9+u*1.8),r=1.9+Math.sin(u*Math.PI)*.5;
      _cp.set(px+Math.cos(ang)*r,CS.zv+.9+Math.sin(u*Math.PI)*.35,pz+Math.sin(ang)*r);camera.position.copy(_cp);_look.set(px,CS.zv+.62,pz);camera.lookAt(_look);if(ec.t>=ec.dur)CS.emoteCam=null;
      INP.a=yaw;
    }else{
      /* shoulder-offset orbit camera; pulled in by walls; convergence keeps the crosshair honest */
      const dist=inVeh?(me.sat===0&&G.veh.find(q=>q.i===me.vh)&&G.veh.find(q=>q.i===me.vh).k==='heli'?6.2:3.9):(ads?1.45:2.35),shoulder=inVeh?0:(ads?.42:.55)*(S.swapShoulder?-1:1);
      const pivY=CS.zv+(inVeh?1.0:CS.eye*.96)+(me.pa?.3:0);
      const rx=-sy2,rz=cy;  /* right vector */
      let want=dist;const bx0=px,bz0=pz;
      const hd=Math.hypot(-cy*cp,-sy2*cp)||1;
      const dd=VB.rayGrid(G.map,bx0*SC,bz0*SC,-cy,-sy2,dist*SC+8,VB.BULLET_SOLID)/SC;if(dd<dist+.25)want=Math.max(.5,dd-.28);CS.tight=want<1.2&&!inVeh;
      _cp.set(px-cy*cp*want+rx*shoulder*(want/dist),pivY-sp2*want+.1,pz-sy2*cp*want+rz*shoulder*(want/dist));
      if(_cp.y<.25)_cp.y=.25;
      _cp.x+=sx;_cp.z+=sz;_cp.y+=sy;camera.position.copy(_cp);_look.copy(_cp).add(_dir.clone().multiplyScalar(10));camera.lookAt(_look);
      /* convergence: aim the sim bullet from the player towards what the crosshair is over */
      const wd=VB.rayGrid(G.map,_cp.x*SC,_cp.z*SC,cy,sy2,24*SC,VB.BULLET_SOLID)/SC,D=Math.max(4,Math.min(24,wd));
      const tx=_cp.x+cy*D,tz=_cp.z+sy2*D,ax=tx-px,az=tz-pz;
      INP.a=(ax*cy+az*sy2>1.2)?Math.atan2(az,ax):yaw;
    }
    scene.fog.near=18;scene.fog.far=56;
  }
  camera.updateMatrixWorld(true);
  sun.position.set(camera.position.x-8,16,camera.position.z+9);sun.target.position.set(camera.position.x,0,camera.position.z);sun.target.updateMatrixWorld();
  /* --- viewmodel (first person) --- */
  if(mode==='fps'&&me.al){
    const look=MD.resolveLook(me.cls,G.roster.get(G.you)&&G.roster.get(G.you).lk,G.cfg),key=look.key;
    if(!vm||vmKey!==key){if(vm)vm.dispose();vm=HX.viewmodel(look,G.cfg);vmKey=key;}
    if(vm.wid!==me.wid||vm.wkey!==(me.wid+JSON.stringify((look.wsk&&(look.wsk[me.wid]||look.wsk.any))||null)))vm.setWeapon(me.wid,G.cfg);
  }
  stepFx(dt);stepFxs(dt);
  renderer.render(scene,camera);
  if(mode==='fps'&&me.al&&vm){
    const ads=!!INP.ads,w=G.cfg.weapons[me.wid]||{};
    vm.cam.aspect=W/H;vm.cam.fov=58;vm.cam.updateProjectionMatrix();
    vm.update(dt,{speed:Math.hypot(me.vx,me.vy)/SC,ads:ads&&((w.model||me.wid)!=='sniper'),reload:me.rl>0,air:me.z>3,crouch:me.st===1,slide:me.st===2,dx:G.lookDX||0,dy:G.lookDY||0,t:ts,vis:true});
    G.lookDX=G.lookDY=0;
    if(vm.flashT>0){vm.flashT-=dt;vm.flash.material.opacity=Math.max(0,vm.flashT/.05);if(vm.muzzle){vm.muzzleWorld(_cp);vm.flash.position.copy(_cp);vm.flash.scale.setScalar(.28+(.05-vm.flashT)*4);}}else vm.flash.material.opacity=0;
    renderer.autoClear=false;renderer.clearDepth();renderer.render(vm.scene,vm.cam);renderer.autoClear=true;
  }
  CS.lastMode=mode;
  overlay(dt,others,vp,ts,mode);
};
/* ================= fog of war + labels (2D overlay on top of WebGL) ================= */
function overlay(dt,others,vp,ts,mode){
  const cfg=G.cfg,map=G.map,rad=cfg.player.vision,me=G.me;
  fctx.setTransform(1,0,0,1,0,0);fctx.clearRect(0,0,W,H);
  if(mode==='top'){
  /* fog */
  fctx.fillStyle=mapTheme==='open'?'rgba(3,6,10,.72)':'rgba(2,4,10,.78)';fctx.fillRect(0,0,W,H);
  fctx.globalCompositeOperation='destination-out';
  const N=280,cx=vp.x,cy=vp.y;
  R3.project(cx/SC,0,cy/SC,_o);const ox=_o[0],oy=_o[1];
  R3.project(cx/SC+rad/SC,0,cy/SC,_p);const hr=Math.max(40,Math.abs(_p[0]-ox));
  R3.project(cx/SC,0,cy/SC+rad/SC,_p);const ky=Math.max(.25,Math.min(1.5,Math.abs(_p[1]-oy)/hr));
  fctx.save();fctx.translate(ox,oy);fctx.scale(1,ky);
  const g=fctx.createRadialGradient(0,0,hr*.35,0,0,hr);g.addColorStop(0,'rgba(0,0,0,1)');g.addColorStop(.72,'rgba(0,0,0,.95)');g.addColorStop(1,'rgba(0,0,0,0)');
  fctx.fillStyle=g;fctx.beginPath();
  for(let i=0;i<N;i++){const a=i/N*TAU,dx=Math.cos(a),dy=Math.sin(a);let d=VB.rayGrid(map,cx,cy,dx,dy,rad,VB.SIGHT_SOLID),wall=d<rad;d=Math.min(rad,d+10);
    R3.project((cx+dx*d)/SC,wall?.75:0,(cy+dy*d)/SC,_p);const X=_p[0]-ox,Y=(_p[1]-oy)/ky;if(i)fctx.lineTo(X,Y);else fctx.moveTo(X,Y);}
  fctx.closePath();fctx.fill();
  const g2=fctx.createRadialGradient(0,0,0,0,0,hr*.22);g2.addColorStop(0,'rgba(0,0,0,.95)');g2.addColorStop(1,'rgba(0,0,0,0)');fctx.fillStyle=g2;fctx.beginPath();fctx.arc(0,0,hr*.22,0,TAU);fctx.fill();
  fctx.restore();
  const lights=[];if(modeIsTeam()||roomIsBR())for(const [id,e] of others){if(e.f&16)continue;if(mateOf(id))lights.push([e.x,e.y,150]);}
  for(const f of flashes)lights.push([f.sp.position.x*SC,f.sp.position.z*SC,120]);
  for(const [lx,ly,lr] of lights){R3.project(lx/SC,0,ly/SC,_o);R3.project((lx+lr)/SC,0,ly/SC,_p);const rr=Math.abs(_p[0]-_o[0]);const gg=fctx.createRadialGradient(_o[0],_o[1],0,_o[0],_o[1],rr);gg.addColorStop(0,'rgba(0,0,0,.6)');gg.addColorStop(1,'rgba(0,0,0,0)');fctx.fillStyle=gg;fctx.beginPath();fctx.arc(_o[0],_o[1],rr,0,TAU);fctx.fill();}
  fctx.globalCompositeOperation='source-over';
  }
  /* storm tint when the player is outside the safe grid */
  if(G.br&&me.zh){const a=.18+.08*Math.sin(ts*6);fctx.fillStyle=`rgba(40,120,255,${a})`;fctx.fillRect(0,0,W,H);}
  /* labels */
  fctx.textAlign='center';fctx.font='700 12px "Rajdhani",system-ui,sans-serif';
  for(const [id,e] of others){
    if(e.f&16){R3.project(e.x/SC,.4,e.y/SC,_o);if(_o[2]>1)continue;const p=.5+.5*Math.sin(ts*5+id);fctx.strokeStyle=`rgba(255,77,109,${.3+.4*p})`;fctx.lineWidth=2;fctx.beginPath();fctx.arc(_o[0],_o[1],14+p*8,0,TAU);fctx.stroke();fctx.fillStyle='rgba(255,77,109,.85)';fctx.fillText('?',_o[0],_o[1]+4);continue;}
    const r=G.roster.get(id)||{n:'?',t:-1},mate=mateOf(id),ent=ents.get(id);if(!ent||(!ent.C.root.visible&&!e.vh)||(ent.vis!=null&&ent.vis<.3&&!mate))continue;
    const d=Math.hypot(e.x-vp.x,e.y-vp.y);
    R3.project(e.x/SC,1.28+(e.z||0)/SC,e.y/SC,_o);if(_o[2]>1)continue;
    const col=roomIsBR()&&mate?R3.sqColor(siOf(id)):(modeIsTeam()?teamCol(r.t):'#ff4d6d');
    if(mate||d<460){fctx.fillStyle='rgba(0,0,0,.7)';fctx.fillText(r.n,_o[0]+1,_o[1]-9);fctx.fillStyle=col;fctx.fillText(r.n,_o[0],_o[1]-10);}
    if(mate&&mode!=='top'){fctx.fillStyle=col;fctx.beginPath();fctx.moveTo(_o[0]-5,_o[1]-24);fctx.lineTo(_o[0]+5,_o[1]-24);fctx.lineTo(_o[0],_o[1]-17);fctx.fill();}
    const pct=(e.h||100)/100,bw=30;fctx.fillStyle='rgba(0,0,0,.65)';fctx.fillRect(_o[0]-bw/2,_o[1]-6,bw,4);fctx.fillStyle=pct>.5?'#8ff0c3':pct>.25?'#ffd166':'#ff4d6d';fctx.fillRect(_o[0]-bw/2,_o[1]-6,bw*pct,4);
  }
  /* dog tag markers, vehicle markers */
  if(mode!=='top'){
    for(const tg of G.tgs){R3.project(tg.x/SC,1.2,tg.y/SC,_o);if(_o[2]>1)continue;const c=R3.sqColor(siOf(tg.o)),d=Math.hypot(tg.x-vp.x,tg.y-vp.y);fctx.fillStyle=c;fctx.beginPath();fctx.moveTo(_o[0],_o[1]+8);fctx.lineTo(_o[0]-7,_o[1]-4);fctx.lineTo(_o[0]+7,_o[1]-4);fctx.fill();fctx.fillStyle='rgba(0,0,0,.7)';fctx.fillText(Math.round(d/32)+'m',_o[0]+1,_o[1]-8);fctx.fillStyle=c;fctx.fillText(Math.round(d/32)+'m',_o[0],_o[1]-9);}
    for(const v of G.veh){if(v.i===me.vh)continue;const d=Math.hypot(v.x-vp.x,v.y-vp.y);if(d>520)continue;R3.project(v.x/SC,1.0+v.z/SC+(v.k==='heli'?1.4:0),v.y/SC,_o);if(_o[2]>1)continue;fctx.fillStyle='rgba(0,0,0,.6)';fctx.fillText((G.cfg.vehicles[v.k]||{}).name||v.k,_o[0]+1,_o[1]+1);fctx.fillStyle='#ffd166';fctx.fillText((G.cfg.vehicles[v.k]||{}).name||v.k,_o[0],_o[1]);}
  }
  /* damage vignette + low-health pulse */
  const da=Math.max(0,1-(performance.now()-G.dmgT)/700),low=me.al&&me.hp<me.mh*.3;
  if(da>0||low){const a=Math.max(da*.55,low?.16+.08*Math.sin(ts*7):0),vg=fctx.createRadialGradient(W/2,H/2,Math.min(W,H)*.3,W/2,H/2,Math.max(W,H)*.75);vg.addColorStop(0,'rgba(255,0,40,0)');vg.addColorStop(1,'rgba(255,0,40,'+a+')');fctx.fillStyle=vg;fctx.fillRect(0,0,W,H);
    if(da>0&&me.al){fctx.save();fctx.translate(W/2,H/2);fctx.rotate(G.dmgA-(mode==='top'?0:(CS.yaw||G.yaw||0)));const rr=Math.min(W,H)*.32;fctx.fillStyle='rgba(255,60,80,'+da+')';fctx.beginPath();fctx.moveTo(rr,0);fctx.lineTo(rr-20,-13);fctx.lineTo(rr-20,13);fctx.fill();fctx.restore();}}
  /* minimap */
  UI.drawMini&&UI.drawMini(others,vp,mode);
}

/* ================= hub showroom ================= */
function buildHub(){
  const s=hub.scene=new T.Scene();s.background=new T.Color('#05070f');s.fog=new T.Fog('#070a18',9,38);
  hub.camera=new T.PerspectiveCamera(38,1,.1,120);hub.camera.position.set(0,1.15,4.1);
  s.add(new T.HemisphereLight('#6f86ff','#1a1020',.75));
  const key=new T.SpotLight('#ffe2b8',90,16,.55,.5,1.2);key.position.set(2.6,3.6,3.2);key.target.position.set(-1.1,.7,0);s.add(key,key.target);
  const rim=new T.SpotLight('#19e6ff',120,14,.7,.6,1.1);rim.position.set(-3.5,2.8,-2.6);rim.target.position.set(-1.1,.8,0);s.add(rim,rim.target);
  const rim2=new T.PointLight('#ff3d9a',14,9,1.5);rim2.position.set(1.6,1.4,-2);s.add(rim2);
  /* floor + platform */
  const fl=new T.Mesh(new T.CircleGeometry(60,48),new T.MeshStandardMaterial({color:'#080b16',roughness:.6,metalness:.3}));fl.rotation.x=-Math.PI/2;s.add(fl);hub.fl=fl;hub.lights={key,rim,rim2};
  hub.plat=new T.Group();
  const pl=new T.Mesh(new T.CylinderGeometry(1.25,1.35,.12,48),new T.MeshStandardMaterial({color:'#0e1426',roughness:.7,metalness:.4}));pl.position.y=.06;hub.plat.add(pl);
  const pr=new T.Mesh(new T.TorusGeometry(1.25,.025,8,64),new T.MeshBasicMaterial({color:'#19e6ff'}));pr.rotation.x=Math.PI/2;pr.position.y=.13;hub.plat.add(pr);
  hub.pr=pr;s.add(hub.plat);
  /* skyline */
  const R=rng(2026),n=170,im=new T.InstancedMesh(new T.BoxGeometry(1,1,1),new T.MeshStandardMaterial({map:canvasTex(64,128,(x,w,h)=>{x.fillStyle='#0b1124';x.fillRect(0,0,w,h);const rr=rng(9);for(let j=0;j<12;j++)for(let i=0;i<4;i++){if(rr()<.5){x.fillStyle=rr()<.8?'rgba(255,205,120,.85)':'rgba(120,220,255,.85)';x.fillRect(5+i*15,6+j*10,8,5);}}}),emissive:new T.Color('#ffffff'),emissiveMap:null,emissiveIntensity:.0,roughness:.9}),n),M4=new T.Matrix4(),col=new T.Color();
  for(let i=0;i<n;i++){const a=R()*TAU,r=16+R()*34,h=3+R()*18,w=1.6+R()*3.2;M4.compose(new T.Vector3(Math.cos(a)*r,h/2,Math.sin(a)*r-6),new T.Quaternion(),new T.Vector3(w,h,w*(.8+R()*.6)));im.setMatrixAt(i,M4);col.setHSL(.6+R()*.1,.35,.35+R()*.35);im.setColorAt(i,col);}
  s.add(im);hub.sky=im;
  /* floating embers */
  const pg=new T.BufferGeometry(),pp=new Float32Array(160*3);for(let i=0;i<160;i++){pp[i*3]=(R()-.5)*14;pp[i*3+1]=R()*6;pp[i*3+2]=(R()-.5)*10-1;}pg.setAttribute('position',new T.BufferAttribute(pp,3));
  hub.parts=new T.Points(pg,new T.PointsMaterial({size:.05,color:'#ffb35c',map:dotTex(),transparent:true,blending:T.AdditiveBlending,depthWrite:false}));s.add(hub.parts);
  hub.char=null;hub.mates=[];
}
function placeHubChar(){if(!hub.camera)return;const asp=W/H,land=asp>1.25;hub.cx=land?(hub.paged?-1.6:-1.15):0;if(hub.char)hub.char.root.position.x=hub.cx;hub.plat.position.set(hub.cx,0,0);hub.sq=hub.paged?.0:1;for(const m of hub.mates||[]){m.pad.visible=m.C.root.visible=!hub.paged;}
  hub.camera.position.set(land?-.35:0,land?1.15:1.4,land?3.4:4.6);hub.camera.lookAt(land?-.3:0,(!land&&hub.paged)?-.5:.82,0);}
R3.hub={
  show(on){hub.on=on;fx.style.display=on?'none':'block';if(on)placeHubChar();},
  set(opId,lk,wid){
    if(!ok)return;const look=MD.resolveLook(opId,lk,G.cfg),key=look.key+'|'+wid+JSON.stringify(look.wsk[wid]||look.wsk.any||'');
    if(hub.key===key)return;hub.key=key;
    if(hub.char){hub.scene.remove(hub.char.root);hub.char.dispose();}
    const C=MD.buildChar(look,G.cfg.weapons);C.setWeapon(wid,G.cfg);hub.scene.add(C.root);hub.char=C;hub.wid=wid;C.root.position.set(hub.cx||0,.12,0);C.root.traverse(o=>{if(o.isMesh)o.castShadow=false;});
    hub.glow=look.glow||null;hub.pr.material.color.set(look.accent||'#19e6ff');
  },
  spin(d){hub.spin+=d;},
  internals:()=>hub,
  /* squad presentation: up to 3 extra operators beside/behind the player, each on a coloured pad */
  squad(list){
    for(const m of hub.mates||[]){hub.scene.remove(m.C.root);m.C.dispose();hub.scene.remove(m.pad);}
    hub.mates=[];if(!ok||!list)return;
    const SP=[[-1.25,-.55,.35],[1.25,-.55,-.35],[0,-1.5,0]];
    list.slice(0,3).forEach((m,i)=>{
      const look=MD.resolveLook(m.op,{s:'',w:{},b:[]},G.cfg),C=MD.buildChar(look,G.cfg.weapons);C.setWeapon(m.wid,G.cfg);C.root.traverse(o=>{if(o.isMesh)o.castShadow=false;});
      const col=R3.sqColor(i+1),pad=new T.Group();
      const d=new T.Mesh(new T.CylinderGeometry(.55,.6,.08,32),new T.MeshStandardMaterial({color:'#0e1426',roughness:.6,metalness:.4}));d.position.y=.04;pad.add(d);
      const r=new T.Mesh(new T.TorusGeometry(.55,.02,8,40),new T.MeshBasicMaterial({color:col}));r.rotation.x=Math.PI/2;r.position.y=.09;pad.add(r);
      const bm=new T.Mesh(new T.CylinderGeometry(.5,.5,2.4,24,1,true),new T.MeshBasicMaterial({color:col,transparent:true,opacity:.07,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide}));bm.position.y=1.2;bm.scale.set(.72,1,.72);pad.add(bm);
      hub.scene.add(pad);hub.scene.add(C.root);hub.mates.push({C,pad,o:SP[i],a:SP[i][2],spawn:0});
    });placeHubChar();
  },
  emote(k){const def=MD.EMOTES[k];if(!def||!hub.char)return;hub.emote={k,t:0,dur:def.dur};hub.emoCam={t:0,dur:def.dur+.3,s:Math.random()<.5?-1:1};if(k==='flex')hub.flexT=def.dur;},
  paged(on){hub.paged=on;placeHubChar();},
  flash(){burst(0,0,0,'#ffffff',0);},
  reveal(){/* little fanfare when a purchase happens */for(const c of ['#ffd166','#19e6ff','#ff3d9a'])hubBurst(c);}
};
let hubAutoA=0;
function hubFrame(dt,t){
  const ts=t/1000;hub.t=ts;let em=null;
  if(hub.emote){hub.emote.t+=dt;if(hub.emote.t>=hub.emote.dur)hub.emote=null;else em=hub.emote;}
  if(hub.char){
    if(!hub.drag&&!em)hub.spin+=dt*.25;
    hub.char.update(dt,{x:hub.cx||0,y:.12,z:0,aim:em?(hub.spin):(hub.dragA!=null?hub.dragA:(.0+hub.spin)),speed:0,moveAng:0,reload:false,dash:false,alpha:1,t:ts,emote:em});
    if(!em&&((ts*.7)%6)<.05)hub.char.kick();
    if(em&&em.k==='flex'&&Math.random()<.7)hubTrail(hub.cx||0,.95+Math.random()*.4,.35,'#ff3df5');
    if(em&&em.k==='backflip'&&Math.random()<.5)hubTrail(hub.cx||0,.4+em.t*.8,0,'#19e6ff');
  }
  /* squad mates: idle breathing, face the camera-ish, little stagger */
  for(const m of hub.mates||[]){const bx=(hub.cx||0)+m.o[0],bz=m.o[1];m.pad.position.set(bx,0,bz);m.spawn=Math.min(1,m.spawn+dt*2.2);m.pad.scale.setScalar(.3+.7*m.spawn);
    m.C.update(dt,{x:bx,y:.12,z:bz,aim:m.a+Math.sin(ts*.4+m.o[0])*.25,speed:0,moveAng:0,reload:false,dash:false,alpha:m.spawn,t:ts});}
  /* cinematic emote camera: slow sweep around the operator, pulls in and settles */
  if(hub.emoCam){const c=hub.emoCam;c.t+=dt;if(c.t>=c.dur){hub.emoCam=null;placeHubChar();}else{const u=c.t/c.dur,e=Math.sin(Math.min(1,u)*Math.PI),ang=c.s*(u-.5)*1.5+.15,rad=3.0-e*.7,cx=hub.cx||0;
    hub.camera.position.set(cx+Math.sin(ang)*rad,1.0+e*.35,Math.cos(ang)*rad);hub.camera.lookAt(cx,.85,0);}}
  hub.pr.material.color.offsetHSL(0,0,0);hub.plat.rotation.y=ts*.2;
  const pos=hub.parts.geometry.attributes.position;for(let i=0;i<pos.count;i++){let y=pos.getY(i)+dt*.12;if(y>6)y=0;pos.setY(i,y);}pos.needsUpdate=true;
  if(hub.themeUpd)hub.themeUpd(dt,ts);
  hubStep(dt);
  renderer.render(hub.scene,hub.camera);
}
/* hub particle pool (purchase bursts, emote trails) */
const HN=400,hubP={pos:new Float32Array(HN*3),col:new Float32Array(HN*3),vel:new Float32Array(HN*3),life:new Float32Array(HN),i:0,pts:null};
function hubPts(){if(hubP.pts)return;const g=new T.BufferGeometry();g.setAttribute('position',new T.BufferAttribute(hubP.pos,3));g.setAttribute('color',new T.BufferAttribute(hubP.col,3));
  hubP.pts=new T.Points(g,new T.PointsMaterial({size:.09,vertexColors:true,map:dotTex(),transparent:true,blending:T.AdditiveBlending,depthWrite:false}));hubP.pts.frustumCulled=false;hub.scene.add(hubP.pts);for(let i=0;i<HN;i++)hubP.pos[i*3+1]=-99;}
const _hc=new T.Color();
function hubAdd(x,y,z,vx,vy,vz,col,l){hubPts();const i=hubP.i++%HN;hubP.pos[i*3]=x;hubP.pos[i*3+1]=y;hubP.pos[i*3+2]=z;hubP.vel[i*3]=vx;hubP.vel[i*3+1]=vy;hubP.vel[i*3+2]=vz;_hc.set(col);hubP.col[i*3]=_hc.r;hubP.col[i*3+1]=_hc.g;hubP.col[i*3+2]=_hc.b;hubP.life[i]=l;}
function hubTrail(x,y,z,col){hubAdd(x+(Math.random()-.5)*.5,y,z+(Math.random()-.5)*.3,(Math.random()-.5)*.4,.3+Math.random()*.5,(Math.random()-.5)*.4,col,.7);}
function hubBurst(col){for(let i=0;i<60;i++)hubAdd(hub.cx||0,.9,0,(Math.random()-.5)*5,Math.random()*4.5,(Math.random()-.5)*5,col,1.1);}
function hubStep(dt){if(!hubP.pts)return;for(let i=0;i<HN;i++){if(hubP.life[i]<=0){hubP.pos[i*3+1]=-99;continue;}hubP.life[i]-=dt;hubP.vel[i*3+1]-=5*dt;hubP.pos[i*3]+=hubP.vel[i*3]*dt;hubP.pos[i*3+1]+=hubP.vel[i*3+1]*dt;hubP.pos[i*3+2]+=hubP.vel[i*3+2]*dt;}hubP.pts.geometry.attributes.position.needsUpdate=true;hubP.pts.geometry.attributes.color.needsUpdate=true;}
/* hub: drag to rotate the soldier */
R3.hubDrag=(dx)=>{hub.dragA=(hub.dragA!=null?hub.dragA:hub.spin)+dx*.012;hub.spin=hub.dragA;};
R3.hubDragEnd=()=>{hub.dragA=null;};
})();
