/* VECTOR HAVOC visual assets. Everything is built from primitives and canvas textures: vehicles (ATV, muscle car, helicopter),
   dog tags, parachutes, and the first-person viewmodel (sleeves, tactical gloves, weapon). World unit = 1 tile (32 sim px). +X is "forward" for every model. */
const HX=(()=>{
  const T=THREE,H={};
  const std=(c,o={})=>new T.MeshStandardMaterial(Object.assign({color:c,roughness:.55,metalness:.15,emissive:new T.Color(c),emissiveIntensity:.34},o));
  const bas=(c,o={})=>new T.MeshBasicMaterial(Object.assign({color:c},o));
  const bx=(w,h,d,m,x=0,y=0,z=0)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y,z);return o;};
  const cy=(rt,rb,h,m,x=0,y=0,z=0,s=14)=>{const o=new T.Mesh(new T.CylinderGeometry(rt,rb,h,s),m);o.position.set(x,y,z);return o;};
  const sph=(r,m,x=0,y=0,z=0,sx=1,sy=1,sz=1)=>{const o=new T.Mesh(new T.SphereGeometry(r,16,12),m);o.position.set(x,y,z);o.scale.set(sx,sy,sz);return o;};
  const glowTex=(()=>{let t=null;return()=>{if(t)return t;const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d'),g=x.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.35,'rgba(255,255,255,.5)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);t=new T.CanvasTexture(c);return t;};})();
  H.glowTex=glowTex;
  const glow=(col,s,x,y,z,op=.9)=>{const sp=new T.Sprite(new T.SpriteMaterial({map:glowTex(),color:col,blending:T.AdditiveBlending,depthWrite:false,transparent:true,opacity:op,fog:false}));sp.scale.set(s,s,1);sp.position.set(x,y,z);return sp;};
  const dispose=root=>{root.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.material){(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(m.map&&m.map!==glowTex())m.map.dispose();m.dispose();});}});};
  const wheel=(r,w,tire,rim)=>{const g=new T.Group(),t=cy(r,r,w,tire,0,0,0,18);t.rotation.x=Math.PI/2;const h=cy(r*.58,r*.58,w*1.04,rim,0,0,0,10);h.rotation.x=Math.PI/2;
    const sp=new T.Group();for(let i=0;i<5;i++){const s=bx(r*1.1,r*.12,w*1.08,rim);s.rotation.z=i*Math.PI/5;sp.add(s);}g.add(t,h,sp);return g;};
  const palette={car:['#0c0d12','#ff6a1a'],atv:['#b3261e','#161616']};
  /* ================= muscle car ================= */
  H.car=(body='#0c0d12',stripe='#ff6a1a')=>{
    const root=new T.Group(),paint=std(body,{metalness:.7,roughness:.28}),dark=std('#101218',{roughness:.6,metalness:.4}),glass=std('#1b2c46',{roughness:.05,metalness:.9,emissive:new T.Color('#0a1a30'),emissiveIntensity:.5}),st=std(stripe,{emissive:new T.Color(stripe),emissiveIntensity:.35,roughness:.4});
    const tire=std('#0b0b0d',{roughness:.9,metalness:0}),rim=std('#b8bfcc',{metalness:.9,roughness:.25});
    root.add(bx(1.95,.26,.86,paint,0,.3,0),bx(.7,.11,.8,paint,.62,.46,0),bx(.42,.1,.8,paint,-.78,.45,0));
    const cab=bx(.82,.24,.72,paint,-.12,.58,0);cab.scale.set(1,1,1);root.add(cab);
    root.add(bx(.7,.2,.64,glass,-.12,.6,0));root.add(bx(.12,.2,.74,paint,.3,.58,0).rotateZ(-.5),bx(.12,.2,.74,paint,-.55,.58,0).rotateZ(.5));
    root.add(bx(.5,.03,.18,dark,.62,.53,0));/* hood scoop */
    root.add(bx(1.5,.012,.1,st,.05,.5,.13),bx(1.5,.012,.1,st,.05,.5,-.13));/* racing stripes */
    root.add(bx(.26,.04,.98,dark,-.95,.72,0),bx(.04,.2,.04,dark,-.9,.6,.32),bx(.04,.2,.04,dark,-.9,.6,-.32));/* spoiler */
    root.add(bx(.08,.07,.9,dark,.98,.2,0),bx(.1,.06,.9,dark,-.98,.2,0));
    const hl=new T.MeshBasicMaterial({color:'#fff6d0'}),tl=new T.MeshBasicMaterial({color:'#ff2a3a'});
    root.add(bx(.04,.07,.2,hl,.98,.36,.28),bx(.04,.07,.2,hl,.98,.36,-.28),bx(.04,.06,.7,tl,-.98,.4,0));
    const beam=new T.Mesh(new T.ConeGeometry(.5,2.6,16,1,true),new T.MeshBasicMaterial({color:'#fff2c0',transparent:true,opacity:.1,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide,fog:false}));beam.rotation.z=-Math.PI/2;beam.position.set(2.3,.3,0);beam.visible=false;root.add(beam);
    root.add(glow('#fff2c0',.7,1.05,.36,.28,.8),glow('#fff2c0',.7,1.05,.36,-.28,.8),glow('#ff2a3a',.8,-1.02,.4,0,.7));
    const wheels=[],front=[];
    for(const [x,z] of [[.66,.46],[.66,-.46],[-.62,.46],[-.62,-.46]]){const piv=new T.Group();piv.position.set(x,.19,z);const w=wheel(.19,.17,tire,rim);piv.add(w);root.add(piv);wheels.push(w);if(x>0)front.push(piv);}
    const blob=new T.Mesh(new T.CircleGeometry(1,24),new T.MeshBasicMaterial({color:'#000',transparent:true,opacity:.45,depthWrite:false}));blob.rotation.x=-Math.PI/2;blob.scale.set(1.25,.7,1);blob.position.y=.012;root.add(blob);
    const V={root,k:'car',lastA:null,steer:0,ph:0};
    V.update=(v,dt,t)=>{
      V.ph+=(v.vf/32)*dt/.19;for(const w of wheels)w.rotation.z=-V.ph;
      let dy=0;if(V.lastA!=null){dy=v.a-V.lastA;while(dy>Math.PI)dy-=2*Math.PI;while(dy<-Math.PI)dy+=2*Math.PI;}V.lastA=v.a;
      const want=Math.max(-.5,Math.min(.5,-dy/Math.max(dt,.001)*.25*(v.vf>=0?1:-1)));V.steer+=(want-V.steer)*Math.min(1,dt*10);for(const f of front)f.rotation.y=V.steer;
      const lat=v.vl/32,fw=v.vf/32;root.rotation.z=-Math.max(-.07,Math.min(.07,lat*.02));root.rotation.x=Math.max(-.05,Math.min(.05,lat*.015));
      beam.visible=!!(v.night);
      body_hp(root,v.h);
    };
    return V;
  };
  function body_hp(root,h){/* smoking when damaged is handled by the renderer; here nothing to do */}
  /* ================= ATV ================= */
  H.atv=(body='#b3261e')=>{
    const root=new T.Group(),paint=std(body,{metalness:.5,roughness:.4}),dark=std('#15161b',{roughness:.6,metalness:.4}),tire=std('#0b0b0d',{roughness:.95,metalness:0}),rim=std('#c9ced8',{metalness:.9,roughness:.25});
    root.add(bx(1.0,.18,.44,dark,0,.34,0),bx(.5,.14,.46,paint,.36,.46,0),bx(.4,.11,.3,dark,-.15,.5,0),bx(.36,.12,.42,paint,-.46,.46,0));
    root.add(bx(.18,.05,.5,dark,.62,.32,0),bx(.14,.04,.52,dark,-.62,.32,0));
    const hb=new T.Group();hb.position.set(.38,.62,0);hb.add(cy(.018,.018,.5,dark,0,0,0,8).rotateX(Math.PI/2),bx(.05,.14,.04,dark,-.02,-.08,0),cy(.026,.026,.12,dark,0,0,.26,8).rotateX(Math.PI/2),cy(.026,.026,.12,dark,0,0,-.26,8).rotateX(Math.PI/2));root.add(hb);
    root.add(bx(.08,.1,.18,new T.MeshBasicMaterial({color:'#fff6d0'}),.6,.5,0),glow('#fff2c0',.6,.66,.5,0,.8),glow('#ff2a3a',.4,-.7,.46,0,.7));
    const wheels=[],front=[];
    for(const [x,z] of [[.42,.34],[.42,-.34],[-.4,.34],[-.4,-.34]]){const piv=new T.Group();piv.position.set(x,.2,z);const w=wheel(.2,.2,tire,rim);piv.add(w);root.add(piv);wheels.push(w);if(x>0)front.push(piv);}
    const blob=new T.Mesh(new T.CircleGeometry(1,24),new T.MeshBasicMaterial({color:'#000',transparent:true,opacity:.45,depthWrite:false}));blob.rotation.x=-Math.PI/2;blob.scale.set(.85,.55,1);blob.position.y=.012;root.add(blob);
    const V={root,k:'atv',lastA:null,steer:0,ph:0};
    V.update=(v,dt)=>{V.ph+=(v.vf/32)*dt/.2;for(const w of wheels)w.rotation.z=-V.ph;
      let dy=0;if(V.lastA!=null){dy=v.a-V.lastA;while(dy>Math.PI)dy-=2*Math.PI;while(dy<-Math.PI)dy+=2*Math.PI;}V.lastA=v.a;
      const want=Math.max(-.55,Math.min(.55,-dy/Math.max(dt,.001)*.3*(v.vf>=0?1:-1)));V.steer+=(want-V.steer)*Math.min(1,dt*10);for(const f of front)f.rotation.y=V.steer;hb.rotation.y=V.steer;
      root.rotation.z=-Math.max(-.14,Math.min(.14,(v.vl/32)*.03));};
    return V;
  };
  /* ================= helicopter ================= */
  H.heli=(body='#1d3b2a',accent='#ffcf40')=>{
    const root=new T.Group(),paint=std(body,{metalness:.55,roughness:.35}),dark=std('#14161c',{metalness:.5,roughness:.5}),glass=std('#2b4a70',{roughness:.05,metalness:.85,transparent:true,opacity:.72,emissive:new T.Color('#0b1c33'),emissiveIntensity:.5}),acc=std(accent,{emissive:new T.Color(accent),emissiveIntensity:.35});
    const air=new T.Group();root.add(air);/* everything that lifts */
    air.add(sph(.55,paint,0,.85,0,1.35,.78,.8),sph(.42,glass,.5,.9,0,1,.8,.85),bx(1.8,.17,.19,paint,-1.2,.92,0),bx(.12,.5,.05,paint,-2.05,1.1,0).rotateZ(.35),bx(.05,.12,.55,paint,-1.92,.95,0));
    air.add(bx(.7,.05,1.5,dark,.0,.55,0),bx(.9,.04,.18,acc,.0,.9,.55),bx(.9,.04,.18,acc,.0,.9,-.55));
    /* side rails and seats: passengers shoot from here */
    for(const s of [1,-1]){air.add(bx(.7,.03,.03,dark,-.05,.86,s*.62),bx(.03,.2,.03,dark,.25,.76,s*.62),bx(.03,.2,.03,dark,-.35,.76,s*.62),bx(.3,.05,.2,dark,-.1,.68,s*.5));}
    /* skids */
    for(const s of [1,-1]){air.add(bx(1.5,.045,.06,dark,0,.22,s*.5),bx(.05,.34,.05,dark,.4,.38,s*.5),bx(.05,.34,.05,dark,-.4,.38,s*.5));}
    /* mast + main rotor */
    air.add(cy(.05,.06,.22,dark,0,1.38,0,8));
    const rotor=new T.Group();rotor.position.set(0,1.5,0);for(let i=0;i<4;i++){const b=bx(2.3,.02,.14,dark,1.15,0,0);b.rotation.y=i*Math.PI/2;const holder=new T.Group();holder.rotation.y=i*Math.PI/2;holder.add(bx(2.3,.02,.14,dark,1.15,0,0));rotor.add(holder);}
    rotor.add(cy(.09,.09,.06,acc,0,0,0,10));air.add(rotor);
    const disc=new T.Mesh(new T.CircleGeometry(2.3,32),new T.MeshBasicMaterial({color:'#cfe6ff',transparent:true,opacity:0,depthWrite:false,side:T.DoubleSide,fog:false}));disc.rotation.x=-Math.PI/2;disc.position.set(0,1.51,0);air.add(disc);
    const tail=new T.Group();tail.position.set(-2.05,1.18,.06);for(let i=0;i<2;i++){const b=bx(.5,.03,.07,dark,0,0,0);b.rotation.x=i*Math.PI/2;tail.add(b);}air.add(tail);
    const beacon=glow('#ff2222',.5,-2.1,1.5,0,1);air.add(beacon,glow('#fff2c0',.9,.95,.78,0,.7));
    const blob=new T.Mesh(new T.CircleGeometry(1,24),new T.MeshBasicMaterial({color:'#000',transparent:true,opacity:.4,depthWrite:false}));blob.rotation.x=-Math.PI/2;blob.position.y=.012;root.add(blob);
    const V={root,k:'heli',air,lastA:null,ang:0,pitch:0,roll:0};
    V.update=(v,dt,t)=>{
      V.ang+=dt*v.r*42;rotor.rotation.y=V.ang;tail.rotation.z=V.ang*1.6;disc.material.opacity=Math.min(.16,v.r*.18);
      const alt=Math.max(0,v.z)/32;air.position.y=alt+.0;
      let dy=0;if(V.lastA!=null){dy=v.a-V.lastA;while(dy>Math.PI)dy-=2*Math.PI;while(dy<-Math.PI)dy+=2*Math.PI;}V.lastA=v.a;
      const tp=Math.max(-.3,Math.min(.3,-(v.vf/32)*.05)),tr=Math.max(-.35,Math.min(.35,-dy/Math.max(dt,.001)*.2));
      V.pitch+=(tp-V.pitch)*Math.min(1,dt*3);V.roll+=(tr-V.roll)*Math.min(1,dt*3);air.rotation.z=V.pitch;air.rotation.x=V.roll;
      beacon.material.opacity=(Math.sin(t*6)>.6)?1:.1;
      const k=Math.max(.35,1-alt/9);blob.scale.set(1.5*k,.9*k,1);blob.material.opacity=.42*k;
    };
    return V;
  };
  /* ================= dog tag ================= */
  H.tag=(col)=>{
    const g=new T.Group(),sh=new T.Shape();const w=.1,h=.15,r=.04;sh.moveTo(-w+r,-h);sh.lineTo(w-r,-h);sh.quadraticCurveTo(w,-h,w,-h+r);sh.lineTo(w,h-r);sh.quadraticCurveTo(w,h,w-r,h);sh.lineTo(-w+r,h);sh.quadraticCurveTo(-w,h,-w,h-r);sh.lineTo(-w,-h+r);sh.quadraticCurveTo(-w,-h,-w+r,-h);
    const hole=new T.Path();hole.absarc(0,h-.04,.018,0,Math.PI*2,true);sh.holes.push(hole);
    const m=new T.Mesh(new T.ExtrudeGeometry(sh,{depth:.02,bevelEnabled:true,bevelSize:.006,bevelThickness:.006,bevelSegments:1}),std('#d8dde6',{metalness:.95,roughness:.2,emissive:new T.Color(col),emissiveIntensity:.8}));
    m.position.z=-.01;g.add(m);
    const ring=new T.Mesh(new T.TorusGeometry(.12,.012,6,20),new T.MeshBasicMaterial({color:col}));ring.position.y=.17;g.add(ring);
    const bar=bx(.12,.018,.026,new T.MeshBasicMaterial({color:col}),0,-.02,.014),bar2=bx(.08,.018,.026,new T.MeshBasicMaterial({color:col}),0,-.07,.014);g.add(bar,bar2);
    const beam=new T.Mesh(new T.CylinderGeometry(.05,.14,2.6,12,1,true),new T.MeshBasicMaterial({color:col,transparent:true,opacity:.22,blending:T.AdditiveBlending,depthWrite:false,side:T.DoubleSide,fog:false}));beam.position.y=1.2;
    const root=new T.Group();g.position.y=.55;root.add(g,beam,glow(col,1.5,0,.55,0,.8));
    const pad=new T.Mesh(new T.RingGeometry(.28,.34,28),new T.MeshBasicMaterial({color:col,transparent:true,opacity:.8,side:T.DoubleSide,depthWrite:false,blending:T.AdditiveBlending}));pad.rotation.x=-Math.PI/2;pad.position.y=.03;root.add(pad);
    root.userData={g,pad,beam};return root;
  };
  /* ================= parachute ================= */
  H.chute=(col)=>{
    const root=new T.Group(),c=document.createElement('canvas');c.width=128;c.height=16;const x=c.getContext('2d');for(let i=0;i<8;i++){x.fillStyle=i%2?col:'#f4f4f4';x.fillRect(i*16,0,16,16);}
    const tex=new T.CanvasTexture(c);tex.colorSpace=T.SRGBColorSpace;tex.wrapS=T.RepeatWrapping;
    const dome=new T.Mesh(new T.SphereGeometry(.85,24,10,0,Math.PI*2,0,Math.PI/2),new T.MeshStandardMaterial({map:tex,roughness:.8,side:T.DoubleSide,emissive:new T.Color(col),emissiveIntensity:.18}));dome.scale.set(1,.62,1);dome.position.y=2.15;root.add(dome);
    const pts=[];for(let i=0;i<8;i++){const a=i/8*Math.PI*2;pts.push(new T.Vector3(Math.cos(a)*.85,2.15,Math.sin(a)*.85),new T.Vector3(Math.cos(a)*.06,1.05,Math.sin(a)*.06));}
    root.add(new T.LineSegments(new T.BufferGeometry().setFromPoints(pts),new T.LineBasicMaterial({color:'#e8edf5',transparent:true,opacity:.8})));
    return root;
  };
  /* ================= first-person viewmodel ================= */
  const UP=new T.Vector3(0,1,0),_v=new T.Vector3();
  function limb(mesh,a,b,len){_v.subVectors(b,a);const l=_v.length()||1e-3;_v.multiplyScalar(1/l);mesh.position.copy(a).addScaledVector(_v,l/2);mesh.quaternion.setFromUnitVectors(UP,_v);mesh.scale.set(1,l/len,1);}
  H.viewmodel=(look,cfg)=>{
    const scene=new T.Scene(),cam=new T.PerspectiveCamera(58,1,.01,10);
    scene.add(new T.HemisphereLight('#d6e0ff','#6a5a78',2.3));const dl=new T.DirectionalLight('#ffffff',2.6);dl.position.set(-.4,.8,.6);scene.add(dl);const dl2=new T.DirectionalLight('#9fd8ff',1.4);dl2.position.set(.6,-.3,-.2);scene.add(dl2);
    const root=new T.Group();scene.add(root);
    const sleeve=std(look.primary||'#1b3b63',{roughness:.85,metalness:0}),glove=std('#14161c',{roughness:.7,metalness:.15}),cuff=std(look.accent||'#19e6ff',{emissive:new T.Color(look.accent||'#19e6ff'),emissiveIntensity:.5,roughness:.5}),knuck=std('#2a2e38',{roughness:.5,metalness:.4});
    const mount=new T.Group();root.add(mount);const gunHold=new T.Group();mount.add(gunHold);gunHold.rotation.y=Math.PI/2;gunHold.scale.setScalar(.46);
    const mkArm=()=>{const up=new T.Mesh(new T.BoxGeometry(.085,1,.085),sleeve),fo=new T.Mesh(new T.BoxGeometry(.07,1,.07),sleeve),cf=new T.Mesh(new T.BoxGeometry(.082,.025,.082),cuff);
      const hand=new T.Group();hand.add(bx(.075,.05,.095,glove,0,0,0),bx(.07,.02,.07,knuck,0,.03,-.01),bx(.02,.045,.065,glove,.045,-.01,.005),bx(.02,.045,.065,glove,-.045,-.01,.005));
      root.add(up,fo,cf,hand);return{up,fo,cf,hand};};
    const aR=mkArm(),aL=mkArm();
    const R={scene,cam,root,mount,gun:null,spec:null,wid:'',wkey:'',fx:null,muzzle:null,ads:0,rc:0,rl:0,bob:0,sx:0,sy:0,swapT:0,vis:true,flash:null,sight:null};
    const mf=glow('#ffd9a0',.6,0,0,0,0);scene.add(mf);R.flash=mf;
    R.setWeapon=(wid,cfgx)=>{
      const sk=(look.wsk&&(look.wsk[wid]||look.wsk.any))||null,key=wid+JSON.stringify(sk);if(R.wkey===key)return;R.wkey=key;
      if(R.gun){gunHold.remove(R.gun);dispose(R.gun);}
      const w=cfgx.weapons[wid]||{},bg=MD.buildGun(w.model||wid,w.color,sk);bg.g.scale.setScalar(w.scale||1);R.gun=bg.g;R.spec=bg.spec;R.fx=bg.fx;R.muzzle=bg.muzzle;R.wid=wid;gunHold.add(bg.g);
      R.model=w.model||wid;R.swapT=1;bg.g.traverse(o=>{if(o.material&&!o.isSprite){(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(m.metalness!=null){m.metalness=Math.min(m.metalness,.3);m.roughness=Math.max(m.roughness||0,.5);if(m.color&&!m.onBeforeCompile.__mythic){const l=(m.color.r+m.color.g+m.color.b)/3;if(l<.12){m.color.lerp(new T.Color('#9aa6bd'),.32);}if(m.emissive&&m.emissiveIntensity>.3&&l>.5){m.emissiveIntensity=.35;}}}});}});
      /* optic: a tiny reflex sight on rifles/SMGs/LMGs, with a glowing red dot */
      if(['rifle','smg','lmg'].includes(R.model)){const sg=new T.Group();sg.position.set(bg.spec.len*.34,.075,0);sg.add(bx(.07,.004,.05,knuck,0,0,0),bx(.07,.04,.004,knuck,0,.022,.025),bx(.07,.04,.004,knuck,0,.022,-.025),bx(.003,.003,.003,bas('#ff2a2a'),.03,.025,0),glow('#ff2a2a',.03,.03,.025,0,.9));bg.g.add(sg);}
      R.swapT=1;
    };
    R.update=(dt,s)=>{
      /* s: {speed,ads,reload,air,crouch,slide,dx,dy,t,vis} */
      const k=Math.min(1,dt*12);R.ads+=((s.ads?1:0)-R.ads)*Math.min(1,dt*(s.ads?11:14));
      R.rc=Math.max(0,R.rc-dt*9);R.rl+=((s.reload?1:0)-R.rl)*Math.min(1,dt*7);R.swapT=Math.max(0,R.swapT-dt*3.2);
      R.bob+=dt*(3+s.speed*1.9)*(s.speed>.3?1:0);const sp=Math.min(1.4,s.speed/5.9),bobA=(1-R.ads*.85);
      R.sx+=((-s.dx||0)*.0009-R.sx)*Math.min(1,dt*10);R.sy+=((-s.dy||0)*.0009-R.sy)*Math.min(1,dt*10);
      const sway=(1-R.ads*.8),rc=R.rc,rl=R.rl,sw=R.swapT;
      const hipX=.15,hipY=-.15,hipZ=-.3,adsX=0,adsY=-.058,adsZ=-.24;
      let x=hipX+(adsX-hipX)*R.ads+Math.sin(R.bob)*.012*sp*bobA+R.sx*sway;
      let y=hipY+(adsY-hipY)*R.ads+Math.abs(Math.cos(R.bob))*.011*sp*bobA+R.sy*sway-(s.crouch?.015:0)-(s.slide?.05:0)-sw*.28-rl*.12+(s.air?.01:0);
      let z=hipZ+(adsZ-hipZ)*R.ads+rc*.07-rl*.02;
      mount.position.set(x,y,z);mount.rotation.set(rl*.55+rc*.07+sw*.5,-(s.slide?.25:0)+rl*.2,(s.slide?.18:0)-rl*.35+Math.sin(R.bob)*.012*sp*bobA);
      mount.updateMatrix();mount.updateMatrixWorld(true);
      if(R.fx)R.fx.update(s.t,dt);
      if(R.spec){
        const g=R.spec;const hR=_v.set(g.grip[0],g.grip[1]-.01,g.grip[2]);const HR=hR.clone();gunHold.localToWorld(HR);root.worldToLocal(HR);
        const HL=new T.Vector3(g.fore[0]-rl*.12,g.fore[1]+.0,g.fore[2]);gunHold.localToWorld(HL);root.worldToLocal(HL);
        const ER=new T.Vector3(.2,-.34,.06),EL=new T.Vector3(-.2,-.32,.09),SR2=new T.Vector3(.36,-.45,.16),SL2=new T.Vector3(-.3,-.5,.2);
        /* sleeves: off-screen shoulder -> elbow -> glove. Reload pulls the left hand down to the magazine. */
        limb(aR.up,SR2,ER,1);limb(aR.fo,ER,HR,1);aR.hand.position.copy(HR);aR.hand.quaternion.copy(mount.quaternion);aR.hand.rotateY(Math.PI/2);aR.cf.position.copy(HR).lerp(ER,.22);aR.cf.quaternion.copy(aR.fo.quaternion);
        limb(aL.up,SL2,EL,1);limb(aL.fo,EL,HL,1);aL.hand.position.copy(HL);aL.hand.quaternion.copy(mount.quaternion);aL.hand.rotateY(Math.PI/2);aL.cf.position.copy(HL).lerp(EL,.22);aL.cf.quaternion.copy(aL.fo.quaternion);
      }
      R.root.visible=!!s.vis;
    };
    R.kick=()=>{R.rc=1;if(R.flash){R.flashT=.05;}};
    R.dispose=()=>{dispose(root);};
    R.muzzleWorld=out=>{if(!R.muzzle)return out.set(0,0,-1);R.muzzle.getWorldPosition(out);return out;};
    return R;
  };
  H.dispose=dispose;
  return H;
})();
