/* Procedural 3D soldiers and guns (Three.js). Everything is built from primitives so no model files are needed, and every colour comes from the
   operator + equipped skin + bling + weapon skin, so cosmetics are visible to every player. World unit = 1 tile (32 sim pixels). */
const MD=(()=>{
  const T=THREE,M={};
  const texCache=new Map();
  function canvasTex(key,draw,size=128){
    if(texCache.has(key))return texCache.get(key);
    const c=document.createElement('canvas');c.width=c.height=size;const x=c.getContext('2d');draw(x,size);
    const t=new T.CanvasTexture(c);t.wrapS=t.wrapT=T.RepeatWrapping;t.colorSpace=T.SRGBColorSpace;t.anisotropy=2;texCache.set(key,t);return t;
  }
  function rng(seed){let s=seed>>>0||1;return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296;};}
  /* pattern textures: ankara, camo, stripes, gold, checker */
  M.pattern=(name,c1,c2)=>{
    if(!name||name==='solid')return null;
    return canvasTex(name+c1+c2,(x,s)=>{
      x.fillStyle=c1;x.fillRect(0,0,s,s);
      if(name==='ankara'){
        for(let i=0;i<4;i++)for(let j=0;j<4;j++){const cx=i*s/4+s/8+((j&1)?s/8:0),cy=j*s/4+s/8;
          for(let r=s/9;r>2;r-=s/36){x.fillStyle=((r/(s/36))|0)%2?c2:c1;x.beginPath();x.arc(cx%s,cy,r,0,7);x.fill();}
          x.fillStyle=c2;for(let a=0;a<6;a++){x.beginPath();x.arc(cx%s+Math.cos(a*1.05)*s/7,cy+Math.sin(a*1.05)*s/7,2.2,0,7);x.fill();}}
      }else if(name==='camo'){
        const R=rng(7);for(let i=0;i<22;i++){x.fillStyle=i%3?c2:'rgba(0,0,0,.28)';x.beginPath();x.ellipse(R()*s,R()*s,10+R()*20,6+R()*14,R()*3,0,7);x.fill();}
      }else if(name==='stripes'){
        x.fillStyle=c2;for(let i=-s;i<s*2;i+=s/4){x.save();x.translate(i,0);x.rotate(.0);x.fillRect(0,0,s/8,s);x.restore();}
      }else if(name==='gold'){
        const g=x.createLinearGradient(0,0,s,s);g.addColorStop(0,c1);g.addColorStop(.5,c2);g.addColorStop(1,c1);x.fillStyle=g;x.fillRect(0,0,s,s);
        x.fillStyle='rgba(255,255,255,.35)';const R=rng(3);for(let i=0;i<14;i++){x.fillRect(R()*s,R()*s,1+R()*3,1+R()*3);}
      }else if(name==='checker'){
        x.fillStyle=c2;for(let i=0;i<8;i++)for(let j=0;j<8;j++)if((i+j)&1)x.fillRect(i*s/8,j*s/8,s/8,s/8);
      }
    });
  };
  /* ---------- mythic shader patterns (WebGL, animated): damascus, diamond, aurora, wave, vinyl ---------- */
  M.uTime={value:0};
  M.glow=()=>canvasTex('glowdot',(x,s)=>{const g=x.createRadialGradient(s/2,s/2,0,s/2,s/2,s/2);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.4,'rgba(255,255,255,.5)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,s,s);},64);
  const PATID={damascus:1,diamond:2,aurora:3,wave:4,vinyl:5};
  M.isShaderPat=p=>!!PATID[p];
  function mythicize(mat,c1,c2,pat,spd,wob){
    const id=PATID[pat];if(!id)return mat;
    mat.onBeforeCompile=sh=>{
      sh.uniforms.uTime=M.uTime;sh.uniforms.uSpd={value:spd||1};sh.uniforms.uWob={value:wob||0};sh.uniforms.uC1={value:new T.Color(c1)};sh.uniforms.uC2={value:new T.Color(c2)};
      sh.vertexShader=sh.vertexShader.replace('#include <common>','#include <common>\nvarying vec3 vObj;uniform float uTime;uniform float uSpd;uniform float uWob;').replace('#include <begin_vertex>','#include <begin_vertex>\nvObj=position;transformed+=normal*sin(position.x*46.+position.y*28.+uTime*uSpd*4.)*uWob;');
      sh.fragmentShader=sh.fragmentShader.replace('#include <common>',`#include <common>
varying vec3 vObj;uniform float uTime;uniform float uSpd;uniform vec3 uC1;uniform vec3 uC2;
float hsh(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float nz(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hsh(i),hsh(i+vec2(1.,0.)),f.x),mix(hsh(i+vec2(0.,1.)),hsh(i+vec2(1.,1.)),f.x),f.y);}
float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*nz(p);p*=2.;a*=.5;}return v;}`)
      .replace('#include <color_fragment>',`#include <color_fragment>
float k=0.;float uT=uTime*uSpd;vec2 q=vec2(vObj.x*6.+vObj.z*4.,vObj.y*10.+vObj.z*3.);
if(${id}==1){float w=fbm(q*1.6+vec2(uT*.35,0.));k=smoothstep(.42,.58,sin(q.x*2.4+w*9.+uT*.9)*.5+.5);}
else if(${id}==2){vec2 u=vec2(vObj.x*18.+vObj.z*9.,vObj.y*34.+vObj.z*9.);float a=abs(fract(u.x+u.y)-.5),b=abs(fract(u.x-u.y)-.5);k=(1.-smoothstep(.0,.09,min(a,b)))*(.65+.35*sin(uT*2.2+u.x*2.));}
else if(${id}==3){float n=fbm(vec2(vObj.x*7.+uT*.55,vObj.y*11.+uT*.35+vObj.z*3.));k=smoothstep(.3,.8,n);}
else if(${id}==4){k=smoothstep(.35,.65,sin(vObj.x*34.-uT*4.+vObj.y*12.)*.5+.5);}
else{k=.5+.25*sin(length(vObj.xy)*150.);}
diffuseColor.rgb=mix(uC1,uC2,k);`)
      .replace('#include <emissivemap_fragment>','#include <emissivemap_fragment>\ntotalEmissiveRadiance+=uC2*k*.75;');
    };
    mat.customProgramCacheKey=()=>'mythic'+id;return mat;
  }
  const lm=(color,o={})=>new T.MeshStandardMaterial(Object.assign({color,roughness:.72,metalness:.08},o));
  function pm(color,pat,c2,glow,o={}){
    const tex=M.pattern(pat,color,c2||color);
    const m=lm(tex?'#ffffff':color,Object.assign({map:tex||null},o));
    if(glow){m.emissive=new T.Color(glow);m.emissiveIntensity=.55;}return m;
  }
  const box=(w,h,d,mat,x=0,y=0,z=0)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);return m;};
  const cyl=(r1,r2,h,mat,x=0,y=0,z=0,seg=10)=>{const m=new T.Mesh(new T.CylinderGeometry(r1,r2,h,seg),mat);m.position.set(x,y,z);return m;};
  const sph=(r,mat,x=0,y=0,z=0,sx=1,sy=1,sz=1)=>{const m=new T.Mesh(new T.SphereGeometry(r,14,10),mat);m.position.set(x,y,z);m.scale.set(sx,sy,sz);return m;};
  const tmpV=new T.Vector3(),tmpQ=new T.Quaternion(),UP=new T.Vector3(0,1,0);

  /* ---------- look resolution: operator + skin + bling + weapon skins -> plain colours ---------- */
  M.resolveLook=(opId,lk,cfg)=>{
    const op=(cfg.classes[opId]||cfg.classes[Object.keys(cfg.classes)[0]]),base=Object.assign({},op.look||{}),items=cfg.store.items;
    const out=Object.assign({sex:'m',skin:'#8a5a3b',primary:'#1b3b63',secondary:'#101c2e',accent:'#19e6ff',head:'',pattern:'solid',bulk:0},base,{bling:[],wsk:{}});
    if(lk&&lk.s&&items[lk.s]&&items[lk.s].look)Object.assign(out,items[lk.s].look);
    if(lk&&lk.b)for(const id of lk.b){const it=items[id];if(it&&it.type==='bling')out.bling.push(Object.assign({slot:it.slot},it.look));}
    if(lk&&lk.w)for(const w in lk.w){const it=items[lk.w[w]];if(it&&it.look)out.wsk[w]=it.look;}
    out.bot=!!(lk&&lk.bot);out.key=JSON.stringify([out.bot,opId,out.primary,out.secondary,out.accent,out.head,out.pattern,out.skin,out.sex,out.glow||'',out.bling.map(b=>b.slot+b.color)]);
    return out;
  };

  /* ---------- guns ---------- */
  const GUNS={
    pistol:{len:.27,grip:[0,-.015,0],fore:[.05,-.075,-.045],muz:.27,build(g,m){g.add(box(.25,.055,.048,m.body,.115,.02,0),box(.05,.11,.044,m.dark,0,-.06,0),box(.07,.02,.03,m.dark,.1,-.02,0),cyl(.012,.012,.04,m.dark,.26,.02,0,8));g.children[g.children.length-1].rotation.z=Math.PI/2;}},
    revolver:{len:.32,grip:[0,-.015,0],fore:[.05,-.08,-.045],muz:.34,build(g,m){g.add(box(.16,.06,.045,m.body,.08,.015,0),cyl(.036,.036,.09,m.dark,.12,.015,0,10),box(.05,.11,.044,m.dark,0,-.06,0),cyl(.016,.016,.2,m.body,.24,.03,0,8),box(.03,.02,.02,m.dark,.31,.05,0));g.children[2].rotation.x=Math.PI/2;g.children[4].rotation.z=Math.PI/2;}},
    smg:{len:.46,grip:[0,-.02,0],fore:[.27,-.07,0],muz:.5,build(g,m){g.add(box(.3,.08,.055,m.body,.15,.02,0),box(.04,.14,.034,m.dark,.12,-.1,0),box(.04,.08,.04,m.dark,.27,-.06,0),box(.05,.1,.04,m.dark,.0,-.07,0),cyl(.012,.012,.14,m.dark,.4,.025,0,8),box(.1,.03,.03,m.acc,.15,.075,0),box(.14,.05,.04,m.dark,-.07,0,0));g.children[4].rotation.z=Math.PI/2;}},
    rifle:{len:.68,grip:[0,-.02,0],fore:[.38,-.05,0],muz:.72,build(g,m){g.add(box(.36,.08,.056,m.body,.19,.02,0),cyl(.013,.013,.3,m.dark,.52,.03,0,8),box(.24,.07,.052,m.body,.42,.02,0),box(.22,.075,.046,m.dark,-.1,.0,0),box(.045,.13,.036,m.dark,.2,-.1,0),box(.04,.09,.04,m.dark,.03,-.08,0),box(.1,.035,.03,m.acc,.18,.08,0),box(.03,.05,.025,m.dark,.62,.065,0));g.children[1].rotation.z=Math.PI/2;g.children[3].rotation.z=-.08;g.children[4].rotation.z=.18;}},
    shotgun:{len:.66,grip:[0,-.02,0],fore:[.32,-.055,0],muz:.66,build(g,m){g.add(box(.22,.085,.056,m.body,.11,.015,0),cyl(.02,.02,.46,m.dark,.4,.035,0,10),cyl(.017,.017,.4,m.dark,.38,-.005,0,10),box(.13,.055,.062,m.wood||m.dark,.3,-.04,0),box(.24,.08,.05,m.wood||m.dark,-.12,-.0,0),box(.04,.09,.04,m.dark,.03,-.08,0));g.children[1].rotation.z=Math.PI/2;g.children[2].rotation.z=Math.PI/2;g.children[4].rotation.z=-.1;}},
    lmg:{len:.7,grip:[0,-.02,0],fore:[.4,-.06,0],muz:.76,build(g,m){g.add(box(.4,.095,.064,m.body,.2,.02,0),cyl(.016,.016,.34,m.dark,.58,.035,0,8),box(.22,.08,.058,m.body,.42,.02,0),box(.24,.08,.05,m.dark,-.1,0,0),cyl(.075,.075,.07,m.dark,.2,-.12,0,12),box(.1,.035,.032,m.acc,.2,.09,0),box(.03,.1,.02,m.dark,.62,-.04,.02),box(.03,.1,.02,m.dark,.62,-.04,-.02),box(.04,.09,.04,m.dark,.04,-.08,0));g.children[1].rotation.z=Math.PI/2;g.children[4].rotation.x=Math.PI/2;g.children[6].rotation.x=.4;g.children[7].rotation.x=-.4;}},
    sniper:{len:.98,grip:[0,-.02,0],fore:[.44,-.045,0],muz:1.02,build(g,m){g.add(box(.5,.075,.052,m.body,.26,.02,0),cyl(.012,.012,.5,m.dark,.75,.03,0,8),cyl(.03,.03,.26,m.dark,.28,.1,0,12),box(.28,.07,.044,m.dark,-.15,0,0),box(.04,.07,.036,m.dark,.22,-.07,0),box(.04,.09,.04,m.dark,.03,-.08,0),cyl(.034,.034,.02,m.acc,.42,.1,0,12),cyl(.034,.034,.02,m.acc,.14,.1,0,12),box(.02,.1,.01,m.dark,.65,-.05,.025),box(.02,.1,.01,m.dark,.65,-.05,-.025));g.children[1].rotation.z=Math.PI/2;g.children[2].rotation.z=Math.PI/2;g.children[6].rotation.z=Math.PI/2;g.children[7].rotation.z=Math.PI/2;g.children[8].rotation.x=.5;g.children[9].rotation.x=-.5;}}
  };
  GUNS.launcher={len:.8,grip:[0,-.02,0],fore:[.34,-.065,0],muz:.86,build(g,m){g.add(cyl(.052,.052,.78,m.body,.4,.05,0,14),cyl(.075,.062,.14,m.dark,.78,.05,0,14),cyl(.075,.075,.1,m.dark,.02,.05,0,14),box(.12,.05,.04,m.acc,.4,.125,0),box(.045,.12,.04,m.dark,.2,-.06,0),box(.045,.12,.04,m.dark,.46,-.06,0));g.children[0].rotation.z=Math.PI/2;g.children[1].rotation.z=Math.PI/2;g.children[2].rotation.z=Math.PI/2;}};
  M.gunDims=id=>GUNS[id]||GUNS.rifle;M.EMOTES={salute:{n:'Salute',dur:2.4},backflip:{n:'Backflip',dur:1.2},flex:{n:'Neon Flex',dur:2.8},dance:{n:'Dance',dur:3},wave:{n:'Wave',dur:2.4}};
  /* build a gun group at origin (+X = forward); returns {g,muzzle,spec} */
  M.buildGun=(model,wcolor,sk)=>{
    const spec=GUNS[model]||GUNS.rifle,g=new T.Group(),metal='#2a2f3a';
    const c1=sk&&sk.c1||'#2a2f3a',c2=sk&&sk.c2||wcolor||'#8ff0c3',shp=!!(sk&&M.isShaderPat(sk.pattern));
    let body;
    if(shp){body=mythicize(lm('#ffffff',{metalness:.45,roughness:.32}),c1,c2,sk.pattern,sk.spd,sk.wob);}
    else body=sk&&sk.pattern&&sk.pattern!=='solid'?pm(c1,sk.pattern,c2,sk.glow,{metalness:.35,roughness:.4}):lm(sk&&sk.c1?c1:metal,{metalness:.55,roughness:.4});
    if(sk&&sk.glow&&!shp&&!(sk.pattern&&sk.pattern!=='solid')){body.emissive=new T.Color(sk.glow);body.emissiveIntensity=.5;}
    const dark=lm(sk&&sk.c2?new T.Color(sk.c2).multiplyScalar(.45):'#161a22',{metalness:.5,roughness:.5});
    const acc=lm(c2,{emissive:new T.Color(sk&&sk.glow||c2),emissiveIntensity:.5,roughness:.4});
    const wood=lm('#4a3322',{roughness:.8});
    spec.build(g,{body,dark,acc,wood});
    const muzzle=new T.Object3D();muzzle.position.set(spec.muz,.02,0);g.add(muzzle);
    const fxl=[];
    if(sk&&sk.muzzle==='brake'){
      const bm=lm('#0d0f14',{metalness:.9,roughness:.25}),gl=new T.MeshBasicMaterial({color:sk.glow||c2});
      const br=new T.Group();br.position.set(spec.muz-.035,.025,0);
      br.add(cyl(.026,.026,.07,bm,0,0,0,10),box(.012,.05,.05,bm,-.02,0,0),box(.012,.05,.05,bm,.0,0,0),box(.012,.05,.05,bm,.02,0,0),cyl(.03,.03,.008,gl,.035,0,0,10));
      br.children[0].rotation.z=Math.PI/2;br.children[4].rotation.z=Math.PI/2;g.add(br);
    }
    if(sk&&sk.crystals){
      const cm=new T.MeshStandardMaterial({color:sk.glow||c2,emissive:new T.Color(sk.glow||c2),emissiveIntensity:1.3,roughness:.15,metalness:.1,transparent:true,opacity:.92,flatShading:true});
      const base=spec.len*.45,list=[[base-.08,.06,.0,.1,.5],[base+.04,.075,.02,.14,.2],[base+.12,.06,-.02,.08,-.4],[base-.02,.03,.04,.07,1.0],[base+.2,.05,.03,.06,.9]];
      for(const [x,y,z,h,r] of list){const c=new T.Mesh(new T.OctahedronGeometry(h*.5,0),cm);c.scale.set(.6,1.7,.6);c.position.set(x,y+h*.5,z);c.rotation.z=r*.5;c.rotation.x=r*.3;g.add(c);fxl.push({o:c,s:c.scale.clone(),p:x*30});}
    }
    let aura=null;
    if(sk&&sk.aura){
      const N=36,pos=new Float32Array(N*3),seed=[];for(let i=0;i<N;i++)seed.push({a:Math.random()*6.28,s:.4+Math.random(),r:.03+Math.random()*.06,u:Math.random()});
      const pg=new T.BufferGeometry();pg.setAttribute('position',new T.BufferAttribute(pos,3));
      aura={pts:new T.Points(pg,new T.PointsMaterial({color:sk.trail||sk.glow||c2,size:.035,transparent:true,opacity:.9,blending:T.AdditiveBlending,depthWrite:false,sizeAttenuation:true,fog:false})),pos,seed,N};aura.pts.frustumCulled=false;g.add(aura.pts);
    }
    const len=spec.len;
    const fx=(fxl.length||aura)?{update(t,dt){
      for(const c of fxl){const k=1+.18*Math.sin(t*3+c.p);c.o.scale.set(c.s.x*k,c.s.y*(.9+.2*Math.sin(t*2.2+c.p)),c.s.z*k);}
      if(aura){for(let i=0;i<aura.N;i++){const s=aura.seed[i];s.u=(s.u+dt*s.s*.55*(sk.vel||1))%1;const x=-.05+s.u*(len+.18);aura.pos[i*3]=x;aura.pos[i*3+1]=.03+Math.sin(s.a+t*2+s.u*9)*s.r*1.4+s.u*.05;aura.pos[i*3+2]=Math.cos(s.a+t*2.4+s.u*9)*s.r;}aura.pts.geometry.attributes.position.needsUpdate=true;}
    }}:null;
    g.traverse(o=>{if(o.isMesh){o.castShadow=false;}});
    return{g,muzzle,spec,fx,mythic:!!(sk&&(sk.crystals||sk.aura||shp))};
  };

  /* ---------- characters ---------- */
  const ARM1=.24,ARM2=.235;
  function placeLimb(mesh,a,b,len){
    tmpV.subVectors(b,a);const l=tmpV.length()||1e-3;tmpV.multiplyScalar(1/l);
    mesh.position.copy(a).addScaledVector(tmpV,l/2);mesh.quaternion.setFromUnitVectors(UP,tmpV);mesh.scale.set(1,l/len,1);
  }
  const _t1=new T.Vector3(),_t2=new T.Vector3(),_ax=new T.Vector3(),_pv=new T.Vector3(),_s=new T.Vector3(),_h=new T.Vector3(),_e=new T.Vector3(),_d=new T.Vector3(),_p=new T.Vector3(),_bd=new T.Vector3();
  function ik(S,H,bend,out){
    _d.subVectors(H,S);let d=_d.length();const reach=(ARM1+ARM2)*.985;if(d>reach){_d.multiplyScalar(reach/d);d=reach;H.copy(S).add(_d);}
    if(d<.06){d=.06;}
    _d.multiplyScalar(1/(d||1));const a=(ARM1*ARM1-ARM2*ARM2+d*d)/(2*d),h=Math.sqrt(Math.max(0,ARM1*ARM1-a*a));
    _bd.copy(bend);_bd.addScaledVector(_d,-_bd.dot(_d));if(_bd.lengthSq()<1e-6)_bd.set(0,-1,0);_bd.normalize();
    out.copy(S).addScaledVector(_d,a).addScaledVector(_bd,h);
  }
  M.buildChar=(look,cfgWeapons)=>{
    const L=look,female=L.sex==='f',bulk=L.bulk?1.18:1;
    const root=new T.Group(),lower=new T.Group(),upper=new T.Group();root.add(lower,upper);upper.position.y=.5;
    const mats=[];const reg=m=>{mats.push(m);return m;};
    const skin=reg(lm(L.skin,{roughness:.8})),shirt=reg(pm(L.primary,L.pattern,L.secondary,L.glow)),pants=reg(lm(L.secondary)),acc=reg(lm(L.accent,{emissive:new T.Color(L.glow||L.accent),emissiveIntensity:.35,roughness:.5})),dark=reg(lm('#10131a')),glove=reg(lm(new T.Color(L.accent).multiplyScalar(.55)));
    const hair=reg(lm('#0c0a09',{roughness:.9}));
    const tw=(female?.3:.35)*bulk,td=(female?.17:.2)*bulk;
    /* legs */
    const mkLeg=side=>{
      const hip=new T.Group();hip.position.set(0,.5,side*(female?.085:.095)*bulk);
      const th=box(.13*bulk,.26,.14*bulk,pants,0,-.13,0),knee=new T.Group();knee.position.y=-.26;
      const sh=box(.11*bulk,.235,.12*bulk,pants,0,-.118,0),boot=box(.2,.08,.13*bulk,dark,.03,-.255,0),sole=box(.21,.02,.135*bulk,acc,.03,-.3,0);
      knee.add(sh,boot,sole);hip.add(th,knee);lower.add(hip);return{hip,knee};
    };
    const legL=mkLeg(-1),legR=mkLeg(1);
    /* torso */
    const torso=box(td,.3,tw,shirt,0,.19,0);upper.add(torso);
    const vest=box(td+.02,.17,tw*.86,dark,.0,.23,0);upper.add(vest);upper.add(box(td+.03,.04,tw*.9,acc,.0,.285,0));
    upper.add(box(td+.015,.045,tw+.012,reg(lm(L.secondary)),0,.045,0));
    if(bulk>1){upper.add(box(.12,.2,.34,dark,-.15,.2,0));}
    const pelvis=box(td*.95,.1,tw*.9,pants,0,.0,0);upper.add(pelvis);
    /* head */
    const head=new T.Group();head.position.set(0,.46,0);upper.add(head);
    upper.add(cyl(.045,.05,.05,skin,0,.37,0,8));
    head.add(sph(.113,skin,0,0,0,1,1.06,.95));
    head.add(box(.012,.026,.03,reg(lm('#fff')),.105,.02,.04),box(.012,.026,.03,reg(lm('#fff')),.105,.02,-.04),box(.014,.014,.014,dark,.112,.02,.04),box(.014,.014,.014,dark,.112,.02,-.04));
    head.add(box(.012,.01,.05,reg(lm(new T.Color(L.skin).multiplyScalar(.6))),.11,-.04,0));
    const HD=L.head||'';
    const headTop=(r)=>{const m=new T.Mesh(new T.SphereGeometry(r,14,8,0,Math.PI*2,0,Math.PI/2),hair);m.position.y=.0;m.scale.set(1,1,.97);return m;};
    if(!HD||HD==='braids'||HD==='afro'){}
    if(HD===''){head.add(headTop(.12));}
    else if(HD==='cap'){const cm=reg(lm(L.accent));const c=new T.Mesh(new T.SphereGeometry(.12,14,8,0,Math.PI*2,0,Math.PI/2),cm);c.position.y=.005;head.add(c,box(.1,.012,.13,cm,.11,.03,0));}
    else if(HD==='fila'){const fm=reg(pm(L.secondary,L.pattern==='solid'?'gold':L.pattern,L.accent,L.glow));head.add(cyl(.095,.115,.14,fm,0,.1,0,14),sph(.1,fm,0,.17,0,1,.3,1));head.add(headTop(.11));}
    else if(HD==='helmet'){const hm=reg(lm(L.primary,{roughness:.5,metalness:.2}));const h=new T.Mesh(new T.SphereGeometry(.135,14,10,0,Math.PI*2,0,Math.PI*.62),hm);h.position.y=.02;head.add(h,box(.04,.045,.17,dark,.115,.025,0),box(.16,.015,.04,acc,.0,.115,0));}
    else if(HD==='gele'){const gm=reg(pm(L.primary,L.pattern==='solid'?'ankara':L.pattern,L.accent,L.glow));head.add(headTop(.115),sph(.15,gm,-.02,.12,0,1.15,.55,1.35),sph(.1,gm,-.02,.19,.1,1,.8,1.3),box(.2,.16,.04,gm,-.03,.24,.19).rotateZ(.25),box(.14,.14,.04,gm,-.03,.2,-.15).rotateZ(-.2));}
    else if(HD==='durag'){const dm=reg(lm(L.secondary));const c=new T.Mesh(new T.SphereGeometry(.12,14,8,0,Math.PI*2,0,Math.PI/2),dm);c.position.y=.01;head.add(c,box(.18,.03,.04,dm,-.2,.0,0));}
    else if(HD==='beanie'){const bm=reg(lm(L.primary));const c=new T.Mesh(new T.SphereGeometry(.125,14,8,0,Math.PI*2,0,Math.PI/2),bm);c.position.y=.015;head.add(c,cyl(.125,.125,.04,acc,0,.01,0,14));}
    else if(HD==='mask'){head.add(headTop(.12),box(.04,.07,.17,dark,.1,-.045,0),box(.05,.03,.2,acc,.095,.03,0));}
    else if(HD==='afro'){head.add(sph(.175,hair,-.03,.07,0,1,1,1));}
    else if(HD==='braids'){head.add(headTop(.125));for(let i=0;i<7;i++){const z=(i-3)*.032;head.add(cyl(.011,.008,.34+(i%2)*.06,hair,-.12,-.13,z,6));}head.add(box(.02,.02,.2,acc,-.12,.0,0));}
    else if(HD==='crown'){const cr=reg(lm('#ffcf40',{metalness:.7,roughness:.25,emissive:new T.Color('#ffcf40'),emissiveIntensity:.5}));head.add(headTop(.115),cyl(.1,.105,.05,cr,0,.12,0,12));for(let i=0;i<6;i++){const a=i/6*Math.PI*2;const c=new T.Mesh(new T.ConeGeometry(.022,.07,6),cr);c.position.set(Math.cos(a)*.095,.18,Math.sin(a)*.095);head.add(c);}}
    else head.add(headTop(.12));
    /* bling */
    for(const b of L.bling){
      const col=b.color||'#ffc933',bm=reg(lm(col,{metalness:.8,roughness:.2,emissive:new T.Color(b.glow||col),emissiveIntensity:b.glow?.7:.25}));
      if(b.slot==='neck'){const t=new T.Mesh(new T.TorusGeometry(.085,.013,6,18),bm);t.rotation.x=Math.PI/2;t.position.set(.0,.35,0);t.scale.set(1,1.15,1);upper.add(t);const p=new T.Mesh(new T.OctahedronGeometry(.032),bm);p.position.set(td/2+.02,.27,0);upper.add(p);}
      if(b.slot==='face'){head.add(box(.03,.04,.19,reg(lm('#050505',{metalness:.9,roughness:.15})),.108,.022,0),box(.025,.012,.1,bm,.112,.045,0));}
      if(b.slot==='ear'){head.add(sph(.014,bm,0,-.005,.117),sph(.014,bm,0,-.005,-.117));}
      if(b.slot==='head'){head.add(cyl(.1,.105,.04,bm,0,.125,0,10));}
    }
    /* arms: shoulders on the upper body, limbs are re-posed every frame by IK onto the gun */
    const shoulderY=.3,sz=(tw/2+.03);
    const mkArm=()=>({up:box(.075*bulk,ARM1,.075*bulk,shirt),fo:box(.062*bulk,ARM2,.062*bulk,shirt),hand:box(.07,.07,.07,glove)});
    const armR=mkArm(),armL=mkArm();
    for(const a of [armR,armL]){a.up.geometry.translate(0,0,0);upper.add(a.up,a.fo,a.hand);}
    /* wrist bling on the left arm */
    for(const b of L.bling)if(b.slot==='wrist'){const bm=reg(lm(b.color||'#ffc933',{metalness:.8,roughness:.2,emissive:new T.Color(b.glow||b.color||'#ffc933'),emissiveIntensity:.3}));armL.fo.add(cyl(.05,.05,.04,bm,0,-.08,0,10));}
    upper.add(sph(.055*bulk,shirt,0,shoulderY,sz),sph(.055*bulk,shirt,0,shoulderY,-sz));
    /* bots wear glowing red shoulder lights so enemies are easy to read */
    if(L.bot){const rl=new T.MeshBasicMaterial({color:'#ff2438'});for(const sd of [1,-1]){upper.add(box(.05,.035,.05,rl,0,shoulderY+.055,sd*(sz+.01)));const sp=new T.Sprite(new T.SpriteMaterial({color:'#ff2438',map:M.glow(),blending:T.AdditiveBlending,depthWrite:false,transparent:true,opacity:.9,fog:false}));sp.scale.set(.3,.3,1);sp.position.set(0,shoulderY+.06,sd*(sz+.01));upper.add(sp);}}
    /* gun mount */
    const gunMount=new T.Group();gunMount.position.set(.1,.2,.075);upper.add(gunMount);
    const C={root,lower,upper,head,legL,legR,armR,armL,mats,gunMount,gun:null,muzzle:null,spec:null,phase:Math.random()*6,yawLower:0,recoil:0,reload:0,cr:0,sl:0,air:0,emW:0,wid:'',wsk:'',alpha:1,L,shoulder:{r:new T.Vector3(0,shoulderY,sz),l:new T.Vector3(0,shoulderY,-sz)}};
    C.setWeapon=(wid,cfg)=>{
      const sk=L.wsk[wid]||L.wsk.any||null,key=wid+JSON.stringify(sk);if(C.wkey===key)return;C.wkey=key;
      if(C.gun){gunMount.remove(C.gun);C.gun.traverse(o=>{if(o.isMesh)o.geometry.dispose();});}
      const w=cfg.weapons[wid]||{},bg=M.buildGun(w.model||wid,w.color,sk);bg.g.scale.setScalar(w.scale||1);C.gun=bg.g;C.muzzle=bg.muzzle;C.spec=bg.spec;C.gunFx=bg.fx;C.mythic=bg.mythic;gunMount.add(bg.g);C.wid=wid;
      C.gunMats=[];bg.g.traverse(o=>{if(o.isMesh)C.gunMats.push(o.material);});
    };
    const bendR=new T.Vector3(0,-.8,.7),bendL=new T.Vector3(0,-.8,-.7),SR=new T.Vector3(),SL=new T.Vector3(),HR=new T.Vector3(),HL=new T.Vector3(),ER=new T.Vector3(),EL=new T.Vector3();
    /* st: {x,z,aim,speed (tiles/s), moveAng, reload, dash, alpha, t} */
    C.update=(dt,st)=>{
      root.position.set(st.x,st.y||0,st.z);M.uTime.value=st.t;if(C.gunFx)C.gunFx.update(st.t,dt);
      const sp=Math.min(1.6,st.speed/5.9);
      upper.rotation.y=-st.aim;
      /* legs follow the direction of travel (with a smooth turn); idle legs follow the aim */
      let target=st.speed>.4?st.moveAng:st.aim;let d=target-C.yawLower;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;
      C.yawLower+=d*Math.min(1,dt*(st.speed>.4?14:5));lower.rotation.y=-C.yawLower;
      /* when travelling backwards or sideways relative to the aim the stride direction flips */
      let rel=st.moveAng-st.aim;while(rel>Math.PI)rel-=2*Math.PI;while(rel<-Math.PI)rel+=2*Math.PI;const back=Math.abs(rel)>Math.PI/2?-1:1;
      C.phase+=dt*(4+st.speed*1.9)*(st.speed>.3?1:0);
      const amp=Math.min(.95,sp*.9),sw=Math.sin(C.phase);
      legL.hip.rotation.z=sw*amp*back;legR.hip.rotation.z=-sw*amp*back;
      legL.knee.rotation.z=-Math.max(0,-sw*back)*amp*1.25-.04;legR.knee.rotation.z=-Math.max(0,sw*back)*amp*1.25-.04;
      upper.position.y=.5+Math.abs(Math.sin(C.phase))*.018*sp+Math.sin(st.t*2.2)*.004;
      /* stance: crouch, slide, airborne tuck, parachute */
      const stc=st.stance||0;C.cr+=((stc===1?1:0)-C.cr)*Math.min(1,dt*10);C.sl+=((stc===2?1:0)-C.sl)*Math.min(1,dt*12);C.air+=((st.air&&!st.para?1:0)-C.air)*Math.min(1,dt*8);
      upper.position.y-=C.cr*.2+C.sl*.3;
      legL.hip.rotation.z+=C.cr*.95+C.sl*1.15+C.air*.5+(st.para?.35:0);legR.hip.rotation.z+=C.cr*.95+C.sl*1.15+C.air*.2+(st.para?.35:0);
      legL.knee.rotation.z-=C.cr*1.5+C.sl*.25+C.air*.8;legR.knee.rotation.z-=C.cr*1.5+C.sl*.25+C.air*.4;
      const lean=st.dash?.35:sp*.07;upper.rotation.z=-lean*back*0+(-lean);
      upper.rotation.z+=C.sl*.8;
      /* gun pose + recoil + reload */
      C.recoil=Math.max(0,C.recoil-dt*7);C.reload+= ((st.reload?1:0)-C.reload)*Math.min(1,dt*9);
      const rc=C.recoil;
      if(C.gun&&C.spec){
        gunMount.position.set(.1-rc*.05-C.reload*.02,.2-C.reload*.1,.075);gunMount.rotation.set(0,0,rc*.09+C.reload*.55);
        const em=st.emote,emU=em?em.t:0,emD=em?em.dur:1,emW=em?Math.min(1,emU*6)*Math.min(1,Math.max(0,(emD-emU)*6)):0;C.emW+=(emW-C.emW)*Math.min(1,dt*20);
        if(em&&em.k==='flex'){gunMount.position.y+=C.emW*.3;gunMount.position.x+=C.emW*.02;gunMount.rotation.z+=C.emW*(.45+Math.sin(emU*7)*.12);}
        if(em&&em.k==='salute'||st.para||(em&&em.k==='wave')){gunMount.position.y-=.05;gunMount.position.z+=C.emW*.02;}
        gunMount.updateMatrix();
        const g=C.spec;
        SR.copy(C.shoulder.r);SL.copy(C.shoulder.l);
        HR.set(g.grip[0],g.grip[1]-.0,g.grip[2]).applyMatrix4(gunMount.matrix);
        const fx=g.fore[0],fy=g.fore[1]-C.reload*.17,fz=g.fore[2];
        HL.set(fx-C.reload*(fx-.02),fy,fz).applyMatrix4(gunMount.matrix);
        if(em){const w=C.emW,u=emU,k=em.k;
          if(k==='salute'){HR.lerp(_t1.set(.1,shoulderY+.19,.075),w);HL.lerp(_t2.set(.02,shoulderY-.28,-.21),w);}
          else if(k==='wave'){HL.lerp(_t2.set(.06,shoulderY+.36+Math.sin(u*10)*.03,-.22+Math.sin(u*9)*.1),w);}
          else if(k==='dance'){HR.lerp(_t1.set(.08,shoulderY+.3+Math.sin(u*9)*.12,.2),w);HL.lerp(_t2.set(.08,shoulderY+.3-Math.sin(u*9)*.12,-.2),w);}
        }
        if(st.para){HR.lerp(_t1.set(.04,shoulderY+.5,.1),.95);HL.lerp(_t2.set(.04,shoulderY+.5,-.1),.95);}
        ik(SR,HR,bendR,ER);ik(SL,HL,bendL,EL);
        placeLimb(armR.up,SR,ER,ARM1);placeLimb(armR.fo,ER,HR,ARM2);armR.hand.position.copy(HR);
        placeLimb(armL.up,SL,EL,ARM1);placeLimb(armL.fo,EL,HL,ARM2);armL.hand.position.copy(HL);
        armR.hand.quaternion.copy(armR.fo.quaternion);armL.hand.quaternion.copy(armL.fo.quaternion);
      }
      {const em=st.emote;
        if(em&&em.k==='backflip'){const u=Math.min(1,em.t/em.dur),ang=u*Math.PI*2,ax=_ax.set(-Math.sin(st.aim),0,Math.cos(st.aim));root.quaternion.setFromAxisAngle(ax,ang);const lift=Math.sin(u*Math.PI)*.8;_pv.set(0,.55,0).applyQuaternion(root.quaternion);root.position.set(st.x-_pv.x,(st.y||0)+lift+.55-_pv.y,st.z-_pv.z);C.flip=1;}
        else if(C.flip){root.quaternion.identity();C.flip=0;}
        if(em&&em.k==='dance'){upper.rotation.y+=Math.sin(em.t*8)*.5*C.emW;upper.position.y+=Math.abs(Math.sin(em.t*9))*.05*C.emW;lower.rotation.y+=Math.sin(em.t*8+1)*.3*C.emW;legL.hip.rotation.z+=Math.sin(em.t*9)*.5*C.emW;legR.hip.rotation.z-=Math.sin(em.t*9)*.5*C.emW;}}
      const a=st.alpha==null?1:st.alpha;
      if(a!==C.alpha){C.alpha=a;const tr=a<.99;for(const m of mats.concat(C.gunMats||[])){m.transparent=tr;m.opacity=a;m.depthWrite=!tr;}}
    };
    C.kick=()=>{C.recoil=1;};
    C.dispose=()=>{root.traverse(o=>{if(o.isMesh)o.geometry.dispose();});for(const m of mats.concat(C.gunMats||[]))m.dispose();};
    return C;
  };
  return M;
})();
