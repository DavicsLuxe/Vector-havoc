/* HAVOC UI layer: crosshair + hit markers + arcade score pops, squad panel, prompts, vehicle HUD, scorestreak, emote wheel,
   minimap v2, mythic kill feed, VectorVibes season pass / lucky draw / artist page, hub squad lobby and lobby themes. */
(()=>{
const I=UI._i,$id=I.$id,fmt=I.fmt,NG=I.NG,items=I.items,rcol=I.rcol,rname=I.rname,show=I.show;
const SQC=['#3ea6ff','#4cd964','#ffd60a','#ff9500'],SQN=['BLUE','GREEN','YELLOW','ORANGE'];
const cl=(v,a,b)=>Math.max(a,Math.min(b,v));
/* settings migration (older saves used Space for ability and V for talk) */
if(S.keys.ability===S.keys.jump)S.keys.ability='KeyQ';
if(S.keys.talk===S.keys.cam)S.keys.talk='KeyT';
saveS();
const season=()=>{const c=G.cfg;return c&&c.seasons?c.seasons[c.activeSeason]:null;};
const sv=()=>G.prof&&G.prof.season||{xp:0,tier:0,into:0,per:1,prem:false,cf:[],cp:[],pity:{n:0,leg:0,myth:0}};
const spotEmbed=u=>{try{const x=new URL(u);if(x.hostname!=='open.spotify.com')return '';const m=x.pathname.match(/^\/(artist|album|track|playlist)\/([A-Za-z0-9]+)/);return m?`https://open.spotify.com/embed/${m[1]}/${m[2]}?utm_source=generator&theme=0`:'';}catch(e){return '';}};
const spotLink=u=>{try{const x=new URL(u);if(x.hostname!=='open.spotify.com')return '';return x.origin+x.pathname;}catch(e){return '';}};

/* =====================================================================================
   CAMERA VIEW
   ===================================================================================== */
const VIEWS={tps:'THIRD PERSON',fps:'FIRST PERSON',top:'TACTICAL VIEW'};
UI.setView=v=>{if(!VIEWS[v])return;if(S.view==='top'&&v!=='top'&&G.state==='play')G.yaw=INP.a;S.view=v;saveS();if(v==='top'&&document.pointerLockElement)document.exitPointerLock();document.body.classList.toggle('cam3',v!=='top');document.body.classList.toggle('cam1',v==='fps');};
UI.cycleView=()=>{if(G.state!=='play')return;const o=['tps','fps','top'];const n=o[(o.indexOf(S.view)+1)%3];UI.setView(n);UI.toast('Camera: '+VIEWS[n]);AUD.play('click');};
$id('hbCam').onclick=UI.cycleView;

/* =====================================================================================
   HIT MARKER + ARCADE SCORE POPS
   ===================================================================================== */
UI.hitMark=kill=>{const h=$id('hm');h.classList.remove('on','kill');void h.offsetWidth;h.classList.add('on');if(kill)h.classList.add('kill');if(S.vib&&navigator.vibrate)try{navigator.vibrate(kill?30:12);}catch(x){}};
let popN=0;
function pop(txt,sub,cls,delay){
  const d=document.createElement('div');d.className='pop '+(cls||'');d.innerHTML=esc(txt)+(sub?`<small>${esc(sub)}</small>`:'');
  d.style.top=(popN++%4)*26+'px';d.style.animationDelay=(delay||0)+'s';$id('pops').appendChild(d);setTimeout(()=>d.remove(),1500+(delay||0)*1000);
  while($id('pops').children.length>8)$id('pops').firstChild.remove();
}
UI.scoreKill=e=>{
  if(e.a!==G.you||e.v===G.you||e.a<=0)return;
  /* the sim is planar, so there are no headshots; bonuses reward skill that the server can actually verify */
  let pts=100,d=0;pop('+100 Elimination','','big',0);
  const bonus=(n,t)=>{pts+=n;pop('+'+n+' '+t,'','',(d+=.12));};
  if(e.sl)bonus(25,'Slide Kill');if(e.ai)bonus(30,'Aerial Kill');if(e.d>700)bonus(40,'Longshot '+Math.round(e.d/32)+'m');
  if(e.kd==='grenade')bonus(20,'Frag Kill');else if(e.kd==='rocket')bonus(25,'Rocket Kill');else if(e.kd==='crush'||e.av)bonus(30,'Roadkill');
  if(e.mk>=2)pop(['','','DOUBLE KILL','TRIPLE KILL','QUAD KILL'][Math.min(4,e.mk)]||(e.mk+' KILL STREAK'),'+'+(e.mk*20)+' MULTI','myth',(d+=.15));
  G.score=(G.score||0)+pts;
};

/* =====================================================================================
   MYTHIC REACTIVE KILL FEED
   ===================================================================================== */
const kf0=UI.killFeed;
UI.killFeed=e=>{
  kf0(e);const f=$id('killfeed'),d=f.firstChild;if(!d||e.a===e.v||e.a<=0)return;
  const r=G.roster.get(e.a),w=G.cfg.weapons[e.w];if(!w)return;
  const it=r&&r.lk&&r.lk.w?items()[r.lk.w[e.w]]:null,myth=it&&it.rarity==='mythic',leg=it&&it.rarity==='legendary';
  const ic=`<span class="wi2">${myth?'<span class="ic2">✦</span>':''}${esc(w.name.toUpperCase())}</span>`;
  d.innerHTML=d.innerHTML.replace(/<small[^>]*>.*?<\/small>/,ic);
  if(myth||(leg&&e.a===G.you)){d.classList.add('myth');if(e.a===G.you)AUD.play('rare');}
};

/* =====================================================================================
   EMOTE WHEEL (works in the lobby and in matches)
   ===================================================================================== */
{const old=$id('wheel');if(old)old.remove();}
const wheel=document.createElement('div');wheel.id='wheel';wheel.style.position='fixed';wheel.style.zIndex=30;document.body.appendChild(wheel);
let wv={x:0,y:0},wHot=null,wCtx='game';
const EM=()=>Object.entries(MD.EMOTES);
function wheelBuild(){
  const list=EM();wheel.innerHTML='<div class="wc"></div><div class="wt">EMOTE</div>'+list.map(([k,d],i)=>{const a=-Math.PI/2+i/list.length*Math.PI*2;return `<div class="wi" data-k="${k}" style="transform:translate(${Math.cos(a)*108}px,${Math.sin(a)*108}px)">${esc(d.n.toUpperCase())}</div>`;}).join('');
  wheel.querySelectorAll('.wi').forEach(b=>{b.onpointerdown=e=>{e.stopPropagation();e.preventDefault();wheelPick(b.dataset.k);};});
}
function wheelHot(k){wHot=k;wheel.querySelectorAll('.wi').forEach(b=>b.classList.toggle('hot',b.dataset.k===k));const t=wheel.querySelector('.wt');if(t)t.textContent=k?MD.EMOTES[k].n.toUpperCase():'EMOTE';}
function wheelPick(k){
  if(!k)return UI.wheelClose();UI.wheelClose();
  if(wCtx==='hub'){R3.hub.emote(k);AUD.play('emote');}
  else if(G.state==='play'&&G.me.al&&!G.me.vh&&!G.me.pa)send({t:'em',k});
}
UI.wheelClose=()=>{wheel.classList.remove('on');IN.wheel=false;wv={x:0,y:0};wheelHot(null);};
UI.wheel=(on,ctx)=>{
  if(!on){if(wheel.classList.contains('on')){const k=wHot;if(ctx==='cancel')UI.wheelClose();else wheelPick(k);}return;}
  if(G.state==='play'&&(!G.me.al||G.me.vh||G.me.pa))return UI.toast('You cannot emote right now');
  if(wheel.classList.contains('on')&&IN.touch){return UI.wheelClose();}
  wCtx=G.state==='play'?'game':'hub';wheelBuild();wheel.classList.add('on');IN.wheel=true;wv={x:0,y:0};wheelHot(null);AUD.play('click');
};
addEventListener('pointermove',e=>{if(!wheel.classList.contains('on'))return;
  if(document.pointerLockElement){wv.x=cl(wv.x+(e.movementX||0),-130,130);wv.y=cl(wv.y+(e.movementY||0),-130,130);}
  else{const r=wheel.getBoundingClientRect();wv.x=e.clientX-(r.left+r.width/2);wv.y=e.clientY-(r.top+r.height/2);}
  if(Math.hypot(wv.x,wv.y)<34){wheelHot(null);return;}
  const list=EM(),a=Math.atan2(wv.y,wv.x)+Math.PI/2,idx=Math.round(((a%(Math.PI*2)+Math.PI*2)%(Math.PI*2))/(Math.PI*2)*list.length)%list.length;wheelHot(list[idx][0]);});
$id('hbEmo').onclick=()=>{UI.wheel(true);};
$id('hEmo').onclick=()=>{if(wheel.classList.contains('on'))UI.wheelClose();else UI.wheel(true);};
document.addEventListener('keydown',e=>{if(e.code==='Escape'&&wheel.classList.contains('on')){UI.wheelClose();}});

/* =====================================================================================
   MINIMAP v2: rotates with the camera, squad colours, vehicles, UAV dots, blinking enemy fire
   ===================================================================================== */
let miniCache=null,miniMap=null;
UI.drawMini=(others,vp,mode)=>{
  if(S.mini===0){$id('mini').style.display='none';return;}$id('mini').style.display='';
  const cvm=$id('mini'),c=cvm.getContext('2d'),R=cvm.width/2,map=G.map,now=performance.now(),rot=mode&&mode!=='top';
  if(miniMap!==map){miniMap=map;const k=3,o=document.createElement('canvas');o.width=map.w*k;o.height=map.h*k;const x=o.getContext('2d');x.fillStyle='#0b1322';x.fillRect(0,0,o.width,o.height);
    for(let ty=0;ty<map.h;ty++)for(let tx=0;tx<map.w;tx++){const ch=map.rows[ty][tx];if(ch==='#'||ch==='X'){x.fillStyle=ch==='#'?'#3d5a96':'#7a6a3a';x.fillRect(tx*k,ty*k,k,k);}else if(ch==='x'){x.fillStyle='#4a4430';x.fillRect(tx*k,ty*k,k,k);}else if(ch==='~'){x.fillStyle='#0d4766';x.fillRect(tx*k,ty*k,k,k);}}miniCache=o;}
  c.clearRect(0,0,cvm.width,cvm.height);c.save();c.beginPath();c.arc(R,R,R-1,0,7);c.clip();c.fillStyle='rgba(5,8,15,.82)';c.fillRect(0,0,cvm.width,cvm.height);
  const yaw=G.yaw||0,view=G.map.br?900:720,sc=R/view;
  c.translate(R,R);if(rot)c.rotate(-Math.PI/2-yaw);c.scale(sc,sc);c.translate(-vp.x,-vp.y);c.imageSmoothingEnabled=false;c.drawImage(miniCache,0,0,map.w*32,map.h*32);
  const b=G.br;if(b){c.strokeStyle='#3da8ff';c.lineWidth=3.5/sc;c.beginPath();c.arc(b.x,b.y,b.r,0,7);c.stroke();c.strokeStyle='#fff';c.lineWidth=1.5/sc;c.beginPath();c.arc(b.nx,b.ny,b.nr,0,7);c.stroke();}
  if(G.map.zones.length&&modeType()==='zone'){const z=G.map.zones[G.zi];if(z){c.strokeStyle='#ffd166';c.lineWidth=2/sc;c.beginPath();c.arc(z.x,z.y,(G.cfg.modes[G.modeId].zoneRadius||96),0,7);c.stroke();}}
  const sqIdx=new Map();for(const m of G.sqd||[])sqIdx.set(m.i,m.si);
  /* vehicles */
  for(const v of G.veh||[]){c.save();c.translate(v.x,v.y);c.rotate(v.a);c.fillStyle=v.k==='heli'?'#d6b8ff':'#ffd166';c.fillRect(-5/sc,-2.5/sc,10/sc,5/sc);c.restore();}
  /* dog tags */
  for(const g of G.tgs||[]){c.fillStyle=SQC[(G.sqd.find(m=>m.i===g.o)||{si:1}).si&3];c.save();c.translate(g.x,g.y);c.rotate(Math.PI/4);c.fillRect(-4/sc*1.6,-4/sc*1.6,8/sc*1.6,8/sc*1.6);c.restore();}
  /* UAV dots */
  if(G.uvp)for(const u of G.uvp){c.fillStyle='rgba(255,77,109,.55)';c.beginPath();c.arc(u.x,u.y,5/sc,0,7);c.fill();}
  /* others */
  for(const [id,e] of others){if(e.f&16)continue;const r=G.roster.get(id),mate=sqIdx.has(id)||(modeIsTeam()&&r&&r.t===G.team);
    c.fillStyle=sqIdx.has(id)?SQC[sqIdx.get(id)&3]:mate?'#8ff0c3':'#ff4d6d';c.beginPath();c.arc(e.x,e.y,(sqIdx.has(id)?6:5)/sc,0,7);c.fill();}
  for(const m of G.sqd||[]){if(m.i===G.you||!m.al||others.has(m.i))continue;c.fillStyle=SQC[m.si&3];c.beginPath();c.arc(m.x,m.y,6/sc,0,7);c.fill();}
  /* enemy gunfire blips: blink red where unsuppressed shots were just fired */
  if(G.blips)for(const [id,bl] of G.blips){const age=now-bl.t;if(age>1400){G.blips.delete(id);continue;}const r=G.roster.get(id);if((sqIdx.has(id))||(modeIsTeam()&&r&&r.t===G.team)||id===G.you)continue;
    const k=age/1400,on=Math.floor(age/140)%2===0;c.strokeStyle=`rgba(255,40,70,${1-k})`;c.lineWidth=2/sc;c.beginPath();c.arc(bl.x,bl.y,(8+k*22)/sc,0,7);c.stroke();if(on){c.fillStyle='#ff1f3d';c.beginPath();c.arc(bl.x,bl.y,6/sc,0,7);c.fill();}}
  c.setTransform(1,0,0,1,0,0);c.translate(R,R);c.rotate(rot?(G.me.a-yaw):(G.me.al?G.me.a:0));if(rot)c.rotate(-Math.PI/2);
  c.fillStyle=G.me.sq>0||G.sqd.length?SQC[(G.me.si|0)&3]:'#19e6ff';c.strokeStyle='#fff';c.lineWidth=1.4;c.beginPath();c.moveTo(9,0);c.lineTo(-6,-6);c.lineTo(-3,0);c.lineTo(-6,6);c.closePath();c.fill();c.stroke();c.restore();
  if(rot){const na=-Math.PI-yaw;c.fillStyle='rgba(255,255,255,.8)';c.font='800 11px Rajdhani,sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText('N',R+Math.cos(na)*(R-10),R+Math.sin(na)*(R-10));}
};

/* =====================================================================================
   HUD UPDATE (called every frame after the base HUD)
   ===================================================================================== */
const hud0=UI.hud;
let xg=8,lastSq='',lastPrompt='',lastDown=0,sqHtml='';
const vehName=k=>(G.cfg.vehicles[k]||{}).name||'Vehicle';
function nearVeh(){const me=G.me;if(me.vh||!me.al||me.pa)return null;let b=null,bd=1e9;for(const v of G.veh||[]){const d=Math.hypot(v.x-me.x,v.y-me.y),reach=v.k==='heli'?60:46;if(d<reach&&d<bd){b=v;bd=d;}}return b;}
UI.hud=(dt,t)=>{
  hud0(dt,t);
  const me=G.me,cfg=G.cfg,view=S.view,th=view!=='top',w=cfg.weapons[me.wid]||{};
  document.body.classList.toggle('cam3',th);document.body.classList.toggle('cam1',view==='fps');
  /* crosshair spread: moving, jumping, sliding, firing widen it; ADS tightens it */
  const spd=Math.hypot(INP.mx,INP.my)*(me.st===1?.5:1),air=(me.z||0)>2,slide=(me.slt||0)>0,fire=performance.now()-(G.lastFire||0)<140;
  const ads=!!INP.ads&&th&&me.al&&!me.vh;
  const tg=ads?2:6+spd*5+(air?13:0)+(slide?9:0)+(INP.fire?5:0)+(me.st===1?-2:0);xg+=(tg-xg)*Math.min(1,dt*14);
  const xh=$id('xh');xh.style.setProperty('--g',xg.toFixed(1)+'px');xh.classList.toggle('ads',ads);
  $id('scope').classList.toggle('on',ads&&view==='fps');
  /* hide the old weapon block while driving, show the vehicle HUD instead */
  $id('hWeap').classList.toggle('hide',!!me.vh);
  const vh=$id('vehHud'),v=me.vh?(G.veh||[]).find(x=>x.i===me.vh):null;
  if(v){vh.classList.add('on');const sp=Math.round(Math.hypot(v.vx||0,v.vy||0)/32*3.6*1.6);vh.innerHTML=`${v.k==='heli'?Math.round(v.z||0)+'<small>ALT M</small>':sp+'<small>KM/H</small>'}<small>${esc(vehName(v.k)).toUpperCase()}</small><div class="vb"><i style="width:${v.h}%"></i></div>`;}else vh.classList.remove('on');
  /* grenades + scorestreak */
  $id('gren').textContent=me.al?'FRAG ×'+(me.gn||0):'';
  const ss=cl((me.ss||0)/100,0,1),rdy=ss>=1&&me.al&&!(me.uv>0);$id('ssBar').firstChild.style.width=ss*100+'%';
  const sb=$id('ssBtn');sb.classList.toggle('rdy',rdy);sb.textContent=me.uv>0?'UAV '+Math.ceil(me.uv)+'s':rdy?'UAV READY [Z]':'UAV '+Math.round(ss*100)+'%';$id('tStreak').classList.toggle('rdy',rdy);
  $id('ssWrap').style.display=me.al?'flex':'none';
  /* swap button label shows the alternate gun */
  const sw=$id('tSwap');if(sw)sw.firstChild.textContent=me.aw?(cfg.weapons[me.aw]||{name:'SWAP'}).name.slice(0,6).toUpperCase():'SWAP';
  /* context prompts: vehicle, dog tags, revival */
  const pm=$id('prompt'),pb=$id('pmBtn'),bar=$id('pmBar');let html='',cls='',bv=0;const nv=nearVeh(),key=kn(S.keys.use);
  if(me.pa){html='PARACHUTE · steer to land';}
  else if(me.vh){html='EXIT '+esc(vehName(v?v.k:'')).toUpperCase()+' ['+key+']';}
  else if(me.tg>0&&me.al){html=(me.sn>0?'SCANNING DOG TAGS…':'HOLD ['+kn(S.keys.revive)+'] · SCAN DOG TAGS TO REVIVE ('+me.tg+')');cls='rev';bv=me.sn||0;}
  else if(nv){html='ENTER '+esc(vehName(nv.k)).toUpperCase()+' ['+key+']';}
  if(!me.al||(G.phase!=='live'))html='';
  const ph=html+'|'+cls;if(ph!==lastPrompt){lastPrompt=ph;pm.classList.toggle('on',!!html&&!me.pa);pb.innerHTML=html;pb.className=cls;}
  bar.classList.toggle('on',bv>0);bar.firstChild.style.width=bv*100+'%';
  $id('tUse').classList.toggle('show',!!nv||!!me.vh);$id('tUse').firstChild.textContent=me.vh?'EXIT':'ENTER';
  $id('tRev').classList.toggle('show',me.tg>0&&me.al);
  pb.onclick=()=>{if(me.tg>0&&!me.vh)return;IN.tu=true;setTimeout(()=>{IN.tu=false;},150);};
  /* revival flight countdown for downed squad mates */
  const rv=(G.sqd||[]).filter(m=>m.rv>0);const rf=$id('rvFlt');
  if(rv.length){rf.classList.add('on');rf.innerHTML=rv.map(m=>`<div style="color:${SQC[m.si&3]}">REVIVAL FLIGHT · ${esc(nm(m.i)).toUpperCase()} · ${Math.ceil(m.rv)}s</div>`).join('');}else rf.classList.remove('on');
  /* squad panel (BR squads) */
  const sq=G.sqd||[];let sh='';
  if(sq.length>1){
    sh=sq.slice().sort((a,b)=>a.si-b.si).map(m=>{const me2=m.i===G.you,st=!m.al?(m.rv>0?'REVIVING':'DOWN'):m.pa?'CHUTE':m.v?'DRIVING':'ACTIVE';
      return `<div class="sqm ${me2?'me':''} ${m.al?'':'dn'}" style="--c:${SQC[m.si&3]}"><div class="nm"><span>${m.si+1} · ${esc(nm(m.i))}${m.b?' <i>BOT</i>':''}</span><i>${st}</i></div><div class="hb2"><b style="width:${m.h}%"></b></div><div class="ar2"><u class="${m.ar>=1?'on':''}"></u><u class="${m.ar>=2?'on':''}"></u><u class="${m.ar>=3?'on':''}"></u></div></div>`;}).join('');
  }
  if(sh!==sqHtml){sqHtml=sh;$id('sqd').innerHTML=sh;}
};
const nm=id=>{const r=G.roster.get(id);return r?r.n:'?';};
const kn=c=>String(c||'').replace('Key','').replace('Arrow','↑').replace('Digit','').replace('ShiftLeft','Shift');
/* tapping prompt/enter buttons: server expects the 'use' input flag via edge triggers, handled by INP.use above */
{const t=$id('pmBtn');t.addEventListener('pointerdown',e=>{e.stopPropagation();});}
$id('ssBtn').onclick=()=>{INP.ssb=true;};

/* wrap enterGame/toHub resets */
const eg0=UI.enterGame;
UI.enterGame=()=>{eg0();G.score=0;G.yaw=G.me.a||0;G.pitch=.12;sqHtml='';lastPrompt='';$id('pops').innerHTML='';UI.wheelClose();document.body.classList.toggle('cam3',S.view!=='top');
  const br=roomIsBR();$id('sqd').style.display=br?'':'none';$id('ssWrap').style.display='flex';
  if(S.view!=='top'&&!IN.touch)UI.toast('Click the game to capture the mouse · V changes camera','good');};

/* =====================================================================================
   HUB: season banner, squad lobby, lobby theme
   ===================================================================================== */
const SQUAD_NAMES=['Tunde','Ngozi','Chidi','Amaka','Emeka','Zainab','Kelechi','Bisi','Femi','Ifeoma','Ola','Yemi','Danjuma','Sade'];
const TAGS=['Ghost','Blaze','Don','Wolf','Storm','Flash','Hawk','Titan'];
let SQUAD=[];try{SQUAD=JSON.parse(localStorage.getItem('hv_squad')||'[]').filter(m=>m&&m.n);}catch(e){}
const saveSq=()=>{try{localStorage.setItem('hv_squad',JSON.stringify(SQUAD));}catch(e){}};
function randMate(){let m,k=0;do{m=randMate1();k++;}while(k<20&&SQUAD.some(x=>x.n===m.n));return m;}
function randMate1(){const cls=Object.entries(G.cfg.classes).filter(([id,c])=>!c.locked);const [op,c]=cls[Math.floor(Math.random()*cls.length)];
  return{n:SQUAD_NAMES[Math.floor(Math.random()*SQUAD_NAMES.length)]+' '+TAGS[Math.floor(Math.random()*TAGS.length)],op,wid:c.primary};}
function renderSquadBar(){
  const bar=$id('squadBar');if(!bar||!G.cfg||!G.prof)return;
  const me=`<div class="sqs me" style="--c:${SQC[0]}"><small>${SQN[0]} · YOU</small>${esc(G.prof.name)}</div>`;
  let h=me;for(let i=0;i<3;i++){const m=SQUAD[i];h+=m?`<div class="sqs" data-rm="${i}" style="--c:${SQC[i+1]}" title="Tap to remove"><small>${SQN[i+1]} · SQUAD BOT</small>${esc(m.n)}</div>`:`<div class="sqs add" data-add="1" style="--c:${SQC[i+1]}"><span><b>+</b>ADD TO SQUAD</span></div>`;}
  bar.innerHTML=h;
  bar.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>{AUD.play('pick');if(SQUAD.length<3)SQUAD.push(randMate());saveSq();renderSquadBar();syncSquad3D();});
  bar.querySelectorAll('[data-rm]').forEach(b=>b.onclick=()=>{SQUAD.splice(+b.dataset.rm,1);saveSq();AUD.play('click');renderSquadBar();syncSquad3D();});
}
function syncSquad3D(){if(R3.ok&&R3.ok()&&R3.hub.squad)R3.hub.squad(SQUAD.filter(m=>G.cfg.classes[m.op]));}
/* lobby theme: auto follows the active season, or a fixed theme, or cycle every 25 s */
const THEME_ORDER=['auto','neon','rust','tokyo','cycle'];let cycleI=0,cycleT=0;
function themeNow(){const m=S.lobby||'auto';if(m==='cycle')return ['neon','rust','tokyo'][cycleI%3];if(m==='auto'){const s=season();return s?s.theme:'neon';}return m;}
function applyTheme(){if(window.LOBBY&&R3.ok&&R3.ok()){LOBBY.set(themeNow());}const b=$id('hTheme');if(b)b.textContent='LOBBY: '+(S.lobby||'auto').toUpperCase();}
$id('hTheme').onclick=()=>{const i=THEME_ORDER.indexOf(S.lobby||'auto');S.lobby=THEME_ORDER[(i+1)%THEME_ORDER.length];saveS();applyTheme();AUD.play('click');UI.toast('Lobby background: '+(S.lobby==='auto'?'follows the season':S.lobby==='cycle'?'cycling':(LOBBY.names[S.lobby])));};
setInterval(()=>{if(G.state!=='hub'||(S.lobby||'auto')!=='cycle')return;cycleT+=1;if(cycleT>=25){cycleT=0;cycleI++;applyTheme();}},1000);
UI.hub2=()=>{
  const s=season();if(s){$id('vvName').textContent=s.name.toUpperCase();$id('vvSub').textContent=(s.presented?'presented by '+s.presented:s.tagline);const k=document.querySelector('#vvBan .vvk');if(k)k.textContent=(s.short||'SEASON').toUpperCase();}
  const pc=G.prof;if(pc){/* tier chip on the banner */const k=document.querySelector('#vvBan .vvk');if(k&&s)k.textContent=(s.short||'SEASON')+' · TIER '+(sv().tier||0);}
  renderSquadBar();applyTheme();
  if(!UI._sqDone&&R3.ok&&R3.ok()&&G.cfg){UI._sqDone=1;syncSquad3D();}
};
const cfgC0=UI.cfgChanged;UI.cfgChanged=()=>{cfgC0();UI.hub2();};

/* =====================================================================================
   SEASON PAGES
   ===================================================================================== */
const rewardLabel=r=>{if(!r)return{t:'—',s:''};if(r.type==='item'){const it=items()[r.item]||{name:'Item',rarity:'common'};return{t:it.name,s:rname(it.rarity),c:rcol(it.rarity),myth:it.rarity==='mythic',leg:it.rarity==='legendary',id:r.item};}return{t:'+'+fmt(r.amount)+' coins',s:'Coins',c:'#ffd166'};};
function heroBlock(s){
  return `<div class="vvhero"><div class="eq">${'<i></i>'.repeat(9)}</div><div class="by">${esc((s.presented?'PRESENTED BY ':'')+(s.presented||'').toUpperCase())}</div><h3>${esc(s.name.toUpperCase())}</h3><p>${esc(s.tagline||'')}</p>${s.artist?`<p style="color:#fff">${esc(s.artist.blurb||'')}</p>`:''}</div>`;
}
function pSeason(body){
  const s=season();if(!s){body.innerHTML='<div class="note">No season is running right now.</div>';return;}
  const tab=I.tab;
  if(tab==='pass')sPass(body,s);else if(tab==='crate')sCrate(body,s);else sVibes(body,s);
}
function sPass(body,s){
  const P=s.pass,v=sv(),pct=v.tier>=P.tiers?100:Math.round(v.into/v.per*100);
  body.innerHTML=heroBlock(s)+`<div class="row" style="justify-content:space-between"><div><div class="sec" style="margin:0">YOUR PROGRESS</div><b style="font:900 28px var(--fd)">TIER ${v.tier}<small style="font:700 14px var(--fh);color:var(--mut)"> / ${P.tiers}</small></b></div>${v.prem?'<span class="own" style="color:#ff5af0;font:800 16px var(--fh);letter-spacing:.14em">PREMIUM ✦ ACTIVE</span>':`<button class="btn gold" id="buyPass">UNLOCK PREMIUM · ${NG(P.premiumNaira)}</button>`}</div>
  <div class="pbar"><i style="width:${pct}%"></i></div><div class="note">Earn ${P.xpPerTier} season XP per tier by playing matches (kills, wins and time all count, ${(G.cfg.match&&G.cfg.match.seasonXpMul)||1.5}× season boost). Free rewards are open to everyone. The premium track has the mythic ${esc(s.name)} weapons and skins. Premium is bought by bank transfer and approved by the ${esc(G.cfg.brand.studio)} team.</div><div id="tiers"></div>`;
  if($id('buyPass'))$id('buyPass').onclick=()=>I.payModal({kind:'pass',ref:s.id,label:'Season Pass: '+s.name,naira:P.premiumNaira});
  const T=$id('tiers');let h='';
  for(let i=1;i<=P.tiers;i++){
    const f=rewardLabel(P.free[i-1]),p=rewardLabel(P.premium[i-1]),reached=v.tier>=i,fg=(v.cf||[]).includes(i),pg=(v.cp||[]).includes(i);
    const cell=(r,got,track,prem)=>`<div class="pcell ${prem?'prem':''} ${reached&&(!prem||v.prem)?'':'lk'} ${got?'got':''} ${r.myth?'myth':''}" ${r.id?`data-pv="${esc(r.id)}"`:''}><small style="color:${r.c||'var(--mut)'}">${esc(r.s)}${prem?' · PREMIUM':''}</small><b>${esc(r.t)}</b>${reached&&!got&&(!prem||v.prem)?`<button class="btn sm cl" data-cl="${i}:${track}">CLAIM</button>`:''}</div>`;
    h+=`<div class="ptier ${v.tier+1===i?'now':''}"><div class="tn">${i}</div>${cell(f,fg,'free',false)}${cell(p,pg,'premium',true)}</div>`;
  }
  T.innerHTML=h;
  T.querySelectorAll('[data-cl]').forEach(b=>b.onclick=e=>{e.stopPropagation();const [t,k]=b.dataset.cl.split(':');send({t:'sclaim',tier:+t,track:k});b.disabled=true;});
  T.querySelectorAll('[data-pv]').forEach(c=>c.onclick=()=>{I.previewItem(c.dataset.pv);});
}
UI.sclaimOk=m=>{UI.toast(m.msg||'Reward claimed','good');if(items()&&m.msg&&/Unlocked/.test(m.msg))R3.hub.reveal();if(I.page==='season')I.renderPage(true);};
/* ---- lucky draw ---- */
let drawing=false;
function sCrate(body,s){
  const L=G.cfg.lucky,D=s.draw,v=sv(),tot=Object.values(L.odds).reduce((a,b)=>a+b,0)||1,pool=Object.entries(items()).filter(([id,it])=>it.season===s.id&&!it.exclusive);
  const P=G.prof;
  body.innerHTML=heroBlock(s)+`<div class="crate" id="crate"><div class="cbox"><i style="transform:translateZ(0)"></i></div></div>
  <div class="row"><button class="btn gold" id="d1" style="flex:1" ${P&&P.coins<D.cost?'disabled':''}>DRAW ×1 · <span class="coin" style="display:inline-block;width:14px;height:14px;vertical-align:-2px"></span> ${fmt(D.cost)}</button><button class="btn" id="d10" style="flex:1" ${P&&P.coins<D.cost10?'disabled':''}>DRAW ×10 · <span class="coin" style="display:inline-block;width:14px;height:14px;vertical-align:-2px"></span> ${fmt(D.cost10)}</button></div>
  <div class="sec">DROP RATES (PER DRAW)</div><div class="odds">${Object.keys(L.odds).map(k=>`<div style="color:${rcol(k)}"><small>${esc(rname(k)).toUpperCase()}</small>${(L.odds[k]/tot*100).toFixed(L.odds[k]/tot<.1?1:0)}%</div>`).join('')}</div>
  <div class="note"><b>Fair play:</b> draws use <b>coins only</b>, never real money, and the rates above are what the server really uses. Pity: a <b>Mythic</b> is guaranteed within ${L.pity.mythic} draws (${Math.max(0,L.pity.mythic-(v.pity?v.pity.myth:0))} left) and a <b>Legendary</b> within ${L.pity.legendary} (${Math.max(0,L.pity.legendary-(v.pity?v.pity.leg:0))} left). Duplicates refund ${Math.round(L.dupRefund*100)}% of the item's value in coins. Need coins? <a href="#" id="getC" style="color:var(--a)">Get coins</a>.</div>
  <div id="reel" class="reel"></div>
  <div class="sec">WHAT CAN DROP (${pool.length} ITEMS)</div><div class="grid" id="pool">${pool.sort((a,b)=>Object.keys(L.odds).indexOf(b[1].rarity)-Object.keys(L.odds).indexOf(a[1].rarity)).map(([id,it])=>`<div class="card ${I.owns(id)?'':'lock'}" data-pv="${esc(id)}"><span class="rar" style="background:${rcol(it.rarity)}"></span><div class="rt" style="color:${rcol(it.rarity)}">${esc(rname(it.rarity))}</div><h4>${esc(it.name)}</h4><p>${I.owns(id)?'OWNED':esc(it.desc||'')}</p></div>`).join('')}</div>`;
  $id('d1').onclick=()=>doDraw(1);$id('d10').onclick=()=>doDraw(10);$id('getC').onclick=e=>{e.preventDefault();I.openPage('store','coins');};
  $id('pool').querySelectorAll('[data-pv]').forEach(c=>c.onclick=()=>I.previewItem(c.dataset.pv));
}
function doDraw(n){if(drawing)return;drawing=true;$id('d1').disabled=$id('d10').disabled=true;$id('crate').classList.add('shake');AUD.play('crate');setTimeout(()=>AUD.play('crate'),500);send({t:'draw',n});setTimeout(()=>{if(drawing){drawing=false;$id('crate')&&$id('crate').classList.remove('shake');}},9000);}
UI.drawOk=m=>{
  const go=()=>{drawing=false;const cr=$id('crate');if(cr)cr.classList.remove('shake');const rl=$id('reel');if(!rl){if(m.res)UI.toast('Draw complete','good');return;}
    const best=m.res.some(r=>r.rarity==='mythic')?'mythic':m.res.some(r=>r.rarity==='legendary')?'legendary':'';
    rl.innerHTML=m.res.map((r,i)=>{const it=items()[r.id]||{name:r.id,rarity:r.rarity};return `<div class="rcard ${r.rarity==='mythic'?'myth':''}" style="--c:${rcol(r.rarity)};animation-delay:${i*.12}s"><small>${esc(rname(r.rarity)).toUpperCase()}</small><b>${esc(it.name)}</b>${r.dup?`<small style="color:var(--mut)">DUPLICATE +${r.coins} coins</small>`:'<small style="color:var(--grn)">NEW</small>'}</div>`;}).join('');
    if(best==='mythic'){AUD.play('mythic');const f=document.createElement('div');f.className='flash';document.body.appendChild(f);setTimeout(()=>f.remove(),1200);R3.hub.reveal();}else if(best==='legendary'){AUD.play('reveal');R3.hub.reveal();}else AUD.play('rare');
    if(I.page==='season'&&I.tab==='crate'){const top=$id('pgBody').scrollTop;const keep=rl.innerHTML;I.renderPage(true);const r2=$id('reel');if(r2)r2.innerHTML=keep;$id('pgBody').scrollTop=top;}};
  setTimeout(go,1100);
};
/* ---- VectorVibes artist page ---- */
function sVibes(body,s){
  const a=s.artist||{},link=spotLink(a.spotify||''),emb=spotEmbed(a.spotify||'');
  const myth=Object.entries(items()).filter(([id,it])=>it.season===s.id&&(it.rarity==='mythic'||it.rarity==='legendary'));
  body.innerHTML=heroBlock(s)+`<div class="row" style="margin:6px 0">${link?`<a class="btn" href="${esc(link)}" target="_blank" rel="noopener noreferrer" style="text-decoration:none">▶ OPEN ${esc((a.name||'ARTIST').toUpperCase())} ON SPOTIFY</a>`:''}${emb?'<button class="btn ghost" id="vvLoad">LOAD PLAYER HERE</button>':''}</div><div id="spf"></div>
  <div class="note">The in-game player loads from Spotify only when you tap it, so the game stays fast and offline-friendly. Music plays from Spotify's own servers.</div>
  <div class="sec">${esc((s.short||'Season').toUpperCase())} MYTHICS & LEGENDARIES</div><div class="grid">${myth.map(([id,it])=>`<div class="card ${I.owns(id)?'':'lock'}" data-pv="${esc(id)}"><span class="rar" style="background:${rcol(it.rarity)}"></span><div class="rt" style="color:${rcol(it.rarity)}">${esc(rname(it.rarity))}</div><h4>${esc(it.name)}</h4><p>${esc(it.desc||'')}</p></div>`).join('')}</div>`;
  if($id('vvLoad'))$id('vvLoad').onclick=()=>{$id('spf').innerHTML=`<div class="spf"><iframe src="${esc(emb)}" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy" title="Spotify"></iframe></div>`;$id('vvLoad').remove();};
  body.querySelectorAll('[data-pv]').forEach(c=>c.onclick=()=>{I.previewItem(c.dataset.pv);const it=items()[c.dataset.pv];if(it)UI.toast(it.name+(I.owns(c.dataset.pv)?' (owned)':' · preview'));});
}
I.PAGEFN.season=pSeason;
/* the season page title and tab refresh when the profile changes */
const pc0=UI.profChanged;UI.profChanged=m=>{pc0(m);UI.hub2();};

/* keep the base 'how' tab list in sync */
UI.hub2();
})();
