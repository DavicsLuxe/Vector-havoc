/* Seasonal lobby backgrounds, 100% procedural: Neon Horizon (synthwave + lasers), Rust & Dust (sandstorm, haze, embers), Tokyo Escape (blossoms, neon billboards). */
(()=>{
const T=THREE,TAU=Math.PI*2;
const rngf=s=>()=>((s=(s*1664525+1013904223)>>>0)/4294967296);
const tex=(w,h,fn)=>{const c=document.createElement('canvas');c.width=w;c.height=h;fn(c.getContext('2d'),w,h);const t=new T.CanvasTexture(c);t.anisotropy=4;return t;};
const dot=tex(32,32,(x,w)=>{const g=x.createRadialGradient(16,16,0,16,16,16);g.addColorStop(0,'#fff');g.addColorStop(.5,'rgba(255,255,255,.6)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,w,w);});
const petalTex=tex(32,32,(x)=>{x.translate(16,16);x.rotate(.6);const g=x.createRadialGradient(0,0,1,0,0,12);g.addColorStop(0,'#fff6fa');g.addColorStop(1,'#ff9fc4');x.fillStyle=g;x.beginPath();x.ellipse(0,0,6,11,0,0,TAU);x.fill();x.fillStyle='rgba(255,255,255,.55)';x.beginPath();x.moveTo(-1,-10);x.lineTo(1,-10);x.lineTo(0,-5);x.fill();});
const skyMat=(top,mid,bot)=>new T.ShaderMaterial({side:T.BackSide,depthWrite:false,fog:false,uniforms:{t:{value:new T.Color(top)},m:{value:new T.Color(mid)},b:{value:new T.Color(bot)}},
  vertexShader:'varying vec3 p;void main(){p=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:'uniform vec3 t,m,b;varying vec3 p;void main(){float h=p.y;vec3 c=h>0.?mix(m,t,pow(clamp(h*1.6,0.,1.),.7)):mix(m,b,clamp(-h*3.,0.,1.));gl_FragColor=vec4(c,1.);}'});
const points=(n,size,col,map,blend=true)=>{const g=new T.BufferGeometry();g.setAttribute('position',new T.BufferAttribute(new Float32Array(n*3),3));const o=new T.Points(g,new T.PointsMaterial({size,color:col,map,transparent:true,depthWrite:false,blending:blend?T.AdditiveBlending:T.NormalBlending,sizeAttenuation:true,fog:false}));o.frustumCulled=false;return o;};
const disposeG=g=>g.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.material){(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{if(m.map&&m.map!==dot&&m.map!==petalTex)m.map.dispose();m.dispose();});}});

/* ---------- Neon Horizon ---------- */
function neon(H){
  const g=new T.Group(),R=rngf(7);
  g.add(new T.Mesh(new T.SphereGeometry(90,24,16),skyMat('#0b0224','#c21e8a','#12062a')));
  /* striped sun */
  const sun=new T.Mesh(new T.CircleGeometry(9,48),new T.ShaderMaterial({transparent:true,depthWrite:false,fog:false,uniforms:{t:{value:0}},
    vertexShader:'varying vec2 u;void main(){u=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader:'varying vec2 u;uniform float t;void main(){float y=u.y;vec3 c=mix(vec3(1.,.85,.2),vec3(1.,.1,.55),smoothstep(.35,.9,1.-y));float k=fract(y*14.-t*.08);float cut=step(.0,.62-y)*step(k,.18+(.62-y)*.5);if(cut>.5)discard;float d=length(u-.5)*2.;gl_FragColor=vec4(c,smoothstep(1.,.96,d));}'}));
  sun.position.set(0,6.5,-42);g.add(sun);
  /* wire mountains */
  const mt=new T.Group();for(let i=0;i<22;i++){const x=-60+i*5.6+(R()-.5)*2,h=3+R()*7;const m=new T.Mesh(new T.ConeGeometry(3.2+R()*2,h,4),new T.MeshBasicMaterial({color:'#2a0a52',fog:false}));m.position.set(x,h/2-.2,-36-R()*5);mt.add(m);
    const e=new T.LineSegments(new T.EdgesGeometry(m.geometry),new T.LineBasicMaterial({color:'#ff2fa8',fog:false}));e.position.copy(m.position);mt.add(e);}g.add(mt);
  /* scrolling grid floor */
  const gm=new T.ShaderMaterial({transparent:true,depthWrite:false,uniforms:{t:{value:0}},
    vertexShader:'varying vec2 p;void main(){p=position.xy;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader:'varying vec2 p;uniform float t;void main(){vec2 q=vec2(p.x,p.y+t*3.)/2.;vec2 w=abs(fract(q-.5)-.5)/fwidth(q);float l=1.-min(min(w.x,w.y),1.);float d=length(p)/70.;vec3 c=mix(vec3(.1,.9,1.),vec3(1.,.15,.65),clamp(abs(p.x)/40.,0.,1.));gl_FragColor=vec4(c*l*1.5,l*(1.-d)*.9);}'});
  gm.extensions={derivatives:true};
  const grid=new T.Mesh(new T.PlaneGeometry(140,140),gm);grid.rotation.x=-Math.PI/2;grid.position.y=-.02;g.add(grid);
  /* laser grid: sweeping beams from above and behind */
  const beams=[];for(let i=0;i<12;i++){const col=i%2?'#19e6ff':'#ff2fa8',m=new T.Mesh(new T.CylinderGeometry(.018,.018,60,6,1,true),new T.MeshBasicMaterial({color:col,transparent:true,opacity:.7,blending:T.AdditiveBlending,depthWrite:false,fog:false}));
    const piv=new T.Group();piv.position.set(-9+i*1.65,9,-12-(i%3)*2);m.position.y=-30;piv.add(m);g.add(piv);beams.push({piv,k:i});}
  const ring=[];for(let i=0;i<3;i++){const r=new T.Mesh(new T.TorusGeometry(5+i*2.4,.02,6,96),new T.MeshBasicMaterial({color:i%2?'#19e6ff':'#ff2fa8',transparent:true,opacity:.55,blending:T.AdditiveBlending,fog:false}));r.position.set(0,2.5,-18);g.add(r);ring.push(r);}
  const stars=points(260,.18,'#ffffff',dot);const sp=stars.geometry.attributes.position;for(let i=0;i<260;i++){const a=R()*TAU,e=.1+R()*1.1;sp.setXYZ(i,Math.cos(a)*70*Math.cos(e),Math.sin(e)*60+4,Math.sin(a)*70*Math.cos(e)-30);}g.add(stars);
  H.scene.add(g);
  const prev={bg:H.scene.background,fog:H.scene.fog};H.scene.background=new T.Color('#0b0224');H.scene.fog=new T.Fog('#2a0a52',16,70);
  const L=H.lights;L.rim.color.set('#19e6ff');L.rim2.color.set('#ff2fa8');L.key.color.set('#ffd8f4');
  return{g,upd(dt,t){gm.uniforms.t.value=t;sun.material.uniforms.t.value=t;beams.forEach(b=>{b.piv.rotation.z=Math.sin(t*.7+b.k*.9)*.9;b.piv.rotation.x=Math.cos(t*.5+b.k)*.35;});ring.forEach((r,i)=>{r.rotation.x=t*.2*(i+1);r.rotation.y=t*.15*(3-i);});},
    done(){H.scene.background=prev.bg;H.scene.fog=prev.fog;}};
}
/* ---------- Rust & Dust ---------- */
function rust(H){
  const g=new T.Group(),R=rngf(11);
  g.add(new T.Mesh(new T.SphereGeometry(90,24,16),skyMat('#4a2410','#e0833a','#3a1d0e')));
  const sun=new T.Mesh(new T.CircleGeometry(7,40),new T.MeshBasicMaterial({color:'#ffb066',transparent:true,opacity:.75,depthWrite:false,fog:false}));sun.position.set(14,9,-46);g.add(sun);
  /* dunes */
  const pg=new T.PlaneGeometry(160,160,100,100);pg.rotateX(-Math.PI/2);const ps=pg.attributes.position;
  for(let i=0;i<ps.count;i++){const x=ps.getX(i),z=ps.getZ(i);const d=Math.hypot(x+1.1,z)||1,flat=Math.min(1,Math.max(0,(d-3.2)/6));ps.setY(i,(Math.sin(x*.19+z*.07)*1.1+Math.sin(x*.07-z*.16)*1.6+Math.sin(x*.5+z*.4)*.12)*flat*(.35+Math.min(1,Math.abs(z)/40)) - 0.05);}
  pg.computeVertexNormals();g.add(new T.Mesh(pg,new T.MeshStandardMaterial({color:'#b5763a',roughness:1,metalness:0,flatShading:true})));
  /* ruined pylons, wrecks, broken walls */
  const rustM=new T.MeshStandardMaterial({color:'#5a3320',roughness:.9,metalness:.5,flatShading:true});
  for(let i=0;i<26;i++){const a=R()*TAU,r=10+R()*34,h=2+R()*9,w=.8+R()*1.8;const b=new T.Mesh(new T.BoxGeometry(w,h,w*(.6+R())),rustM);b.position.set(Math.cos(a)*r,h/2-.6,Math.sin(a)*r-8);b.rotation.set((R()-.5)*.3,R()*TAU,(R()-.5)*.35);g.add(b);}
  /* half-buried wreck: tilted fuselage with ribs */
  const wr=new T.Group();const body=new T.Mesh(new T.CylinderGeometry(1.1,1.1,7,10,1,true),new T.MeshStandardMaterial({color:'#6b3a22',roughness:.8,metalness:.6,side:T.DoubleSide,flatShading:true}));body.rotation.z=Math.PI/2;wr.add(body);
  for(let i=0;i<6;i++){const rib=new T.Mesh(new T.TorusGeometry(1.1,.05,5,12),rustM);rib.rotation.y=Math.PI/2;rib.position.x=-3+i*1.2;wr.add(rib);}wr.position.set(7,.1,-9);wr.rotation.set(.1,.5,-.2);g.add(wr);
  /* sandstorm: fast particles + drifting haze sheets */
  const N=900,sand=points(N,.07,'#e8c48a',dot,false);const sa=sand.geometry.attributes.position;const sv=new Float32Array(N);
  for(let i=0;i<N;i++){sa.setXYZ(i,(R()-.5)*34,R()*6,(R()-.5)*20-2);sv[i]=2.5+R()*5;}g.add(sand);
  const hz=tex(256,256,(x,w,h)=>{const r=rngf(5);for(let i=0;i<90;i++){const gr=x.createRadialGradient(r()*w,r()*h,0,0,0,1);const cx=r()*w,cy=r()*h,rad=20+r()*70;const gg=x.createRadialGradient(cx,cy,0,cx,cy,rad);gg.addColorStop(0,'rgba(255,200,140,.18)');gg.addColorStop(1,'rgba(255,200,140,0)');x.fillStyle=gg;x.fillRect(0,0,w,h);}});hz.wrapS=T.RepeatWrapping;
  const sheets=[];for(let i=0;i<5;i++){const m=new T.Mesh(new T.PlaneGeometry(34,9),new T.MeshBasicMaterial({map:hz,transparent:true,opacity:.55,depthWrite:false,fog:false}));m.position.set(-6+i*3,3.2,-2-i*2.2);g.add(m);sheets.push({m,s:.5+i*.25});}
  /* embers */
  const E=160,emb=points(E,.09,'#ff8a2a',dot);const ea=emb.geometry.attributes.position,ev=[];for(let i=0;i<E;i++){ea.setXYZ(i,(R()-.5)*12,R()*5,(R()-.5)*8-1);ev.push({s:.4+R()*.9,w:R()*TAU});}g.add(emb);
  H.scene.add(g);
  const prev={bg:H.scene.background,fog:H.scene.fog};H.scene.background=new T.Color('#4a2410');H.scene.fog=new T.Fog('#9a5a2a',5,40);
  const L=H.lights;L.rim.color.set('#ff7a2a');L.rim2.color.set('#ffb25c');L.key.color.set('#ffd9a0');
  return{g,upd(dt,t){for(let i=0;i<N;i++){let x=sa.getX(i)+sv[i]*dt;if(x>17)x=-17;sa.setX(i,x);sa.setY(i,sa.getY(i)+Math.sin(t*2+i)*.002);}sa.needsUpdate=true;
      sheets.forEach(s=>{s.m.position.x+=s.s*dt;if(s.m.position.x>22)s.m.position.x=-22;s.m.material.opacity=.4+.2*Math.sin(t*.7+s.s*5);});
      for(let i=0;i<E;i++){let y=ea.getY(i)+ev[i].s*dt;if(y>6)y=0;ea.setXYZ(i,ea.getX(i)+Math.sin(t*.9+ev[i].w)*dt*.35+dt*.4,y,ea.getZ(i));}ea.needsUpdate=true;emb.material.opacity=.7+.3*Math.sin(t*9);},
    done(){H.scene.background=prev.bg;H.scene.fog=prev.fog;}};
}
/* ---------- Tokyo Escape ---------- */
function tokyo(H){
  const g=new T.Group(),R=rngf(23);
  g.add(new T.Mesh(new T.SphereGeometry(90,24,16),skyMat('#07061c','#4a1b6e','#0a0818')));
  const moon=new T.Mesh(new T.CircleGeometry(2.6,32),new T.MeshBasicMaterial({color:'#ffe9f2',fog:false}));moon.position.set(-14,17,-55);g.add(moon);
  /* wet street */
  const st=new T.Mesh(new T.PlaneGeometry(120,120),new T.MeshStandardMaterial({color:'#0b0b18',roughness:.18,metalness:.75}));st.rotation.x=-Math.PI/2;st.position.y=-.01;g.add(st);
  /* neon billboard textures */
  const sign=(txt,fg,bg,w=512,h=192,font='900 96px Orbitron, Rajdhani, sans-serif')=>tex(w,h,(x,W,Hh)=>{x.fillStyle=bg;x.fillRect(0,0,W,Hh);x.strokeStyle=fg;x.lineWidth=8;x.strokeRect(10,10,W-20,Hh-20);x.shadowColor=fg;x.shadowBlur=22;x.fillStyle='#fff';x.font=font;x.textAlign='center';x.textBaseline='middle';x.fillText(txt,W/2,Hh/2+4);x.shadowBlur=0;});
  const SIGNS=[['VECTOR HAVOC','#19e6ff','#04202c'],['ヴェクター','#ff2fa8','#2a0620'],['ラーメン','#ffd166','#2a1c04'],['VECTORVIBES','#c07bff','#1a0830'],['夜明け','#8ff0c3','#04241a'],['東京','#ff7a2a','#2a1004'],['NEON 24H','#ff2f5a','#2a0610']];
  const bills=[];
  /* skyline with lit windows */
  const win=tex(64,128,(x,w,h)=>{x.fillStyle='#0a0a1c';x.fillRect(0,0,w,h);const r=rngf(3);for(let j=0;j<14;j++)for(let i=0;i<5;i++)if(r()<.55){x.fillStyle=r()<.7?'rgba(255,214,140,.9)':r()<.5?'rgba(255,90,170,.9)':'rgba(110,220,255,.9)';x.fillRect(4+i*12,5+j*9,7,5);}});win.wrapS=win.wrapT=T.RepeatWrapping;
  for(let i=0;i<46;i++){const side=i%2?1:-1,z=-8-(i>>1)*1.9-R()*2,x=side*(6+R()*5+(i%5)),h=6+R()*22,w=2.4+R()*2.6;const m=new T.Mesh(new T.BoxGeometry(w,h,w),new T.MeshStandardMaterial({map:win,emissiveMap:win,emissive:'#ffffff',emissiveIntensity:.9,roughness:.8,color:'#8a8aa8'}));m.material.map=win.clone();m.material.map.repeat.set(w/3,h/9);m.material.map.needsUpdate=true;m.material.emissiveMap=m.material.map;m.position.set(x,h/2,z);g.add(m);
    if(i%4===0){const sd=SIGNS[(i/4|0)%SIGNS.length],sm=new T.Mesh(new T.PlaneGeometry(3.4,1.3),new T.MeshBasicMaterial({map:sign(sd[0],sd[1],sd[2]),toneMapped:false,fog:false}));sm.position.set(x-side*(w/2+.02),2.8+R()*8,z+(R()-.5));sm.rotation.y=-side*Math.PI/2;g.add(sm);bills.push({sm,p:R()*TAU,o:R()<.3});}}
  /* hero billboard over the street */
  const hero=new T.Mesh(new T.PlaneGeometry(9,3.4),new T.MeshBasicMaterial({map:sign('VECTORVIBES · SEASON 1','#ff2fa8','#16061c',1024,384,'900 92px Orbitron, Rajdhani, sans-serif'),toneMapped:false,fog:false}));hero.position.set(1.8,7.2,-20);g.add(hero);bills.push({sm:hero,p:0,o:false});
  /* torii gate */
  const red=new T.MeshStandardMaterial({color:'#d9232d',roughness:.5,emissive:'#6a0a10',emissiveIntensity:.6});
  const tg=new T.Group();for(const x of[-2.4,2.4]){const p=new T.Mesh(new T.CylinderGeometry(.2,.24,6.2,12),red);p.position.set(x,3.1,0);tg.add(p);}
  const k1=new T.Mesh(new T.BoxGeometry(7.6,.34,.42),red);k1.position.y=5.7;tg.add(k1);const k2=new T.Mesh(new T.BoxGeometry(5.8,.22,.3),red);k2.position.y=4.6;tg.add(k2);
  const cap=new T.Mesh(new T.BoxGeometry(8.4,.2,.6),new T.MeshStandardMaterial({color:'#1a1020',roughness:.7}));cap.position.y=6.0;tg.add(cap);tg.position.set(2.2,0,-7);g.add(tg);
  /* lanterns */
  const lan=[];for(let i=0;i<9;i++){const l=new T.Group();const b=new T.Mesh(new T.SphereGeometry(.2,14,10),new T.MeshBasicMaterial({color:i%2?'#ff5a3a':'#ffb35c',fog:false}));b.scale.y=1.25;l.add(b);const s=new T.Mesh(new T.CylinderGeometry(.004,.004,2.5,3),new T.MeshBasicMaterial({color:'#222'}));s.position.y=1.35;l.add(s);l.position.set(-5+i*1.35,3.2+Math.sin(i*2)*.5,-3.5-(i%3)*.8);g.add(l);lan.push(l);const pl=new T.Sprite(new T.SpriteMaterial({map:dot,color:i%2?'#ff5a3a':'#ffb35c',blending:T.AdditiveBlending,depthWrite:false,fog:false}));pl.scale.set(1.1,1.1,1);l.add(pl);}
  /* cherry blossoms */
  const N=520,pet=points(N,.2,'#ffffff',petalTex,false);pet.material.alphaTest=.2;const pa=pet.geometry.attributes.position,pv=[];
  for(let i=0;i<N;i++){pa.setXYZ(i,(R()-.5)*20,R()*9,(R()-.5)*14-2);pv.push({f:.35+R()*.7,s:R()*TAU,sw:.4+R()*.9});}g.add(pet);
  /* blossom tree: dark trunk + pink clouds */
  const tr=new T.Group();const trunk=new T.Mesh(new T.CylinderGeometry(.16,.3,3.2,8),new T.MeshStandardMaterial({color:'#2a1810',roughness:1}));trunk.position.y=1.6;tr.add(trunk);
  for(let i=0;i<14;i++){const c=new T.Mesh(new T.IcosahedronGeometry(.9+R()*.7,1),new T.MeshStandardMaterial({color:'#ffb0cc',emissive:'#ff5f9a',emissiveIntensity:.35,roughness:.9,flatShading:true}));c.position.set((R()-.5)*3.4,3.2+R()*1.8,(R()-.5)*2.4);tr.add(c);}
  tr.position.set(-6.2,0,-4.5);g.add(tr);
  const pl1=new T.PointLight('#ff3fa8',22,16,1.6);pl1.position.set(-3,3,-3);const pl2=new T.PointLight('#3f8cff',18,16,1.6);pl2.position.set(4,3,-4);g.add(pl1,pl2);
  H.scene.add(g);
  const prev={bg:H.scene.background,fog:H.scene.fog};H.scene.background=new T.Color('#07061c');H.scene.fog=new T.Fog('#1a1038',14,70);
  const L=H.lights;L.rim.color.set('#ff6fb0');L.rim2.color.set('#5fa8ff');L.key.color.set('#ffe9f4');
  return{g,upd(dt,t){for(let i=0;i<N;i++){const v=pv[i];let y=pa.getY(i)-v.f*dt;let x=pa.getX(i)+Math.sin(t*v.sw+v.s)*dt*.7+dt*.25;if(y<0){y=9;x=(Math.random()-.5)*20;}if(x>10)x=-10;pa.setXYZ(i,x,y,pa.getZ(i)+Math.cos(t*v.sw+v.s)*dt*.3);}pa.needsUpdate=true;
      bills.forEach(b=>{b.sm.material.color.setScalar(b.o?(Math.sin(t*13+b.p)>.2?1:.35):.85+.15*Math.sin(t*2+b.p));});lan.forEach((l,i)=>{l.rotation.z=Math.sin(t*.9+i)*.05;});},
    done(){H.scene.background=prev.bg;H.scene.fog=prev.fog;}};
}
const THEMES={neon,rust,tokyo};
const LOBBY={names:{neon:'Neon Horizon',rust:'Rust & Dust',tokyo:'Tokyo Escape'},cur:'',inst:null,
  set(name){const R=typeof R3!=='undefined'?R3:null;if(!R||!R.ok()||!R.hub.internals)return;const H=R.hub.internals();if(!H||!H.scene)return;if(!THEMES[name])name='';if(name===LOBBY.cur)return;
    if(LOBBY.inst){LOBBY.inst.done();H.scene.remove(LOBBY.inst.g);disposeG(LOBBY.inst.g);LOBBY.inst=null;H.themeUpd=null;}
    LOBBY.cur=name;const base=!name;if(H.sky)H.sky.visible=base;if(H.fl)H.fl.visible=base||name==='';
    if(name){LOBBY.inst=THEMES[name](H);H.themeUpd=LOBBY.inst.upd;if(H.fl)H.fl.visible=false;}
    else{H.lights.rim.color.set('#19e6ff');H.lights.rim2.color.set('#ff3d9a');H.lights.key.color.set('#ffe2b8');}}};
window.LOBBY=LOBBY;
})();
