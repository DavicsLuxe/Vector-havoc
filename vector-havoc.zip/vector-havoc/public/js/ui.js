/* UI: intro, hub, store, loadout, daily, settings, HUD, scoreboard, chat, end screen. */
(()=>{
const SEL=Object.assign({mode:'tdm',map:'',diff:'normal',tab:'online'},store.get('vb_sel',{}));
const saveSel=()=>store.set('vb_sel',SEL);
S.aimMode=S.aimMode||'point';
const fmt=n=>(+n||0).toLocaleString('en-NG');
const NG=n=>'₦'+fmt(n);
const TIPS=['Fog of war is real. Cut the lights and flank the grid.','Reload behind cover. Oga, no dey reload for open ground.','Teammates can hear you on voice. Enemies only up close.','Tap FIRE to shoot. Swipe the right side to aim.','In Battle Royale, loot first, then stay inside the grid.','Daily rewards stack up. Day 20 and day 40 are exclusive.','Legendary and mythic skins make your soldier shine.','Practice mode bots play fair. Learn the maps there.','Use your ability. A good dash saves your life.','Check Settings to move buttons wherever you like.'];
const SUGG=['Oga Sniper','Lagos Boy','Naija Ghost','Mama Put','Eko Flash','Danfo King','Jollof Don','Abuja Wolf','Ikeja Blaze','Calabar Storm','Kano Hawk','Oyo Thunder'];
const $id=i=>document.getElementById(i);
let page=null,tab='',preview=null,sel=null;
const items=()=>G.cfg.store.items,rars=()=>G.cfg.store.rarities;
const rcol=r=>(rars()[r]||{}).color||'#9aa7b8',rname=r=>(rars()[r]||{}).name||r;
const owns=id=>!!(G.prof&&G.prof.owned.includes(id));
const eq=()=>G.prof?G.prof.equip:{op:'ronin',skins:{},wskins:{},bling:[]};
const opName=id=>(G.cfg.classes[id]||{}).name||id;
/* ---------- basics ---------- */
UI.toast=(m,k)=>{const d=document.createElement('div');d.className='toast '+(k||'');d.textContent=m;$id('toasts').appendChild(d);setTimeout(()=>d.remove(),3300);};
UI.busy=(on,txt)=>{const b=$id('busy');b.classList.toggle('on',!!on);if(txt)b.querySelector('span').textContent=txt;};
const show=(id,on)=>$id(id).classList.toggle('on',on);
UI.modal=html=>{$id('modalBox').innerHTML=html;show('modal',true);UI.modalOpen=true;};
UI.closeModal=()=>{show('modal',false);UI.modalOpen=false;};
$id('modal').addEventListener('pointerdown',e=>{if(e.target.id==='modal'&&!UI.modalLocked)UI.closeModal();});
document.addEventListener('click',e=>{const b=e.target.closest('[data-open]');if(b){AUD.unlock();AUD.play('click');const [p,t]=b.dataset.open.split(':');openPage(p,t);}});
/* ---------- intro ---------- */
let introDone=false,introT0=performance.now(),introP=0,introReady={cfg:false,gl:false,fonts:false};
UI.intro=()=>{
  const nm='VECTORGAMEX';$id('inName').innerHTML=[...nm].map((c,i)=>`<span style="animation-delay:${.9+i*.07}s">${c}</span>`).join('');
  show('intro',true);G.state='boot';
  let ti=0;const tipEl=$id('inTip'),tip=()=>{tipEl.textContent=TIPS[ti++%TIPS.length];};tip();const tt=setInterval(()=>{if(introDone)clearInterval(tt);else tip();},2600);
  (document.fonts&&document.fonts.ready?Promise.race([document.fonts.ready,new Promise(r=>setTimeout(r,2500))]):Promise.resolve()).then(()=>introReady.fonts=true);
  const tick=()=>{if(introDone)return;const el=(performance.now()-introT0)/1000,got=(introReady.cfg?.4:0)+(introReady.gl?.3:0)+(introReady.fonts?.3:0);
    const target=Math.min(got,Math.min(1,el/3.6));introP+=(target-introP)*.12;const p=Math.round(introP*100);$id('inBar').style.width=p+'%';$id('inPct').textContent=p+'%';
    if(got>=1&&el>3.6&&introP>.985){$id('inBar').style.width='100%';$id('inPct').textContent='READY';$id('inEnter').style.display='';return;}
    requestAnimationFrame(tick);};tick();
  $id('inEnter').onclick=()=>{AUD.unlock();AUD.play('shine');introDone=true;$id('intro').classList.add('out');setTimeout(()=>{show('intro',false);toHub();},550);};
};
UI.introReady=k=>{introReady[k]=true;};
UI.introFail=m=>{$id('inTip').textContent=m;$id('inTip').style.color='#ff8a9d';};
/* ---------- hub ---------- */
function toHub(msg){
  if(G.state==='play'){send({t:'leave'});VOICE.disable();VOICE.leaveRoom();}
  G.state='hub';G.joining=false;document.body.classList.remove('playing');IN.paused=false;
  ['hud','end','pause'].forEach(i=>show(i,false));$id('board').classList.remove('on');UI.closeChat();UI.closeModal();
  show('hub',true);R3.hub.show(true);AUD.setMode('menu');UI.busy(false);hubUpdate();if(msg)UI.toast(msg);
  if(G.needName){G.needName=false;setTimeout(()=>nameModal(true),700);}
}
UI.toHub=toHub;
function hubPreviewSet(){
  if(!G.cfg||!R3.ok())return;const e=eq(),p=preview||{};
  let op=p.op||e.op;if(!G.cfg.classes[op])op=Object.keys(G.cfg.classes)[0];
  const lk={s:p.s!==undefined?p.s:(e.skins[op]||''),w:Object.assign({},e.wskins,p.w||{}),b:p.b||e.bling||[]};
  const wid=p.wid||G.cfg.classes[op].primary;R3.hub.set(op,lk,wid);
}
function hubUpdate(){
  if(!G.cfg)return;const P=G.prof,B=G.cfg.brand;
  $id('hStudio').textContent=(B.studio||'VectorGamex').toUpperCase();$id('hYear').textContent=B.year||'';$id('hMotd').textContent=B.motd||'';
  $id('hOnline').textContent=G.connected?(G.online?G.online+' online':'Online'):'Connecting…';
  if(P){$id('hName').textContent=P.name;$id('hLvl').textContent=P.lvl;$id('hXp').style.width=Math.min(100,P.xpInto/Math.max(1,P.xpNext)*100)+'%';$id('hXpT').textContent=P.xpInto+' / '+P.xpNext+' XP';$id('hCoins').textContent=fmt(P.coins);
    $id('dDot').classList.toggle('on',!!P.daily.canClaim);const o=G.cfg.classes[eq().op]||{};$id('hOp').textContent=(o.name||'').toUpperCase();$id('hOpT').textContent=(o.title||'').toUpperCase()+' · '+((o.ability||'').toUpperCase());}
  if(G.state!=='play')hubPreviewSet();
  if(UI.hub2)UI.hub2();
}
$id('pcard').onclick=()=>openPage('settings','profile');
UI.conn=ok=>{$id('hOnline').textContent=ok?'Online':'Reconnecting…';if(!ok&&G.state==='hub')UI.toast('Connection lost. Reconnecting…','bad');};
UI.cfgChanged=()=>{introReady.cfg=true;const B=G.cfg.brand;document.title=(G.cfg.app&&G.cfg.app.name)||B.title;$id('inGame').textContent=B.title;$id('inYear').textContent=B.year;
  if(G.state==='hub'){hubUpdate();if(page==='store'||page==='play'||page==='daily')renderPage();}};
UI.profChanged=m=>{
  if(G.state==='hub'||G.state==='boot'){hubUpdate();if(page)renderPage(true);}
  if(m&&m.fresh&&!store.get('vb_named',false)){store.set('vb_named',true);G.needName=true;}
  if(G.needName&&G.state==='hub'){G.needName=false;setTimeout(()=>nameModal(true),600);}
};
function nameModal(first){
  UI.modalLocked=!!first;
  UI.modal(`<h2>${first?'CHOOSE YOUR NAME':'CHANGE NAME'}</h2><p>${first?'Welcome, soldier. Pick the name other players will see.':'Pick a new name.'}</p><div class="field"><input id="nmIn" maxlength="16" value="${esc(G.prof?G.prof.name:'')}"></div>
  <div class="row">${SUGG.sort(()=>Math.random()-.5).slice(0,5).map(s=>`<button class="tab" data-sg="${esc(s)}">${esc(s)}</button>`).join('')}</div><button class="btn big" id="nmGo">SAVE</button>${first?'':'<button class="btn ghost" id="nmX">CANCEL</button>'}`);
  $id('modalBox').querySelectorAll('[data-sg]').forEach(b=>b.onclick=()=>{$id('nmIn').value=b.dataset.sg;});
  $id('nmGo').onclick=()=>{const n=$id('nmIn').value.trim();if(n.length<2)return UI.toast('Name needs at least 2 characters','bad');store.set('vb_name',n);send({t:'name',n});UI.modalLocked=false;UI.closeModal();};
  if($id('nmX'))$id('nmX').onclick=()=>UI.closeModal();
}
/* ---------- pages ---------- */
const PAGES={play:{t:'PLAY',tabs:[['online','ONLINE'],['practice','PRACTICE'],['private','PRIVATE ROOM']]},
  loadout:{t:'LOADOUT',tabs:[['op','OPERATOR'],['skin','SKINS'],['weapon','WEAPONS'],['bling','BLING']]},
  store:{t:'STORE',tabs:[['feat','FEATURED'],['skin','SKINS'],['wskin','GUN SKINS'],['bling','BLING'],['op','OPERATORS'],['coins','COINS'],['orders','ORDERS']]},
  daily:{t:'DAILY REWARDS',tabs:[]},settings:{t:'SETTINGS',tabs:[['profile','PROFILE'],['controls','CONTROLS'],['keys','KEYS'],['gfx','GRAPHICS'],['audio','AUDIO & VOICE']]},how:{t:'HOW TO PLAY',tabs:[]},season:{t:'SEASON',tabs:[['pass','SEASON PASS'],['crate','LUCKY DRAW'],['vibes','VECTORVIBES']]}};
function openPage(p,t){
  page=p;tab=t||(PAGES[p].tabs[0]||[''])[0];sel=null;preview=null;show('page',true);document.body.classList.add('paged');R3.hub.paged&&R3.hub.paged(true);
  if(p==='store'&&!t)tab='feat';renderPage();hubPreviewSet();
}
function closePage(){page=null;preview=null;show('page',false);document.body.classList.remove('paged');R3.hub.paged&&R3.hub.paged(false);hubPreviewSet();}
$id('pgClose').onclick=()=>{AUD.play('click');if(G.state==='play'){show('page',false);page=null;show('pause',true);}else closePage();};
UI.closePage=closePage;
const PAGEFN={play:pPlay,loadout:pLoadout,store:pStore,daily:pDaily,settings:pSettings,how:pHow};
function renderPage(soft){
  if(!page)return;const def=PAGES[page];$id('pgTitle').textContent=def.t;
  $id('pgTabs').innerHTML=def.tabs.map(([k,n])=>`<button class="tab ${k===tab?'on':''}" data-tab="${k}">${n}</button>`).join('');
  $id('pgTabs').querySelectorAll('.tab').forEach(b=>b.onclick=()=>{AUD.play('click');tab=b.dataset.tab;sel=null;preview=null;hubPreviewSet();renderPage();});
  const body=$id('pgBody'),sc=body.scrollTop;body.innerHTML='';
  (PAGEFN[page])(body);
  if(soft)body.scrollTop=sc;
}
/* ----- play ----- */
function modeCards(el,onPick,withBR=true){
  const modes=Object.entries(G.cfg.modes).filter(([id,m])=>withBR||m.type!=='br');
  el.innerHTML=modes.map(([id,m])=>`<div class="card mode ${m.type==='br'?'br':''} ${SEL.mode===id?'sel':''}" data-m="${id}"><div class="ic">${esc(m.icon||id.toUpperCase())}</div><h4>${esc(m.name)}</h4><p>${esc(m.desc)}</p></div>`).join('');
  if(!modes.some(([id])=>id===SEL.mode)){SEL.mode=modes[0][0];}
  el.querySelectorAll('[data-m]').forEach(c=>c.onclick=()=>{AUD.play('click');SEL.mode=c.dataset.m;saveSel();onPick();});
}
function mapRow(el){
  const br=(G.cfg.modes[SEL.mode]||{}).type==='br';
  if(br){el.innerHTML='<div class="note">Battle Royale is played on the open world map. The grid closes in, so keep moving.</div>';return;}
  const list=G.cfg.mapList.filter(m=>!m.br&&m.arena);
  if(!list.some(m=>m.id===SEL.map))SEL.map='';
  el.innerHTML=`<div class="sec">MAP</div><div class="grid"><div class="card ${!SEL.map?'sel':''}" data-mp=""><h4>Random</h4><p>Any map in rotation</p></div>${list.map(m=>`<div class="card ${SEL.map===m.id?'sel':''}" data-mp="${esc(m.id)}"><h4>${esc(m.name)}</h4><p>${esc(m.desc||'')}</p></div>`).join('')}</div>`;
  el.querySelectorAll('[data-mp]').forEach(c=>c.onclick=()=>{AUD.play('click');SEL.map=c.dataset.mp;saveSel();mapRow(el);});
}
function join(o){if(G.joining)return;if(!G.connected)return UI.toast('Not connected yet. Try again in a moment.','bad');
  const br=(G.cfg.modes[o.mode]||{}).type==='br';if(br)delete o.map;G.joining=true;UI.busy(true,o.practice?'Starting practice…':o.create?'Creating room…':o.room?'Joining room…':'Finding a match…');send(Object.assign({t:'join'},o));setTimeout(()=>{if(G.joining&&G.state!=='play'){G.joining=false;UI.busy(false);UI.toast('No response from server. Try again.','bad');}},9000);}
function pPlay(body){
  const d=document.createElement('div');body.appendChild(d);
  const diffs=Object.entries(G.cfg.match.difficulty);
  const draw=()=>{
    d.innerHTML=`<div class="sec">MODE</div><div class="modes" id="mc"></div><div id="mr"></div>`;
    modeCards($id('mc'),draw,true);mapRow($id('mr'));
    const x=document.createElement('div');d.appendChild(x);
    if(tab==='online'){x.innerHTML=`<div class="sec">MATCHMAKING</div><div class="note">Quick Play drops you into a live room with other online players. Empty slots are filled with fair bots so matches always start fast.</div><button class="btn big" id="goOn" style="width:100%">FIND MATCH</button>`;
      $id('goOn').onclick=()=>{AUD.play('click');join({mode:SEL.mode,map:SEL.map});};}
    else if(tab==='practice'){x.innerHTML=`<div class="sec">BOT DIFFICULTY</div><div class="seg" id="df">${diffs.map(([k,v])=>`<button data-d="${k}" class="${SEL.diff===k?'on':''}">${esc(v.name)}</button>`).join('')}</div><div class="note">Practice bots only see what is in front of them, react after a delay and miss shots. Rewards are reduced.</div><button class="btn big" id="goPr" style="width:100%">START PRACTICE</button>`;
      x.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{SEL.diff=b.dataset.d;saveSel();x.querySelectorAll('[data-d]').forEach(z=>z.classList.toggle('on',z===b));});
      $id('goPr').onclick=()=>{AUD.play('click');join({practice:1,mode:SEL.mode,map:SEL.map,diff:SEL.diff});};}
    else{x.innerHTML=`<div class="sec">CREATE A PRIVATE ROOM</div><button class="btn" id="goCr" style="width:100%">CREATE ROOM & GET CODE</button><div class="sec">OR JOIN WITH A CODE</div><div class="row"><div class="field" style="flex:1;margin:0"><input id="rc" maxlength="4" placeholder="ABCD" style="text-transform:uppercase;letter-spacing:.4em;font-size:24px;text-align:center"></div><button class="btn" id="goJn">JOIN</button></div>`;
      $id('goCr').onclick=()=>{AUD.play('click');join({create:1,mode:SEL.mode,map:SEL.map});};
      $id('goJn').onclick=()=>{const c=$id('rc').value.toUpperCase().replace(/[^A-Z]/g,'');if(c.length<4)return UI.toast('Enter the 4 letter room code','bad');AUD.play('click');join({room:c,mode:SEL.mode});};}
  };draw();
}
/* ----- loadout & store ----- */
function itemCard(id,it,o={}){
  const own=owns(id),on=(it.type==='skin'&&eq().skins[o.op||eq().op]===id)||(it.type==='wskin'&&Object.values(eq().wskins||{}).includes(id))||(it.type==='bling'&&(eq().bling||[]).includes(id));
  return `<div class="card ${sel===id?'sel':''} ${own||o.free?'':'lock'}" data-it="${id}"><span class="rar" style="background:${rcol(it.rarity)}"></span>${it.exclusive?'<span class="ex">EXCLUSIVE</span>':''}
  <div class="rt" style="color:${rcol(it.rarity)}">${esc(rname(it.rarity))}</div><h4>${esc(it.name)}</h4><p>${esc(it.desc||typeLabel(it))}</p>
  <div class="pr">${on?'<span class="own">EQUIPPED</span>':own?'<span class="own">OWNED</span>':(it.coins>0?`<span class="coin"></span>${fmt(it.coins)}`:'')+(it.naira>0?`<span style="color:var(--gold)">${(it.coins>0?' · ':'')+NG(it.naira)}</span>`:'')}</div></div>`;
}
const typeLabel=it=>it.type==='skin'?('Outfit'+(it.op&&it.op!=='any'?' · '+opName(it.op):'')):it.type==='wskin'?('Gun skin'+(it.weapon&&it.weapon!=='any'?' · '+((G.cfg.weapons[it.weapon]||{}).name||it.weapon):'')):it.type==='bling'?('Bling · '+it.slot):'Operator';
function previewItem(id){
  const it=items()[id],e=eq();if(!it)return;preview={};
  if(it.type==='skin'){preview.op=it.op!=='any'&&G.cfg.classes[it.op]?it.op:e.op;preview.s=id;}
  else if(it.type==='wskin'){const op=e.op,wid=it.weapon!=='any'?it.weapon:G.cfg.classes[op].primary;preview.wid=wid;preview.w={[wid]:id};}
  else if(it.type==='bling'){preview.b=(e.bling||[]).filter(b=>items()[b]&&items()[b].slot!==it.slot).concat(id);}
  else if(it.type==='operator'){preview.op=it.op;}
  hubPreviewSet();
}
function equipSend(mut){const e=JSON.parse(JSON.stringify(eq()));e.skins=e.skins||{};e.wskins=e.wskins||{};e.bling=e.bling||[];mut(e);send({t:'equip',eq:e});}
function equipItem(id,off){
  const it=items()[id];if(!it||!owns(id))return;
  equipSend(e=>{
    if(it.type==='skin'){const op=it.op!=='any'&&G.cfg.classes[it.op]?it.op:e.op;if(off)delete e.skins[op];else{e.skins[op]=id;e.op=op;}}
    else if(it.type==='wskin'){const ws=it.weapon!=='any'?[it.weapon]:Object.keys(G.cfg.weapons);for(const w of ws){if(off)delete e.wskins[w];else e.wskins[w]=id;}}
    else if(it.type==='bling'){e.bling=e.bling.filter(b=>items()[b]&&items()[b].slot!==it.slot);if(!off)e.bling.push(id);}
  });AUD.play('click');preview=null;
}
function detailBar(body,id){
  const old=$id('detail');if(old)old.remove();if(!id)return;
  const it=items()[id];if(!it)return;const own=owns(id),P=G.prof;
  const d=document.createElement('div');d.id='detail';d.style.cssText='position:sticky;bottom:0;background:rgba(5,8,15,.97);border:1px solid '+rcol(it.rarity)+';padding:12px;margin-top:10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;z-index:3';
  const on=(it.type==='skin'&&Object.values(eq().skins).includes(id))||(it.type==='wskin'&&Object.values(eq().wskins||{}).includes(id))||(it.type==='bling'&&(eq().bling||[]).includes(id));
  let btns='';
  if(own){if(it.type==='operator')btns=`<span class="own">UNLOCKED</span>`;else btns=on?`<button class="btn ghost sm" id="dbOff">UNEQUIP</button>`:`<button class="btn sm" id="dbEq">EQUIP</button>`;}
  else{if(it.coins>0)btns+=`<button class="btn gold sm" id="dbBuy" ${P&&P.coins<it.coins?'disabled':''}>BUY ${fmt(it.coins)} COINS</button>`;if(it.naira>0)btns+=`<button class="btn sm" id="dbPay">PAY ${NG(it.naira)}</button>`;if(!(it.coins>0)&&!(it.naira>0))btns='<span class="own">NOT FOR SALE</span>';}
  d.innerHTML=`<div style="flex:1;min-width:160px"><div class="rt" style="color:${rcol(it.rarity)};font:700 12px var(--fh);letter-spacing:.14em">${esc(rname(it.rarity)).toUpperCase()}${it.exclusive?' · EXCLUSIVE':''}</div><b style="font:700 20px var(--fh)">${esc(it.name)}</b><div style="font-size:13px;color:var(--mut)">${esc(it.desc||typeLabel(it))}</div></div><div class="row">${btns}</div>`;
  body.appendChild(d);
  const q=i=>d.querySelector(i);
  if(q('#dbEq'))q('#dbEq').onclick=()=>equipItem(id);if(q('#dbOff'))q('#dbOff').onclick=()=>equipItem(id,true);
  if(q('#dbBuy'))q('#dbBuy').onclick=()=>{send({t:'buy',id});};
  if(q('#dbPay'))q('#dbPay').onclick=()=>payModal({kind:'item',ref:id,label:it.name,naira:it.naira});
}
function bindItems(body,filterFree){
  body.querySelectorAll('[data-it]').forEach(c=>c.onclick=()=>{AUD.play('click');sel=c.dataset.it;body.querySelectorAll('[data-it]').forEach(z=>z.classList.toggle('sel',z===c));previewItem(sel);detailBar(body,sel);});
}
function pLoadout(body){
  const e=eq(),op=e.op,cls=G.cfg.classes;
  if(tab==='op'){
    body.innerHTML=`<div class="grid">${Object.entries(cls).map(([id,c])=>{const ok=!c.locked||G.prof.owned.some(i=>items()[i]&&items()[i].type==='operator'&&items()[i].op===id);
      return `<div class="card ${op===id?'sel':''} ${ok?'':'lock'}" data-op="${id}"><h4>${esc(c.name)}</h4><div class="rt" style="color:${c.color}">${esc(c.title)} · ${esc((c.ability||'').toUpperCase())}</div><p>${esc(c.desc)}</p><p style="margin-top:4px">HP ${c.hp} · SPEED ${(c.speed*100)|0}% · ${esc((G.cfg.weapons[c.primary]||{}).name||c.primary)}</p>${ok?'':'<div class="pr"><span class="own" style="color:var(--gold)">LOCKED · see Store</span></div>'}</div>`;}).join('')}</div>`;
    body.querySelectorAll('[data-op]').forEach(c=>c.onclick=()=>{const id=c.dataset.op,cc=cls[id];const ok=!cc.locked||G.prof.owned.some(i=>items()[i]&&items()[i].type==='operator'&&items()[i].op===id);if(!ok){UI.toast('Unlock this operator in the Store','bad');preview={op:id};hubPreviewSet();return;}AUD.play('click');equipSend(x=>{x.op=id;});});
  }else if(tab==='skin'){
    const list=Object.entries(items()).filter(([id,it])=>it.type==='skin'&&(it.op==='any'||it.op===op));
    body.innerHTML=`<div class="sec">${esc(opName(op)).toUpperCase()} OUTFITS</div><div class="grid"><div class="card ${!e.skins[op]?'sel':''}" data-def="1"><h4>Default</h4><p>Standard issue</p></div>${list.map(([id,it])=>itemCard(id,it,{op})).join('')}</div>`;
    body.querySelector('[data-def]').onclick=()=>{equipSend(x=>{delete x.skins[op];});};bindItems(body);if(sel)detailBar(body,sel);
  }else if(tab==='weapon'){
    const w=sel&&G.cfg.weapons[sel]?sel:(preview&&preview.wid)||cls[op].primary;
    body.innerHTML=`<div class="sec">GUN</div><div class="grid">${Object.entries(G.cfg.weapons).map(([id,x])=>`<div class="card ${w===id?'sel':''}" data-w="${id}"><h4>${esc(x.name)}</h4><p>DMG ${x.damage} · RPM ${x.rpm} · MAG ${x.mag}</p></div>`).join('')}</div><div class="sec">${esc(G.cfg.weapons[w].name).toUpperCase()} SKINS</div><div class="grid" id="wsk"></div>`;
    body.querySelectorAll('[data-w]').forEach(c=>c.onclick=()=>{AUD.play('click');sel=c.dataset.w;preview={wid:sel};hubPreviewSet();renderPage(true);});
    const list=Object.entries(items()).filter(([id,it])=>it.type==='wskin'&&(it.weapon==='any'||it.weapon===w));
    $id('wsk').innerHTML=`<div class="card ${!e.wskins[w]?'sel':''}" data-wd="1"><h4>Factory</h4><p>No skin</p></div>`+list.map(([id,it])=>itemCard(id,it)).join('');
    $id('wsk').querySelector('[data-wd]').onclick=()=>{equipSend(x=>{delete x.wskins[w];});preview={wid:w};};
    $id('wsk').querySelectorAll('[data-it]').forEach(c=>c.onclick=()=>{AUD.play('click');const id=c.dataset.it;previewItem(id);preview.wid=w;preview.w={[w]:id};hubPreviewSet();detailBar(body,id);sel=w;});
  }else{
    const list=Object.entries(items()).filter(([id,it])=>it.type==='bling');
    body.innerHTML=`<div class="note">Bling shows on your soldier in every match. One item per slot (face, neck, ear, wrist).</div><div class="grid">${list.map(([id,it])=>itemCard(id,it)).join('')}</div>`;bindItems(body);if(sel)detailBar(body,sel);
  }
}
function pStore(body){
  const P=G.prof,st=G.cfg.store,all=Object.entries(items());
  const grid=(arr)=>`<div class="grid">${arr.map(([id,it])=>itemCard(id,it)).join('')||'<p>Nothing here yet.</p>'}</div>`;
  const byRar=a=>a.slice().sort((x,y)=>Object.keys(rars()).indexOf(y[1].rarity)-Object.keys(rars()).indexOf(x[1].rarity));
  if(tab==='feat'){
    body.innerHTML=(st.featuredText?`<div class="note">${esc(st.featuredText)}</div>`:'')+`<div class="sec">FEATURED</div>`+grid(byRar(all.filter(([i,x])=>x.featured||x.exclusive)))+`<div class="sec">COIN PACKS</div><div class="grid">${packCards()}</div>`;bindItems(body);bindPacks(body);
  }else if(tab==='skin'||tab==='wskin'||tab==='bling'){body.innerHTML=grid(byRar(all.filter(([i,x])=>x.type===tab)));bindItems(body);}
  else if(tab==='op'){body.innerHTML=grid(all.filter(([i,x])=>x.type==='operator'));bindItems(body);}
  else if(tab==='coins'){body.innerHTML=`<div class="note">Buy coins by bank transfer. After you pay, submit your order and it is approved by the ${esc(G.cfg.brand.studio)} team. Coins land in your account automatically.</div><div class="grid">${packCards()}</div>`;bindPacks(body);}
  else{
    const o=(P&&P.orders||[]).slice().reverse();
    body.innerHTML=`<div class="sec">YOUR ORDERS</div>`+(o.length?o.map(x=>`<div class="ord"><span><b>${esc(x.id)}</b> · ${esc(x.label)}</span><span>${NG(x.naira)} · <b class="st-${x.status}">${x.status.toUpperCase()}</b></span></div>`).join(''):'<p style="color:var(--mut)">No orders yet.</p>');
  }
  if(sel&&items()[sel])detailBar(body,sel);
}
const packCards=()=>G.cfg.store.coinPacks.map(p=>`<div class="card" data-pk="${esc(p.id)}"><div class="row" style="gap:6px"><span class="coin"></span><h4 style="margin:0;font-size:22px">${fmt(p.coins)}</h4></div><p>${esc(p.name)}${p.bonus?' · <b style="color:var(--grn)">'+esc(p.bonus)+'</b>':''}</p><div class="pr" style="color:var(--gold)">${NG(p.naira)}</div></div>`).join('');
function bindPacks(body){body.querySelectorAll('[data-pk]').forEach(c=>c.onclick=()=>{AUD.play('click');const p=G.cfg.store.coinPacks.find(x=>x.id===c.dataset.pk);payModal({kind:'pack',ref:p.id,label:p.name+' · '+fmt(p.coins)+' coins',naira:p.naira});});}
function payModal(o){
  const pay=G.cfg.store.payment||{},sv=store.get('vb_pay',{name:'',phone:''});
  UI.modal(`<h2>PAY BY TRANSFER</h2><p><b>${esc(o.label)}</b> · <b style="color:var(--gold)">${NG(o.naira)}</b></p>
  <div class="acct"><small style="color:var(--mut);letter-spacing:.2em">STEP 1 · SEND ${NG(o.naira)} TO ${esc((pay.bank||'').toUpperCase())}</small><b id="acN">${esc(pay.account||'')}</b>${pay.accountName?`<div>${esc(pay.accountName)}</div>`:''}<button class="btn sm" id="acCp" style="margin-top:6px">COPY ACCOUNT NUMBER</button></div>
  ${pay.note?`<div class="note">${esc(pay.note)}</div>`:''}
  <div class="field"><label>STEP 2 · YOUR NAME (as on the transfer)</label><input id="pyN" maxlength="40" value="${esc(sv.name)}" placeholder="Full name"></div>
  <div class="field"><label>PHONE NUMBER</label><input id="pyP" maxlength="16" inputmode="tel" value="${esc(sv.phone)}" placeholder="080..."></div>
  <button class="btn big" id="pyGo">I HAVE PAID · SUBMIT ORDER</button><button class="btn ghost" id="pyX">CANCEL</button>`);
  $id('acCp').onclick=()=>{try{navigator.clipboard.writeText(pay.account||'');}catch(e){}UI.toast('Account number copied','good');};
  $id('pyX').onclick=UI.closeModal;
  $id('pyGo').onclick=()=>{const name=$id('pyN').value.trim(),phone=$id('pyP').value.trim();store.set('vb_pay',{name,phone});send({t:'order',kind:o.kind,ref:o.ref,name,phone});$id('pyGo').disabled=true;};
}
UI.orderOk=ord=>{UI.modalLocked=false;UI.modal(`<h2>ORDER SUBMITTED</h2><p>Order code <b style="color:var(--a)">${esc(ord.id)}</b> for ${esc(ord.label)} (${NG(ord.naira)}).</p><p>Once your transfer is confirmed it is approved, usually within minutes. You will see it in Store → Orders and your items or coins arrive automatically.</p><button class="btn" id="okX">OK</button>`);$id('okX').onclick=()=>{UI.closeModal();if(page==='store'){tab='orders';renderPage();}};};
UI.bought=id=>{const it=items()[id];UI.toast('Unlocked '+(it?it.name:'item'),'good');R3.hub.reveal();if(it&&it.type!=='operator')setTimeout(()=>equipItem(id),150);};
/* ----- daily ----- */
function pDaily(body){
  const P=G.prof,rw=G.cfg.daily.rewards,idx=P.daily.day%rw.length;
  const lab=r=>r.type==='item'?((items()[r.item]||{}).name||'Item'):'+'+r.amount;
  body.innerHTML=`<div class="note">Log in every day to claim. Day 20 and day 40 give exclusive items. Resets at midnight, Lagos time.</div>
  <div class="dgrid">${rw.map((r,i)=>`<div class="day ${i<idx?'done':''} ${i===idx?'now':''} ${r.type==='item'?'ex':''}"><b>DAY ${i+1}</b><span class="rw">${esc(lab(r))}</span>${r.type==='item'?'<small style="color:var(--mut)">'+esc(r.label||'ITEM')+'</small>':'<span class="coin" style="display:inline-block;width:14px;height:14px"></span>'}</div>`).join('')}</div>
  <div style="position:sticky;bottom:0;padding:10px 0;background:rgba(5,8,15,.95);margin-top:10px"><button class="btn big gold" id="clm" style="width:100%" ${P.daily.canClaim?'':'disabled'}>${P.daily.canClaim?'CLAIM TODAY\'S REWARD':'COME BACK TOMORROW'}</button></div>`;
  $id('clm').onclick=()=>send({t:'daily'});
  const n=body.querySelector('.now');if(n)setTimeout(()=>n.scrollIntoView({block:'center'}),50);
}
UI.dailyOk=m=>{UI.modal(`<h2>DAILY REWARD</h2><p style="text-align:center;font:800 28px var(--fd);color:var(--gold)">${esc(m.msg)}</p><button class="btn" id="okX">NICE</button>`);$id('okX').onclick=UI.closeModal;R3.hub.reveal();};
/* ----- how ----- */
function pHow(body){const B=G.cfg.brand;body.innerHTML=`<div class="how"><p>${esc(B.rules||'')}</p>
<p><b>Camera:</b> switch between third person, first person and tactical top-down with the VIEW button (V on keyboard).</p>
<p><b>Touch:</b> left thumb moves (relative to where the camera looks). Swipe the right side to look. <b>FIRE</b> shoots from the hip, <b>ADS FIRE</b> aims down sights while shooting. JUMP, SLIDE and CROUCH sit by your thumb. FRAG throws a grenade. SWAP flips to your second weapon. ENTER gets in a vehicle, SCAN revives a squadmate with their dog tags. UAV uses your scorestreak.</p>
<p><b>Keyboard:</b> WASD move, mouse look (click to capture), left click fire, right click aim, Space jump, C crouch, Shift slide, Q ability, R reload, G frag, E enter/exit vehicle, F hold to scan dog tags, X swap weapon, Z scorestreak, V camera, B emote wheel, Tab scoreboard, T push to talk, Enter chat, Esc pause.</p>
<p><b>Battle Royale squads:</b> teammates are colour coded Blue, Green, Yellow and Orange. If a teammate falls, their dog tag drops. Run over it, then hold SCAN near open ground to call a revival flight. They parachute back in. Cars, bikes and the helicopter are on the map; the helicopter has a pilot seat and side-rail passenger seats.</p>
<p><b>Modes:</b> ${Object.values(G.cfg.modes).map(m=>'<b>'+esc(m.name)+'</b> '+esc(m.desc)).join(' ')}</p></div>`;}
/* ----- settings ----- */
const tog=(id,label,sub,on)=>`<div class="tog"><div>${label}${sub?'<small>'+sub+'</small>':''}</div><div class="sw ${on?'on':''}" id="${id}"></div></div>`;
const rng=(id,label,min,max,step,v,suf)=>`<div class="bar"><label>${label}</label><input type="range" id="${id}" min="${min}" max="${max}" step="${step}" value="${v}"><span class="v" id="${id}V">${v}${suf||''}</span></div>`;
function bindTog(id,fn){const e=$id(id);e.onclick=()=>{e.classList.toggle('on');fn(e.classList.contains('on'));saveS();};}
function bindRng(id,fn){const e=$id(id);e.oninput=()=>{$id(id+'V').textContent=e.value+($id(id+'V').dataset.s||'');fn(+e.value);};e.onchange=saveS;}
const KEYNAMES={up:'Move forward',down:'Move back',left:'Move left',right:'Move right',jump:'Jump / ascend',crouch:'Crouch / descend',slide:'Slide',ability:'Ability',reload:'Reload',grenade:'Frag grenade',use:'Enter / exit vehicle',revive:'Scan dog tags (hold)',swap:'Swap weapon',streak:'Scorestreak (UAV)',cam:'Camera view',emote:'Emote wheel (hold)',board:'Scoreboard',talk:'Push to talk',chat:'Chat',pause:'Pause'};
const kn=c=>c.replace('Key','').replace('Arrow','↑').replace('Digit','');
function pSettings(body){
  if(tab==='profile'){const P=G.prof||{name:''};
    body.innerHTML=`<div class="field"><label>PLAYER NAME</label><div class="row"><b style="font:800 24px var(--fh);flex:1">${esc(P.name)}</b><button class="btn sm" id="chN">CHANGE NAME</button></div></div>
    <div class="sec">STATS</div><div class="tog"><div>Matches ${P.stats?P.stats.matches||0:0} · Wins ${P.stats?P.stats.wins||0:0} · Kills ${P.stats?P.stats.kills||0:0}</div></div>
    <div class="sec">SAVE YOUR ACCOUNT</div><div class="note">Your progress is stored on this device. Copy your recovery code to restore your coins and skins on another phone.</div>
    <div class="row"><button class="btn sm" id="rcCp">COPY RECOVERY CODE</button></div><div class="field"><label>RESTORE FROM CODE</label><div class="row"><input id="rcIn" style="flex:1" placeholder="Paste code"><button class="btn sm" id="rcGo">RESTORE</button></div></div>
    <div class="sec">INSTALL</div><div id="instBox"></div>`;
    $id('chN').onclick=()=>nameModal(false);
    $id('rcCp').onclick=()=>{try{navigator.clipboard.writeText(recoveryCode());UI.toast('Recovery code copied','good');}catch(e){UI.modal(`<h2>RECOVERY CODE</h2><p style="word-break:break-all;user-select:text">${esc(recoveryCode())}</p><button class="btn" id="okX">OK</button>`);$id('okX').onclick=UI.closeModal;}};
    $id('rcGo').onclick=()=>{const c=$id('rcIn').value.trim();if(c)send({t:'restore',code:c});};
    const ib=$id('instBox');
    if(window.__installEvt)ib.innerHTML='<button class="btn" id="inst">INSTALL APP</button>';else if(matchMedia('(display-mode:standalone)').matches)ib.innerHTML='<div class="note">App installed.</div>';else ib.innerHTML='<div class="note">To install: open the browser menu (⋮ in Chrome) and tap <b>Install app</b> / <b>Add to Home screen</b>. The game logo will appear on your home screen.</div>';
    if($id('inst'))$id('inst').onclick=async()=>{const e=window.__installEvt;window.__installEvt=null;e.prompt();try{await e.userChoice;}catch(x){}renderPage();};
  }else if(tab==='controls'){
    body.innerHTML=`<div class="sec">CAMERA</div><div class="seg" id="cv">${[['tps','THIRD PERSON'],['fps','FIRST PERSON'],['top','TACTICAL TOP-DOWN']].map(([k,n])=>`<button data-v="${k}" class="${S.view===k?'on':''}">${n}</button>`).join('')}</div>${rng('sFov','Field of view',55,100,1,S.fov||70,'')}${tog('sInv','Invert look Y','',!!S.invertY)}
    <div class="sec">AIMING</div><div class="seg" id="am"><button data-v="point" class="${S.aimMode==='point'?'on':''}">POINT (swipe where to aim)</button><button data-v="rotate" class="${S.aimMode==='rotate'?'on':''}">ROTATE (camera style)</button></div>
    ${rng('sSens','Swipe sensitivity',.4,2.5,.1,S.sens,'')}${rng('sAA','Aim assist',0,1,.05,S.aimAssist!=null?S.aimAssist:(ctrl().aimAssist||0),'')}
    ${tog('sAuto','Auto fire','Shoots automatically when an enemy is in your sights',autoFireOn())}${tog('sLF','Left-hand FIRE button','Adds a second FIRE button on the left',S.leftFire)}${tog('sVib','Vibration','Haptic feedback on fire and hits',S.vib)}
    ${rng('sFS','FIRE button size',60,140,2,fireSize(),'px')}
    ${IN.touch?'<button class="btn" id="lay" style="width:100%;margin-top:8px">MOVE BUTTONS (LAYOUT EDITOR)</button><button class="btn ghost sm" id="layR" style="margin-top:8px">RESET LAYOUT</button>':'<div class="note">First/third person: click the game to capture the mouse, move to look, left click fires, right click aims down sights. Tactical view: mouse aims, right click uses ability.</div>'}`;
    $id('cv').querySelectorAll('button').forEach(b=>b.onclick=()=>{UI.setView(b.dataset.v);renderPage(true);});bindRng('sFov',v=>S.fov=v);bindTog('sInv',v=>S.invertY=v);
    $id('am').querySelectorAll('button').forEach(b=>b.onclick=()=>{S.aimMode=b.dataset.v;saveS();renderPage(true);});
    bindRng('sSens',v=>S.sens=v);bindRng('sAA',v=>S.aimAssist=v);bindTog('sAuto',v=>S.autoFire=v);bindTog('sLF',v=>{S.leftFire=v;IN.applyLayout();});bindTog('sVib',v=>S.vib=v);bindRng('sFS',v=>{S.fireSize=v;IN.applyLayout();});$id('sFSV').dataset.s='px';
    if($id('lay'))$id('lay').onclick=UI.editLayout;if($id('layR'))$id('layR').onclick=()=>{S.layout={};saveS();IN.applyLayout();UI.toast('Layout reset');};
  }else if(tab==='keys'){
    body.innerHTML=`<div class="note">Click a key then press the new key.</div>`+Object.entries(KEYNAMES).map(([k,n])=>`<div class="tog"><div>${n}</div><button class="key" data-k="${k}">${esc(kn(S.keys[k]))}</button></div>`).join('')+`<button class="btn ghost sm" id="kR">RESET KEYS</button>`;
    body.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>{body.querySelectorAll('.key').forEach(x=>x.classList.remove('listen'));b.classList.add('listen');b.textContent='press key…';IN.listen=code=>{IN.listen=null;if(code!=='Escape'){S.keys[b.dataset.k]=code;saveS();}renderPage(true);};});
    $id('kR').onclick=()=>{S.keys=Object.assign({},DEFKEYS);saveS();renderPage(true);};
  }else if(tab==='gfx'){
    body.innerHTML=`<div class="sec">QUALITY</div><div class="seg" id="ql">${[['auto','AUTO'],['low','LOW'],['med','MEDIUM'],['high','HIGH']].map(([k,n])=>`<button data-v="${k}" class="${S.quality===k?'on':''}">${n}</button>`).join('')}</div>
    ${tog('sSh','Shadows','Looks better, costs performance',S.shadows)}${tog('sFps','Show FPS and ping','',S.showFps)}${rng('sCam','Camera zoom',.6,1.5,.05,S.cam,'')}${rng('sMini','Minimap size',0,2,1,S.mini,'')}`;
    $id('ql').querySelectorAll('button').forEach(b=>b.onclick=()=>{S.quality=b.dataset.v;window.__lowfps=false;saveS();R3.setQuality(S.quality);renderPage(true);});
    bindTog('sSh',v=>{S.shadows=v;R3.setQuality(S.quality);});bindTog('sFps',v=>S.showFps=v);bindRng('sCam',v=>S.cam=v);bindRng('sMini',v=>{S.mini=v;IN.applyLayout();});
  }else{
    body.innerHTML=`${rng('aM','Music',0,1,.05,AUD.S.music,'')}${rng('aS','Sound effects',0,1,.05,AUD.S.sfx,'')}${rng('aV','Voice volume',0,1,.05,VOICE.vol,'')}
    ${tog('aO','Let nearby enemies hear me','Off: only your team hears your voice',VOICE.open)}
    <div class="sec">VOICE CHAT</div><div class="note" id="vSt">Join a match, then tap the mic button (or hold V) to talk.</div>`;
    bindRng('aM',v=>AUD.vol('music',v));bindRng('aS',v=>{AUD.vol('sfx',v);AUD.play('click');});bindRng('aV',v=>VOICE.setVol(v));bindTog('aO',v=>VOICE.setOpen(v));
  }
}
UI.editLayout=()=>{
  closePage();show('hub',false);R3.hub.show(false);show('hud',true);document.body.classList.add('editing');IN.setEdit(true);IN.applyLayout();
  const d=document.createElement('div');d.id='layBar';d.style.cssText='position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:90;display:flex;gap:10px;flex-direction:column;align-items:center;text-align:center';
  d.innerHTML='<b style="font:800 18px var(--fd);letter-spacing:.1em">DRAG BUTTONS WHERE YOU WANT THEM</b><div class="row"><button class="btn" id="layD">DONE</button><button class="btn ghost" id="layR2">RESET</button></div>';document.body.appendChild(d);
  $id('layD').onclick=()=>{d.remove();IN.setEdit(false);document.body.classList.remove('editing');show('hud',false);show('hub',true);R3.hub.show(true);openPage('settings','controls');};
  $id('layR2').onclick=()=>{S.layout={};saveS();IN.applyLayout();};
};
{const st=document.createElement('style');st.textContent='body.editing #hud>*:not(#touch){display:none!important}body.editing #touch{display:block!important}body.editing #stickZone,body.editing #aimZone{pointer-events:none}body.editing .tb.ch,body.editing .tb.mc,body.editing .tb.fire2{display:grid!important}';document.head.appendChild(st);}
/* ---------- match / HUD ---------- */
let lastRos='',fpsA=0,fpsN=0,fpsT=0,lastCount=-1;
UI.enterGame=()=>{
  G.state='play';document.body.classList.add('playing');closePage();show('hub',false);show('end',false);show('pause',false);UI.closeModal();UI.busy(false);
  show('hud',true);R3.hub.show(false);AUD.setMode('match');IN.applyLayout();IN.paused=false;
  $id('killfeed').innerHTML='';$id('chatLog').innerHTML='';$id('respawn').style.display='none';$id('spec').textContent='';lastCount=-1;
  const br=roomIsBR(),m=G.cfg.modes[G.modeId]||{};
  UI.banner(m.name||'MATCH',G.practice?'PRACTICE':G.priv?'ROOM '+G.room:'ONLINE');
  if(G.priv&&!G.practice)UI.toast('Room code: '+G.room+' (share it with friends)','good');
  IN.a=0;INP.a=0;
  if(window.__vbWantVoice)setTimeout(()=>VOICE.enable(),500);
};
UI.banner=(t,sub)=>{const b=$id('banner');b.innerHTML=esc(t)+(sub?'<small>'+esc(sub)+'</small>':'');b.classList.remove('show');void b.offsetWidth;b.classList.add('show');};
const nm=id=>{const r=G.roster.get(id);return r?r.n:'?';};
UI.killFeed=e=>{const f=$id('killfeed'),d=document.createElement('div'),mine=e.a===G.you||e.v===G.you;d.className='kf'+(mine?' me':'');
  const w=(G.cfg.weapons[e.w]||{}).name||'';const r1=G.roster.get(e.a),r2=G.roster.get(e.v);
  d.innerHTML=(e.a===e.v||e.a<0)?`<span style="color:${modeIsTeam()&&r2?teamCol(r2.t):'#fff'}">${esc(nm(e.v))}</span> ${e.a<0?'was caught by the grid':'eliminated themself'}`:`<span style="color:${modeIsTeam()&&r1?teamCol(r1.t):'#fff'}">${esc(nm(e.a))}</span> <small style="color:var(--mut)">[${esc(w)}]</small> <span style="color:${modeIsTeam()&&r2?teamCol(r2.t):'#fff'}">${esc(nm(e.v))}</span>`;
  f.prepend(d);while(f.children.length>5)f.lastChild.remove();setTimeout(()=>d.remove(),5500);};
UI.died=e=>{G.shake=14;};
UI.rosterChanged=()=>{if($id('board').classList.contains('on'))UI.board(true);};
UI.chatMsg=m=>{const d=document.createElement('div');d.className='cm';d.innerHTML=`<b style="color:${esc(teamCol(m.tm))}">${m.team?'[TEAM] ':''}${esc(m.n)}:</b> ${esc(m.m)}`;const c=$id('chatLog');c.appendChild(d);while(c.children.length>7)c.firstChild.remove();setTimeout(()=>d.remove(),9000);};
UI.sysMsg=(m,big)=>{if(big)UI.banner(m,'');else UI.chatMsg({n:'SYSTEM',m,tm:-1});};
UI.openChat=()=>{if(G.state!=='play')return;$id('chatBox').classList.add('on');$id('chatIn').focus();};
UI.closeChat=()=>{$id('chatBox').classList.remove('on');$id('chatIn').blur();$id('chatIn').value='';};
UI.sendChat=()=>{const v=$id('chatIn').value.trim();if(v)send({t:'chat',m:v});UI.closeChat();};
$id('chatGo').onclick=UI.sendChat;
UI.pause=on=>{if(G.state!=='play')return;IN.paused=on;show('pause',on);if(on){INP.mx=INP.my=0;INP.fire=0;IN.fireM=false;IN.fireT.clear();$id('pVoice').textContent=VOICE.on?'VOICE: ON':'VOICE: OFF';}};
UI.voiceToggle=()=>{if(G.state!=='play')return UI.toast('Join a match first, then enable voice');if(VOICE.on){VOICE.disable();window.__vbWantVoice=false;}else{window.__vbWantVoice=true;VOICE.enable();}};
$id('pResume').onclick=()=>UI.pause(false);
$id('pSet').onclick=()=>{show('pause',false);openPage('settings','controls');};
$id('pLeave').onclick=()=>toHub();
{const b=document.createElement('button');b.className='btn ghost';b.id='pVoice';b.textContent='VOICE: OFF';$id('pLeave').before(b);b.onclick=()=>{UI.voiceToggle();setTimeout(()=>b.textContent=VOICE.on?'VOICE: ON':'VOICE: OFF',400);};}
UI.board=on=>{
  const b=$id('board');if(!on||G.state!=='play'){b.classList.remove('on');return;}
  const rows=[...G.roster.values()].filter(r=>r.n);const team=modeIsTeam();let h='';
  const tbl=(title,list,col)=>`<div class="sbh" style="color:${col}">${esc(title)}</div><table class="sb"><tr><th>PLAYER</th><th>K</th><th>D</th></tr>${list.map(r=>`<tr class="${r.i===G.you?'me':''}"><td class="n">${r.v?'🎤 ':''}${esc(r.n)}${r.b?' <small style="color:var(--mut)">BOT</small>':''}</td><td>${r.k}</td><td>${r.d}</td></tr>`).join('')}</table>`;
  if(team){for(const t of [0,1])h+=tbl((t===0?G.cfg.brand.teamA:G.cfg.brand.teamB)+' · '+(G.sc[t]|0),rows.filter(r=>r.t===t).sort((a,c)=>c.k-a.k),teamCol(t));}
  else h+=tbl('PLAYERS'+(G.alive?' · '+G.alive+' alive':''),rows.sort((a,c)=>c.k-a.k),'#fff');
  b.innerHTML=h;b.classList.add('on');
};
UI.matchEnd=e=>{
  const team=modeIsTeam();let head,col,won=false;
  if(team){if(e.win===-1){head='DRAW';col='#fff';}else{won=e.win===G.team;head=won?'VICTORY':'DEFEAT';col=won?'#ffd166':'#ff4d6d';}}
  else{won=e.win===G.you;head=won?'VICTORY':(nm(e.win)+' WINS');col=won?'#ffd166':'#ff4d6d';}
  AUD.play(won?'win':'lose');
  const rows=(e.rows||[]).slice(0,10);
  $id('endBox').innerHTML=`<div class="endh" style="color:${col}">${esc(head)}</div><table class="sb">${'<tr><th>PLAYER</th><th>K</th><th>D</th></tr>'}${rows.map((r,i)=>`<tr class="${r.i===G.you?'me':''}"><td class="n">${roomIsBR()?'#'+(r.pl||i+1)+' ':''}${esc(r.n)}${r.b?' <small style="color:var(--mut)">BOT</small>':''}</td><td>${r.k}</td><td>${r.d}</td></tr>`).join('')}</table>
  <div class="rwd" id="endRw"><div><small>REWARDS</small>…</div></div><div id="endNext" style="text-align:center;color:var(--mut)"></div><div class="row" style="justify-content:center"><button class="btn danger ghost" id="endLv">LEAVE</button></div>`;
  $id('endLv').onclick=()=>toHub();show('end',true);$id('board').classList.remove('on');
};
UI.reward=m=>{if(m.p){G.prof=m.p;}const r=$id('endRw');if(!r)return;r.innerHTML=`<div><small>COINS</small>+${m.coins}</div><div><small>XP</small>+${m.xp}</div>${m.place?`<div><small>PLACE</small>#${m.place}</div>`:''}`;if(m.coins>0)AUD.play('coin');};
/* mini-map */
let miniCache=null,miniMap=null;
UI.drawMini=(others,vp)=>{
  if(S.mini===0){$id('mini').style.display='none';return;}$id('mini').style.display='';
  const cvm=$id('mini'),c=cvm.getContext('2d'),R=cvm.width/2,map=G.map;
  if(miniMap!==map){miniMap=map;const k=3,o=document.createElement('canvas');o.width=map.w*k;o.height=map.h*k;const x=o.getContext('2d');x.fillStyle='#0b1322';x.fillRect(0,0,o.width,o.height);
    for(let ty=0;ty<map.h;ty++)for(let tx=0;tx<map.w;tx++){const ch=map.rows[ty][tx];if(ch==='#'||ch==='X'){x.fillStyle=ch==='#'?'#3d5a96':'#7a6a3a';x.fillRect(tx*k,ty*k,k,k);}else if(ch==='x'){x.fillStyle='#4a4430';x.fillRect(tx*k,ty*k,k,k);}else if(ch==='~'){x.fillStyle='#0d4766';x.fillRect(tx*k,ty*k,k,k);}}miniCache=o;}
  c.clearRect(0,0,cvm.width,cvm.height);c.save();c.beginPath();c.arc(R,R,R-1,0,7);c.clip();c.fillStyle='rgba(5,8,15,.8)';c.fillRect(0,0,cvm.width,cvm.height);
  const view=G.map.br?900:720,sc=R/view,k=3/32;
  c.translate(R,R);c.scale(sc,sc);c.translate(-vp.x,-vp.y);c.imageSmoothingEnabled=false;c.drawImage(miniCache,0,0,map.w*32,map.h*32);
  const b=G.br;if(b){c.strokeStyle='#c07bff';c.lineWidth=3/sc;c.beginPath();c.arc(b.x,b.y,b.r,0,7);c.stroke();c.strokeStyle='#fff';c.lineWidth=1.5/sc;c.beginPath();c.arc(b.nx,b.ny,b.nr,0,7);c.stroke();}
  for(const [id,e] of others){if(e.f&16)continue;const r=G.roster.get(id),mate=modeIsTeam()&&r&&r.t===G.team;c.fillStyle=mate?'#8ff0c3':'#ff4d6d';c.beginPath();c.arc(e.x,e.y,5/sc,0,7);c.fill();}
  if(G.map.zones.length&&modeType()==='zone'){const z=G.map.zones[G.zi];if(z){c.strokeStyle='#ffd166';c.lineWidth=2/sc;c.beginPath();c.arc(z.x,z.y,(G.cfg.modes[G.modeId].zoneRadius||96),0,7);c.stroke();}}
  c.setTransform(1,0,0,1,0,0);c.translate(R,R);c.rotate(G.me.al?G.me.a:0);c.fillStyle='#19e6ff';c.beginPath();c.moveTo(8,0);c.lineTo(-5,-5);c.lineTo(-5,5);c.fill();c.restore();
};
const mmss=s=>{s=Math.max(0,Math.ceil(s));return((s/60)|0)+':'+String(s%60).padStart(2,'0');};
let lastVL='';
UI.hud=(dt,t)=>{
  const me=G.me,cfg=G.cfg,w=cfg.weapons[me.wid]||{},cl=cfg.classes[me.cls]||{},B=cfg.brand,type=modeType();
  const hp=Math.max(0,me.hp),mh=me.mh||100;$id('hpFill').style.transform=`scaleX(${Math.min(1,hp/mh)})`;$id('hpTxt').textContent=Math.ceil(hp);document.querySelector('.hbar:not(.ar)').classList.toggle('low',hp<mh*.3);
  $id('arFill').style.transform=`scaleX(${Math.min(1,me.ar/cfg.player.armorMax)})`;$id('arTxt').textContent=me.ar>0?'ARMOR '+Math.ceil(me.ar):'';
  $id('wName').textContent=(w.name||'').toUpperCase();$id('wAmmo').innerHTML=me.rl>0?'<small>RELOADING</small>':`${me.am}<small> / ${w.mag||''}</small>`;
  const cdT=cl.cd||1,rdy=me.abCD<=0,ab=(cl.ability||'').toUpperCase();$id('wAb').textContent=me.al?(rdy?ab+' READY':ab+' '+Math.ceil(me.abCD)+'s'):'';
  const ar=$id('abRing');if(ar)ar.style.strokeDashoffset=String(107*Math.max(0,Math.min(1,me.abCD/cdT)));$id('tAb').classList.toggle('rdy',rdy&&me.al);
  /* score */
  let sc='';const tl=G.phase==='countdown'?'':mmss(G.tl);
  if(type==='br'){const b=G.br;sc=`<div class="tm"><small>ALIVE</small>${G.alive}</div><div class="tl">${b?'PHASE '+(b.ph+1)+' · '+(b.st==='wait'?'CLOSES IN '+Math.ceil(b.t):'CLOSING '+Math.ceil(b.t)):''}</div><div class="tm"><small>KILLS</small>${me.k}</div>`;}
  else if(modeIsTeam())sc=`<div class="tm" style="color:${teamCol(0)}"><small>${esc(B.teamA)}</small>${G.sc[0]|0}</div><div class="tl">${tl}</div><div class="tm" style="color:${teamCol(1)}"><small>${esc(B.teamB)}</small>${G.sc[1]|0}</div>`;
  else if(type==='gungame')sc=`<div class="tm"><small>GUN LEVEL</small>${me.lv+1}</div><div class="tl">${tl}</div><div class="tm"><small>KILLS</small>${me.k}</div>`;
  else sc=`<div class="tm"><small>KILLS</small>${me.k}</div><div class="tl">${tl}</div><div class="tm"><small>DEATHS</small>${me.d}</div>`;
  if(sc!==UI._sc){UI._sc=sc;$id('hScore').innerHTML=sc;}
  /* countdown */
  if(G.phase==='countdown'){const n=Math.ceil(G.pt);if(n!==lastCount&&n>0){lastCount=n;UI.banner(String(n),'GET READY');AUD.play('beep',false);}}
  /* respawn / spectate */
  const rs=$id('respawn'),sp=$id('spec');
  if(G.sp){sp.textContent='SPECTATING '+nm(G.sp.i).toUpperCase();rs.style.display='block';rs.innerHTML=roomIsBR()?'ELIMINATED'+(me.pl?' · #'+me.pl:''):'';if(!roomIsBR())rs.style.display='none';}
  else{sp.textContent='';if(!me.al&&G.phase==='live'&&!roomIsBR()){rs.style.display='block';rs.textContent='RESPAWN IN '+Math.max(1,Math.ceil(me.rs));}else rs.style.display='none';}
  const en=$id('endNext');if(en&&G.phase==='end')en.textContent='Next match in '+Math.max(0,Math.ceil(G.pt))+'s';
  /* voice */
  const vl=(VOICE.on&&VOICE.talking?`<div class="vl" style="border-color:var(--a)">🎤 You</div>`:'')+[...VOICE.speaking].map(id=>`<div class="vl">🎤 ${esc(nm(id))}</div>`).join('');
  if(vl!==lastVL){lastVL=vl;$id('voiceList').innerHTML=vl;}
  const mc=$id('tMic');mc.classList.toggle('on',VOICE.on);mc.classList.toggle('talk',VOICE.on&&VOICE.talking);
  fpsA+=dt;fpsN++;if(fpsA>.5){fpsT=Math.round(fpsN/fpsA);fpsA=fpsN=0;}
  $id('hPing').textContent=S.showFps?G.ping+' ms':'';$id('hFps').textContent=S.showFps?fpsT+' fps':'';
};
VOICE.listeners.push(()=>{const v=$id('vSt');if(v)v.textContent=VOICE.err||(VOICE.on?(VOICE.micOK?'Voice connected. Teammates always audible, enemies only up close.':'Listening only (no microphone).'):'Voice is off. Join a match, then tap the mic.');});
UI.boot=()=>{UI.intro();};
UI._i={PAGES,PAGEFN,openPage,renderPage,payModal,fmt,NG,items,rars,rcol,rname,owns,show,$id,equipItem,previewItem,hubPreviewSet,SEL,nm,get page(){return page;},get tab(){return tab;},set tab(v){tab=v;}};
})();
