/* Boot + main loop */
(()=>{
  const boot=$('#boot');
  const fail=m=>{boot.style.display='flex';boot.textContent=m;};
  addEventListener('error',e=>{if(G.state==='boot'&&e.message)UI.introFail&&UI.introFail('Error: '+e.message);});
  try{
    if(!R3.init()){boot.remove();UI.intro();UI.introFail('Your browser could not start 3D graphics. Try Chrome, and make sure hardware acceleration is on.');return;}
    UI.introReady('gl');
  }catch(e){boot.remove();UI.intro();UI.introFail('Graphics error: '+e.message);console.error(e);return;}
  boot.remove();UI.intro();IN.applyLayout();
  fetch('/api/config').then(r=>r.json()).then(c=>{if(c&&c.cfg&&!G.cfg){setCfg(c.cfg,c.ice);UI.cfgChanged();}}).catch(()=>{});
  connect();
  let last=performance.now();
  let fa=0,fn=0;const loop=t=>{
    requestAnimationFrame(loop);const dt=Math.min(.1,(t-last)/1000);last=t;fa+=dt;fn++;if(fa>.5){G.fps=Math.round(fn/fa);fa=fn=0;}
    try{
      if(G.state==='play'){IN.update(dt);inputTick(dt);}
      R3.frame(dt,t);
      if(G.state==='play')UI.hud(dt,t);
    }catch(e){console.error('frame',e);}
  };
  requestAnimationFrame(loop);
  const rot=()=>$('#rot').classList.toggle('on',IN.touch&&innerHeight>innerWidth&&G.state==='play');setInterval(rot,1000);
  addEventListener('beforeinstallprompt',e=>{e.preventDefault();window.__installEvt=e;});
  if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('sw.js').catch(()=>{}));
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&G.state==='play'&&IN.touch)UI.pause(true);});
  addEventListener('keydown',e=>{if(e.code==='Tab')e.preventDefault();});
})();
