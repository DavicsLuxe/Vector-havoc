/* Core: shared client state, settings, networking, snapshot handling, prediction/reconciliation. UI and renderer plug into the global UI / R3 objects. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const UI={},R3={};
const TS=VB.TS,DT=VB.DT;
const store={get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v);}catch(e){return d;}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}};
/* ---------- settings (per device) ---------- */
const DEFKEYS={up:'KeyW',down:'KeyS',left:'KeyA',right:'KeyD',jump:'Space',crouch:'KeyC',slide:'ShiftLeft',ability:'KeyQ',reload:'KeyR',grenade:'KeyG',use:'KeyE',revive:'KeyF',swap:'KeyX',streak:'KeyZ',cam:'KeyV',emote:'KeyB',talk:'KeyT',board:'Tab',chat:'Enter',pause:'Escape'};
const S=Object.assign({view:'tps',fov:70,quality:'auto',cam:1,sens:1,aimAssist:null,autoFire:null,leftFire:false,fireSize:null,hand:'right',shadows:true,keys:{},layout:{},showFps:false,mini:1,vib:true},store.get('vb_settings',{}));
S.keys=Object.assign({},DEFKEYS,S.keys||{});
const saveS=()=>store.set('vb_settings',S);
const G={
  cfg:null,ice:null,ws:null,online:0,connected:false,pid:store.get('vb_pid',''),tok:store.get('vb_tok',''),prof:null,
  you:0,team:-1,room:'',priv:false,practice:false,modeId:'',mapDef:null,map:null,pickups:[],roster:new Map(),snaps:[],
  me:{x:0,y:0,vx:0,vy:0,a:0,cls:'ronin',wid:'pistol',dashT:0,dashDx:0,dashDy:0,abCD:0,surge:false,hp:100,mh:100,ar:0,am:0,rl:0,al:0,rs:0,at:0,inv:0,k:0,d:0,lv:0,pl:0,zh:0,z:0,vz:0,st:0,slT:0,slCD:0,aw:'',aa:0,gn:0,ss:0,uv:0,tg:0,sn:0,vh:0,sat:0,pa:0,rvt:0,sq:-1,si:0,mk:0},
  pend:[],seq:0,phase:'countdown',pt:0,tl:0,sc:[0,0],zi:0,zs:-1,alive:0,br:null,sp:null,ping:0,state:'boot',
  kills:[],hitT:0,hitKill:0,dmgT:0,dmgA:0,shake:0,lfcd:0,fireHeld:false,veh:[],pr:[],tgs:[],sqd:[],uvp:null,pitch:.12,yawTarget:null,adsOn:false,emote:null,vehNear:null,lastSnapT:0,popups:[],emoteT:0,lastOthers:new Map(),applied:{css:'',jsv:0},joining:false
};
const wcol=w=>(G.cfg&&G.cfg.weapons[w]&&G.cfg.weapons[w].color)||'#fff';
const teamCol=t=>t===0?G.cfg.brand.accent:t===1?G.cfg.brand.accent2:'#ff4d6d';
const modeType=()=>{const m=G.cfg&&G.cfg.modes[G.modeId];return m?(m.type||G.modeId):'tdm';};
const modeIsTeam=()=>{const t=modeType();return t==='tdm'||t==='zone';};
const roomIsBR=()=>modeType()==='br';
const lagosToday=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Africa/Lagos'}).format(new Date());
/* ---------- network ---------- */
function send(o){if(G.ws&&G.ws.readyState===1)G.ws.send(JSON.stringify(o));}
VOICE.send=send;
let reconTimer=0,pingTimer=0,retry=0;
function connect(){
  if(G.ws&&G.ws.readyState<=1)return;
  const ws=new WebSocket((location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws');G.ws=ws;
  ws.onopen=()=>{retry=0;G.connected=true;send({t:'auth',pid:G.pid,tok:G.tok,name:store.get('vb_name','')});clearInterval(pingTimer);pingTimer=setInterval(()=>send({t:'ping',c:performance.now(),rtt:G.ping,fps:G.fps||0}),2000);UI.conn&&UI.conn(true);};
  ws.onmessage=e=>{let m;try{m=JSON.parse(e.data);}catch(x){return;}try{onMsg(m);}catch(err){console.error('msg',m.t,err);}};
  ws.onclose=()=>{G.connected=false;clearInterval(pingTimer);UI.conn&&UI.conn(false);if(G.state==='play')UI.toHub&&UI.toHub('Connection lost');clearTimeout(reconTimer);reconTimer=setTimeout(connect,Math.min(8000,1000+retry++*1000));};
  ws.onerror=()=>{};
}
function onMsg(m){
  switch(m.t){
    case 'hi':G.online=m.online||0;G.banner=m.banner||'';setCfg(m.cfg,m.ice);UI.cfgChanged&&UI.cfgChanged();break;
    case 'cfg':G.banner=m.banner||'';setCfg(m.cfg,m.ice);UI.cfgChanged&&UI.cfgChanged();break;
    case 'prof':{
      G.prof=m.p;if(m.pid&&m.tok){G.pid=m.pid;G.tok=m.tok;store.set('vb_pid',G.pid);store.set('vb_tok',G.tok);}
      else if(m.pid){G.pid=m.pid;store.set('vb_pid',G.pid);}
      if(m.note)UI.toast(m.note,'good');
      UI.profChanged&&UI.profChanged(m);break;}
    case 'bought':AUD.play('buy');UI.bought&&UI.bought(m.id);break;
    case 'sclaimok':AUD.play('buy');UI.sclaimOk&&UI.sclaimOk(m);break;
    case 'drawok':UI.drawOk&&UI.drawOk(m);break;
    case 'dailyok':AUD.play('reveal');UI.dailyOk&&UI.dailyOk(m);break;
    case 'orderok':AUD.play('buy');UI.orderOk&&UI.orderOk(m.order);break;
    case 'rw':G.reward=m;UI.reward&&UI.reward(m);break;
    case 'w':onWorld(m);break;
    case 's':onSnap(m);break;
    case 'r':G.roster=new Map(m.p.map(p=>[p.i,p]));UI.rosterChanged&&UI.rosterChanged();R3.rosterChanged&&R3.rosterChanged();break;
    case 'pl':VOICE.drop(m.id);break;
    case 'c':UI.chatMsg&&UI.chatMsg(m);break;
    case 'sys':UI.sysMsg&&UI.sysMsg(m.m,m.big);break;
    case 'kick':UI.toHub&&UI.toHub(m.m||'Disconnected');break;
    case 'err':UI.toast(m.m,'bad');G.joining=false;UI.busy&&UI.busy(false);break;
    case 'vg':VOICE.setGains(m.g);break;
    case 'vp':if(m.ice)VOICE.ice=m.ice;VOICE.onPeers(m.ids);break;
    case 'vx':VOICE.drop(m.id);break;
    case 'sig':VOICE.onSig(m.from,m.d);break;
    case 'pong':G.ping=Math.round(performance.now()-m.c);break;
    case 'reload':location.reload();break;
  }
}
/* ---------- config + live custom code ---------- */
function setCfg(cfg,ice){
  if(cfg){
    G.cfg=cfg;AUD.setCfg(cfg);
    const c=cfg.custom||{};
    if(G.applied.css!==c.css){G.applied.css=c.css;let st=$('#customCss');if(!st){st=document.createElement('style');st.id='customCss';document.head.appendChild(st);}st.textContent=c.css||'';}
    if(c.js&&G.applied.jsv!==c.version){const first=!G.applied.jsv;G.applied.jsv=c.version;
      if(first){try{new Function('G','UI','R3','AUD',c.js)(G,UI,R3,AUD);}catch(e){console.error('custom js',e);}}
      else UI.toast&&UI.toast('A game update is ready. Reload to apply.','good');}
  }
  if(ice){G.ice=ice;VOICE.ice=ice;}
}
function onWorld(m){
  VOICE.leaveRoom();
  G.joining=false;G.you=m.you;G.team=m.team;G.room=m.room;G.priv=!!m.priv;G.practice=!!m.practice;G.modeId=m.mode;G.mapDef=m.map;G.map=VB.parseMap(m.map);G.map.br=!!m.map.br;
  G.pickups=m.pickups.map(k=>({...k,up:!!k.up}));G.snaps.length=0;G.pend.length=0;G.seq=0;G.sp=null;G.br=null;G.veh=[];G.pr=[];G.tgs=[];G.sqd=[];G.uvp=null;G.yawTarget=null;G.reward=null;G.endData=null;
  const me=G.me;me.al=0;me.k=0;me.d=0;me.dashT=0;me.abCD=0;me.pl=0;
  G.phase='countdown';G.lastOthers=new Map();G.blips=new Map();
  R3.buildMap&&R3.buildMap();UI.enterGame&&UI.enterGame();
}
/* ---------- snapshots ---------- */
function onSnap(m){
  if(G.state!=='play')return;
  const cfg=G.cfg,map=G.map,me=G.me,s=m.me,now=performance.now();
  G.snaps.push({t:now,p:m.p});if(G.snaps.length>24)G.snaps.shift();
  const wasAlive=me.al;
  me.cls=s.cls;me.wid=s.wid;me.hp=s.hp;me.mh=s.mh||100;me.ar=s.ar;me.am=s.am;me.rl=s.rl;me.al=s.al;me.rs=s.rs;me.at=s.at;me.inv=s.inv;me.k=s.sk;me.d=s.sd;me.lv=s.lv||0;me.pl=s.pl||0;me.zh=s.zh||0;
  me.x=s.x;me.y=s.y;me.vx=s.vx;me.vy=s.vy;me.dashT=s.dt;me.dashDx=s.ddx;me.dashDy=s.ddy;me.abCD=s.cd;me.surge=!!s.sg;
  me.z=s.zz||0;me.vz=s.vz||0;me.slT=s.slt||0;me.slCD=s.slc||0;me.aw=s.aw||'';me.aa=s.aa||0;me.gn=s.gn||0;me.ss=s.ss||0;me.uv=s.uv||0;me.tg=s.tg||0;me.sn=s.sn||0;me.vh=s.vh||0;me.sat=s.sat||0;me.pa=s.pa||0;me.rvt=s.rvt||0;me.sq=s.sq==null?-1:s.sq;me.si=s.si||0;me.mk=s.mk||0;
  G.veh=m.vh||[];G.pr=m.pr||[];G.tgs=m.tgs||[];G.sqd=m.sqd||[];G.uvp=m.uvp||null;G.lastSnapT=now;
  G.phase=m.ph;G.pt=m.pt;G.tl=m.tl;G.sc=m.sc;G.zs=m.zs;G.zi=m.zi;G.alive=m.al||0;G.br=m.br||null;G.sp=m.sp||null;
  G.pend=G.pend.filter(i=>i.seq>m.ack);
  if(me.al&&!me.vh&&!me.pa)for(const i of G.pend)VB.stepInput(me,i,DT,cfg,map);
  if(!wasAlive&&me.al){AUD.play('spawn');R3.snapCam&&R3.snapCam();}
  for(const e of m.ev)onEvent(e);
}
function onEvent(e){
  const me=G.me,cfg=G.cfg,now=performance.now();
  switch(e.e){
    case 's':{
      const mine=e.i===G.you;
      if(!mine){(G.blips||(G.blips=new Map())).set(e.i,{x:e.x,y:e.y,t:now});}
      R3.shot&&R3.shot(e,mine);
      if(!mine)AUD.at('shot',e.x,e.y,G.sp?G.sp.x:me.x,G.sp?G.sp.y:me.y,e.w);
      if(mine){G.shake=Math.min(10,G.shake+(e.w==='shotgun'||e.w==='sniper'?3.5:1.2));}
      break;}
    case 'dm':G.dmgT=now;G.dmgA=e.a;G.shake=Math.min(12,G.shake+4+e.n*.1);AUD.play('hurt');if(S.vib&&navigator.vibrate)try{navigator.vibrate(40);}catch(x){}break;
    case 'ht':G.hitT=now;G.hitKill=e.k;AUD.play('chirp',e.k?'kill':'hit');UI.hitMark&&UI.hitMark(e.k);break;
    case 'k':{UI.killFeed&&UI.killFeed(e);UI.scoreKill&&UI.scoreKill(e);R3.kill&&R3.kill(e);if(e.v===G.you){UI.died&&UI.died(e);}else AUD.at('hurt',e.x,e.y,me.x,me.y);break;}
    case 'pk':{const k=G.pickups[e.id];if(k){k.up=!!e.u;R3.pickup&&R3.pickup(k,e);if(!e.u&&e.by===G.you)AUD.play('pick');}break;}
    case 'ab':{AUD.at(e.k,e.x,e.y,me.x,me.y);R3.ability&&R3.ability(e);if(e.i===G.you&&e.k==='scan')UI.toast('SCAN ONLINE');break;}
    case 'sp':R3.spawnFx&&R3.spawnFx(e);if(e.i===G.you)AUD.play('spawn');break;
    case 'zn':if(e.br){UI.toast('The grid is closing in. Move!','bad');AUD.play('storm');}else{UI.toast('GRID ZONE RELOCATED');AUD.play('zone');}break;
    case 'go':UI.banner&&UI.banner(roomIsBR()?'DROP IN':'GO','');AUD.play('beep',true);break;
    case 'rl':if(e.i===G.you)AUD.play('reload');else{const p=G.lastOthers.get(e.i);if(p)AUD.at('reload',p.x,p.y,me.x,me.y);}break;
    case 'rk':R3.rocket&&R3.rocket(e);AUD.at('boom',e.x,e.y,G.sp?G.sp.x:me.x,G.sp?G.sp.y:me.y);break;
    case 'gt':AUD.at('whoosh',me.x,me.y,me.x,me.y);break;
    case 'ex':{R3.explode&&R3.explode(e);const vx=G.sp||me,d=Math.hypot(e.x-vx.x,e.y-vx.y);G.shake=Math.min(26,G.shake+Math.max(0,22*(1-d/(e.r*5+200))));AUD.at('boom',e.x,e.y,vx.x,vx.y);break;}
    case 'vi':R3.sparks&&R3.sparks(e.x,e.y,'#ffb347',14);AUD.at('hurt',e.x,e.y,me.x,me.y);G.shake=Math.min(12,G.shake+3);break;
    case 'cr':R3.sparks&&R3.sparks(e.x,e.y,'#ff4d6d',16);AUD.at('hurt',e.x,e.y,me.x,me.y);break;
    case 've':if(e.i===G.you){G.yawTarget='veh';UI.toast('Entered '+((G.cfg.vehicles[e.k]||{}).name||'vehicle')+'. [E] to exit','good');AUD.play('click');}break;
    case 'vx':if(e.i===G.you)UI.toast('Exited vehicle');break;
    case 'ld':R3.dust&&R3.dust(e.x,e.y);if(e.i===G.you)AUD.play('step',1,0);break;
    case 'sl':if(e.i!==G.you){const p=G.lastOthers.get(e.i);if(p)AUD.at('dash',p.x,p.y,me.x,me.y);}else AUD.play('whoosh');break;
    case 'sw':if(e.i===G.you)AUD.play('click');break;
    case 'dt':UI.banner&&UI.banner(e.n+' IS DOWN','COLLECT THEIR DOG TAG');AUD.play('storm');break;
    case 'tc':UI.banner&&UI.banner('DOG TAG COLLECTED',e.n);AUD.play('pick');break;
    case 'rv':UI.toast('Revival flight inbound for '+e.n+' ('+Math.round(e.t)+'s)','good');AUD.play('zone');break;
    case 'rvd':UI.banner&&UI.banner(e.i===G.you?'YOU ARE BACK':e.n+' REDEPLOYED','PARACHUTE INBOUND');R3.beam&&R3.beam(e.x,e.y,'#8ff0c3');AUD.play('reveal');break;
    case 'uav':UI.toast(e.i===G.you?'UAV ONLINE':'Friendly UAV online','good');AUD.play('scan');break;
    case 'em':R3.emote&&R3.emote(e.i,e.k);break;
    case 'end':UI.matchEnd&&UI.matchEnd(e);break;
  }
}
/* ---------- fixed-rate input + prediction ---------- */
const INP={mx:0,my:0,a:0,fire:0,ab:false,rl:false,acc:0,j:0,c:0,sl:0,sw:false,gr:false,use:false,rv:0,ssb:false,ads:0};
function inputTick(dt){
  if(G.state!=='play'||!G.ws||G.ws.readyState!==1)return;
  INP.acc+=dt;let n=0;
  while(INP.acc>=DT&&n<4){
    INP.acc-=DT;n++;
    const i={seq:++G.seq,mx:INP.mx,my:INP.my,a:INP.a,fire:UI.typing&&UI.typing()?0:INP.fire,ab:INP.ab?1:0,rl:INP.rl?1:0,j:INP.j?1:0,c:INP.c?1:0,sl:INP.sl?1:0,sw:INP.sw?1:0,gr:INP.gr?1:0,use:INP.use?1:0,rv:INP.rv?1:0,ssb:INP.ssb?1:0,ads:INP.ads?1:0};
    INP.ab=false;INP.rl=false;INP.sw=false;INP.gr=false;INP.ssb=false;INP.sl=0;
    const me=G.me;
    if(me.al&&!me.vh&&!me.pa){VB.stepInput(me,i,DT,G.cfg,G.map);
      if(G.lfcd>0)G.lfcd-=DT;
      const w=G.cfg.weapons[me.wid];
      if(i.fire&&w&&G.lfcd<=0&&me.am>0&&me.rl<=0&&G.phase==='live'&&(w.auto||!G.fireHeld)){G.lfcd=60/w.rpm;if(w.proj!=='rocket')AUD.play('shot',me.wid,.8,0);R3.localKick&&R3.localKick();}
      G.fireHeld=!!i.fire;
    }
    G.pend.push(i);if(G.pend.length>90)G.pend.shift();
    send({t:'in',seq:i.seq,mx:+i.mx.toFixed(3),my:+i.my.toFixed(3),a:+i.a.toFixed(3),fire:i.fire,ab:i.ab,rl:i.rl,j:i.j,c:i.c,sl:i.sl,sw:i.sw,gr:i.gr,use:i.use,rv:i.rv,ssb:i.ssb,ads:i.ads});
  }
  if(n>=4)INP.acc=0;
}
/* interpolated view of everyone else (100 ms behind the newest snapshot) */
function viewOthers(){
  const rt=performance.now()-100,sn=G.snaps,out=new Map();
  if(!sn.length)return out;
  let a=sn[0],b=sn[sn.length-1];
  for(let i=sn.length-1;i>0;i--){if(sn[i-1].t<=rt){a=sn[i-1];b=sn[i];break;}a=sn[i-1];b=sn[i];}
  const k=b.t===a.t?1:Math.max(0,Math.min(1.2,(rt-a.t)/(b.t-a.t)));
  const am=new Map(a.p.map(e=>[e.i,e]));
  for(const e of b.p){
    const o=am.get(e.i);
    if(o&&!(e.f&16)&&!(o.f&16)){let da=e.a-o.a;while(da>Math.PI)da-=2*Math.PI;while(da<-Math.PI)da+=2*Math.PI;
      out.set(e.i,{...e,x:o.x+(e.x-o.x)*k,y:o.y+(e.y-o.y)*k,a:o.a+da*k});}
    else out.set(e.i,e);
  }
  G.lastOthers=out;return out;
}
/* recovery code so a player can restore their profile on another device */
const recoveryCode=()=>G.pid&&G.tok?btoa(JSON.stringify([G.pid,G.tok])).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''):'';
