/* Input: keyboard + mouse (desktop) and multi-touch controls (phones). FIRE is a tap/hold button; aiming is a separate swipe, so shooting never depends on dragging. */
const IN={keys:{},mouse:{x:innerWidth/2,y:innerHeight/2,has:false},fireM:false,fireT:new Set(),adsT:new Set(),adsM:false,tj:false,tc:false,tu:false,tr:false,wheel:false,touch:false,stick:{id:null,sx:0,sy:0,dx:0,dy:0},aimT:new Map(),talkHeld:false,paused:false,listen:null,edit:false,lastAimA:0};
IN.touch=matchMedia('(pointer:coarse)').matches||'ontouchstart' in window;
document.body.classList.toggle('touch',IN.touch);
IN.look=(dx,dy)=>{if(IN.wheel||IN.paused)return;G.yaw=(G.yaw||0)+dx;G.pitch=Math.max(-.55,Math.min(.95,(G.pitch||0)-dy*(S.invertY?-1:1)));G.lookDX=(G.lookDX||0)+dx*1000;G.lookDY=(G.lookDY||0)+dy*1000;G.lookT=performance.now();};
const ctrl=()=>G.cfg&&G.cfg.controls||{};
const aimAssistLvl=()=>S.aimAssist!=null?S.aimAssist:(ctrl().aimAssist!=null?ctrl().aimAssist:.5);
const autoFireOn=()=>S.autoFire!=null?S.autoFire:!!ctrl().defaultAutoFire;
const fireSize=()=>S.fireSize||ctrl().fireSize||84;
const typing=()=>document.activeElement&&document.activeElement.tagName==='INPUT';
UI.typing=()=>typing()&&G.state==='play';
IN.canPlay=()=>G.state==='play'&&!IN.paused&&!UI.modalOpen;
/* ---------- keyboard ---------- */
addEventListener('keydown',e=>{
  if(IN.listen){e.preventDefault();IN.listen(e.code);return;}
  if(typing()){if(e.code==='Enter'&&G.state==='play'){UI.sendChat();e.preventDefault();}else if(e.code==='Escape'){UI.closeChat();}return;}
  if(G.state!=='play')return;
  const K=S.keys;IN.keys[e.code]=true;
  if(e.code===K.pause){UI.pause(!IN.paused);e.preventDefault();return;}
  if(IN.paused)return;
  if(e.code===K.ability)INP.ab=true;else if(e.code===K.reload)INP.rl=true;
  else if(e.code===K.slide){if(!e.repeat)INP.sl=1;}
  else if(e.code===K.grenade){if(!e.repeat)INP.gr=true;}
  else if(e.code===K.swap){if(!e.repeat)INP.sw=true;}
  else if(e.code===K.streak){if(!e.repeat)INP.ssb=true;}
  else if(e.code===K.cam){if(!e.repeat)UI.cycleView&&UI.cycleView();}
  else if(e.code===K.emote){if(!e.repeat)UI.wheel&&UI.wheel(true);}
  else if(e.code===K.board){UI.board(true);e.preventDefault();}
  else if(e.code===K.talk){VOICE.ptt(true);}
  else if(e.code===K.chat){UI.openChat();e.preventDefault();}
  if(e.code==='Tab'||e.code==='Space'||e.code==='ShiftLeft'||e.code.startsWith('Arrow'))e.preventDefault();
});
addEventListener('keyup',e=>{IN.keys[e.code]=false;if(e.code===S.keys.emote&&UI.wheel)UI.wheel(false);if(e.code===S.keys.board)UI.board(false);if(e.code===S.keys.talk)VOICE.ptt(false);});
addEventListener('blur',()=>{IN.keys={};IN.fireM=false;IN.adsM=false;VOICE.ptt(false);});
/* ---------- mouse ---------- */
const cv=$('#gl');
addEventListener('pointermove',e=>{if(e.pointerType==='mouse'){IN.mouse.x=e.clientX;IN.mouse.y=e.clientY;IN.mouse.has=true;}});
cv.addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse')return;AUD.unlock();
  if(G.state==='play'&&S.view!=='top'&&document.pointerLockElement!==cv&&!IN.paused&&!UI.modalOpen){try{cv.requestPointerLock();}catch(x){}return;}
  if(e.button===0)IN.fireM=true;if(e.button===2&&S.view!=='top')IN.adsM=true;});
addEventListener('pointerup',e=>{if(e.pointerType==='mouse'){if(e.button===0)IN.fireM=false;if(e.button===2)IN.adsM=false;}});
cv.addEventListener('contextmenu',e=>e.preventDefault());
cv.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&e.button===2&&S.view==='top')INP.ab=true;});
/* look: pointer lock mouse movement drives yaw and pitch in first/third person */
addEventListener('mousemove',e=>{if(G.state!=='play'||document.pointerLockElement!==cv||IN.paused||UI.modalOpen)return;IN.look(e.movementX*.0022*S.sens*(S.invertY?1:1),e.movementY*.002*S.sens);});
document.addEventListener('pointerlockchange',()=>{if(document.pointerLockElement===cv)IN.wasLocked=true;else if(IN.wasLocked){IN.wasLocked=false;IN.fireM=false;IN.adsM=false;if(G.state==='play'&&!IN.paused&&!UI.modalOpen)UI.pause(true);}});
/* hub: drag the soldier to rotate */
{let down=false,lx=0;
 addEventListener('pointerdown',e=>{if(G.state==='play'||e.target.closest('button,.pg,.modal,.card,input,select'))return;if(e.target.id==='gl'||e.target.id==='hub'){down=true;lx=e.clientX;R3.hubDragging=true;}});
 addEventListener('pointermove',e=>{if(down&&G.state!=='play'){R3.hubDrag(e.clientX-lx);lx=e.clientX;}});
 addEventListener('pointerup',()=>{if(down){down=false;R3.hubDragEnd();}});}
/* ---------- touch ---------- */
const stickEl=$('#stick'),knob=$('#stick i'),zoneS=$('#stickZone'),zoneA=$('#aimZone');
const FIRE=['#tFire','#tFire2'].map(s=>$(s));
function hold(el,on){el.classList.toggle('hold',on);}
function aimFromDelta(id,t){
  const st=IN.aimT.get(id);if(!st)return;
  const dx=t.clientX-st.x,dy=t.clientY-st.y;
  if(S.view!=='top'){IN.look((t.clientX-st.lx)*.0042*S.sens,(t.clientY-st.ly)*.0036*S.sens);st.lx=t.clientX;st.ly=t.clientY;}
  else if(S.aimMode==='rotate'){const d=Math.hypot(t.clientX-st.lx,t.clientY-st.ly);INP.a+=(t.clientX-st.lx)*.012*S.sens;st.lx=t.clientX;st.ly=t.clientY;}
  else{const d=Math.hypot(dx,dy);if(d>10)INP.a=Math.atan2(dy,dx);}
}
if(IN.touch){
  zoneS.addEventListener('pointerdown',e=>{if(IN.stick.id!=null||!IN.canPlay())return;e.preventDefault();AUD.unlock();try{zoneS.setPointerCapture(e.pointerId);}catch(x){};const s=IN.stick;s.id=e.pointerId;s.sx=e.clientX;s.sy=e.clientY;s.dx=s.dy=0;stickEl.style.display='block';stickEl.style.left=e.clientX+'px';stickEl.style.top=e.clientY+'px';knob.style.transform='';});
  zoneS.addEventListener('pointermove',e=>{const s=IN.stick;if(e.pointerId!==s.id)return;let dx=e.clientX-s.sx,dy=e.clientY-s.sy;const m=Math.hypot(dx,dy),R=55;if(m>R){dx=dx/m*R;dy=dy/m*R;}s.dx=dx/R;s.dy=dy/R;knob.style.transform=`translate(${dx}px,${dy}px)`;});
  const endS=e=>{const s=IN.stick;if(e.pointerId!==s.id)return;s.id=null;s.dx=s.dy=0;stickEl.style.display='none';};
  zoneS.addEventListener('pointerup',endS);zoneS.addEventListener('pointercancel',endS);
  /* swipe zone: swipe to aim */
  zoneA.addEventListener('pointerdown',e=>{if(!IN.canPlay())return;e.preventDefault();AUD.unlock();try{zoneA.setPointerCapture(e.pointerId);}catch(x){};IN.aimT.set(e.pointerId,{x:e.clientX,y:e.clientY,lx:e.clientX,ly:e.clientY});});
  zoneA.addEventListener('pointermove',e=>aimFromDelta(e.pointerId,e));
  const endA=e=>IN.aimT.delete(e.pointerId);zoneA.addEventListener('pointerup',endA);zoneA.addEventListener('pointercancel',endA);
  /* FIRE buttons: pressing = firing (instant, no drag needed). Moving the same finger also aims, like other mobile shooters. */
  for(const el of FIRE){
    el.addEventListener('pointerdown',e=>{if(IN.edit)return;e.preventDefault();e.stopPropagation();AUD.unlock();try{el.setPointerCapture(e.pointerId);}catch(x){};IN.fireT.add(e.pointerId);IN.aimT.set(e.pointerId,{x:e.clientX,y:e.clientY,lx:e.clientX,ly:e.clientY,btn:1});hold(el,true);if(S.vib&&navigator.vibrate)try{navigator.vibrate(8);}catch(x){}});
    el.addEventListener('pointermove',e=>{if(IN.fireT.has(e.pointerId))aimFromDelta(e.pointerId,e);});
    const up=e=>{IN.fireT.delete(e.pointerId);IN.aimT.delete(e.pointerId);hold(el,false);};
    el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);
  }
  const tap=(sel,down,up)=>{const el=$(sel);el.addEventListener('pointerdown',e=>{if(IN.edit)return;e.preventDefault();e.stopPropagation();AUD.unlock();hold(el,true);down&&down();});const u=()=>{hold(el,false);up&&up();};el.addEventListener('pointerup',u);el.addEventListener('pointercancel',u);};
  tap('#tAb',()=>INP.ab=true);tap('#tRl',()=>INP.rl=true);tap('#tSb',()=>UI.board(true),()=>UI.board(false));tap('#tMic',()=>{if(VOICE.on)VOICE.ptt(true);else UI.voiceToggle();},()=>VOICE.ptt(false));
  tap('#tChat',()=>UI.openChat());tap('#tPause',()=>UI.pause(true));
  tap('#tJump',()=>{INP.j=1;IN.tj=true;},()=>{IN.tj=false;});tap('#tCrouch',()=>{IN.tc=!IN.tc;$('#tCrouch').classList.toggle('on',IN.tc);});tap('#tSlide',()=>{INP.sl=1;});
  tap('#tGren',()=>INP.gr=true);tap('#tSwap',()=>INP.sw=true);tap('#tUse',()=>{IN.tu=true;},()=>{IN.tu=false;});tap('#tCam',()=>UI.cycleView&&UI.cycleView());
  tap('#tStreak',()=>INP.ssb=true);tap('#tRev',()=>{IN.tr=true;},()=>{IN.tr=false;});tap('#tEmo',()=>UI.wheel&&UI.wheel(!IN.wheel));
  {const el=$('#tAds');el.addEventListener('pointerdown',e=>{if(IN.edit)return;e.preventDefault();e.stopPropagation();AUD.unlock();try{el.setPointerCapture(e.pointerId);}catch(x){};IN.adsT.add(e.pointerId);IN.fireT.add(e.pointerId);IN.aimT.set(e.pointerId,{x:e.clientX,y:e.clientY,lx:e.clientX,ly:e.clientY,btn:1});hold(el,true);if(S.vib&&navigator.vibrate)try{navigator.vibrate(8);}catch(x){}});
    el.addEventListener('pointermove',e=>{if(IN.adsT.has(e.pointerId))aimFromDelta(e.pointerId,e);});
    const up=e=>{IN.adsT.delete(e.pointerId);IN.fireT.delete(e.pointerId);IN.aimT.delete(e.pointerId);hold(el,false);};el.addEventListener('pointerup',up);el.addEventListener('pointercancel',up);}
}
/* layout editor for touch buttons (saved per device) */
const BTN_IDS=['tFire','tFire2','tAds','tAb','tRl','tSb','tChat','tMic','tPause','tJump','tCrouch','tSlide','tGren','tSwap','tUse','tCam','tStreak','tRev','tEmo'];
IN.applyLayout=()=>{
  document.documentElement.style.setProperty('--fs',fireSize()+'px');document.documentElement.style.setProperty('--ms',(110+S.mini*30)+'px');
  document.body.classList.toggle('leftfire',!!S.leftFire);
  for(const id of BTN_IDS){const el=document.getElementById(id),p=S.layout[id];if(!el)continue;
    if(p){el.style.left=p.x+'%';el.style.top=p.y+'%';el.style.right='auto';el.style.bottom='auto';}else{el.style.left=el.style.top=el.style.right=el.style.bottom='';}}
};
IN.setEdit=on=>{IN.edit=on;document.body.classList.toggle('edit',on);};
for(const id of BTN_IDS){const el=document.getElementById(id);let drag=null;
  el.addEventListener('pointerdown',e=>{if(!IN.edit)return;e.preventDefault();e.stopPropagation();try{el.setPointerCapture(e.pointerId);}catch(x){};drag=e.pointerId;});
  el.addEventListener('pointermove',e=>{if(!IN.edit||drag!==e.pointerId)return;const w=el.offsetWidth,h=el.offsetHeight;const x=Math.max(0,Math.min(100-w/innerWidth*100,(e.clientX-w/2)/innerWidth*100)),y=Math.max(0,Math.min(100-h/innerHeight*100,(e.clientY-h/2)/innerHeight*100));S.layout[id]={x:+x.toFixed(1),y:+y.toFixed(1)};IN.applyLayout();});
  el.addEventListener('pointerup',()=>{if(drag!=null){drag=null;saveS();}});}
/* ---------- per-frame input -> INP ---------- */
function bestTarget(range,cone){
  const me=G.me,vp=me;let best=null,bd=1e9;
  for(const [id,e] of G.lastOthers){if(!(e.f&1)||(e.f&2)||(e.f&16))continue;const r=G.roster.get(id);if(modeIsTeam()&&r&&r.t===G.team)continue;
    const dx=e.x-me.x,dy=e.y-me.y,d=Math.hypot(dx,dy);if(d>range||d<10)continue;
    let da=Math.atan2(dy,dx)-INP.a;while(da>Math.PI)da-=TAU2;while(da<-Math.PI)da+=TAU2;if(Math.abs(da)>cone)continue;
    if(!VB.los(G.map,me.x,me.y,e.x,e.y))continue;const sc=d*(1+Math.abs(da)*2);if(sc<bd){bd=sc;best={a:Math.atan2(dy,dx),d,da};}}
  return best;
}
const TAU2=Math.PI*2;
IN.update=dt=>{
  if(G.state!=='play')return;
  const dead=!G.me.al||G.sp;
  if(IN.paused||UI.modalOpen||UI.typing()){INP.mx=INP.my=0;INP.fire=0;INP.j=0;INP.c=0;INP.rv=0;INP.use=false;INP.ads=0;return;}
  const K=S.keys,view=S.view,third=view!=='top',me=G.me;
  /* movement: screen axes (top view) or camera-relative (first / third person). Vehicles always take raw stick input: up = throttle, left/right = steer. */
  let mx=0,my=0;
  if(IN.keys[K.left])mx-=1;if(IN.keys[K.right])mx+=1;if(IN.keys[K.up])my-=1;if(IN.keys[K.down])my+=1;
  if(IN.touch&&IN.stick.id!=null){mx+=IN.stick.dx;my+=IN.stick.dy;}
  const m=Math.hypot(mx,my);if(m>1){mx/=m;my/=m;}if(m>0&&m<.12){mx=my=0;}
  if(third&&!me.vh){const yaw=G.yaw||0,cy=Math.cos(yaw),sy=Math.sin(yaw),fwd=-my,rt=mx;INP.mx=fwd*cy-rt*sy;INP.my=fwd*sy+rt*cy;}
  else{INP.mx=mx;INP.my=my;}
  /* aim: top view projects the mouse onto the ground; first/third person aims through the camera (see the renderer) */
  if(!third){if(!IN.touch&&IN.mouse.has){const w=R3.pointerToWorld(IN.mouse.x,IN.mouse.y);if(w)INP.a=Math.atan2(w.y-G.me.y,w.x-G.me.x);}G.yaw=INP.a;}
  else if(G.yaw==null)G.yaw=INP.a;
  /* stance + actions */
  INP.j=(IN.keys[K.jump]||IN.tj)?1:0;INP.c=(IN.keys[K.crouch]||IN.tc)?1:0;INP.use=!!(IN.keys[K.use]||IN.tu);INP.rv=(IN.keys[K.revive]||IN.tr)?1:0;
  if(me.vh||me.pa){INP.c=INP.c;}
  INP.ads=((IN.adsM||IN.adsT.size>0)&&!me.vh&&!me.pa)?1:0;
  /* fire */
  let fire=IN.fireM||IN.fireT.size>0;
  const w=G.cfg.weapons[G.me.wid];
  if(IN.touch&&autoFireOn()&&w&&!fire){const t=bestTarget(Math.min(w.range||700,520),.5);if(t){fire=true;}}
  const lvl=aimAssistLvl();
  if(fire&&lvl>0&&w&&!third){const t=bestTarget(Math.min(w.range||700,560),.12+lvl*.28);if(t){let da=t.a-INP.a;while(da>Math.PI)da-=TAU2;while(da<-Math.PI)da+=TAU2;INP.a+=da*Math.min(1,lvl*.35+dt*6*lvl);}}
  else if(fire&&lvl>0&&w&&third&&IN.touch){const t=bestTarget(Math.min(w.range||700,560),.1+lvl*.12);if(t){let da=t.a-INP.a;while(da>Math.PI)da-=TAU2;while(da<-Math.PI)da+=TAU2;G.yaw+=da*Math.min(.12,lvl*.06+dt*lvl*.8);}}
  INP.fire=(fire&&!dead&&!IN.wheel)?1:0;
  if(R3.emoteActive&&R3.emoteActive()&&(INP.mx||INP.my||INP.fire||INP.j))R3.cancelEmote();
};
