/* Developer console v2. All edits are sent to the server, which validates them; the PIN-issued token is the only authority. */
(()=>{
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let token=sessionStorage.getItem('vb_dev')||'',S=null,C=null,orig='',tab='live',curMap='',tool='#',mirror=true,painting=false,undo=[],orders=[],profs=[],liveT=0;
const CELL=14;
const TABS=[['live','Live'],['analytics','Analytics'],['orders','Orders'],['players','Players'],['store','Store'],['daily','Daily rewards'],['ops','Operators'],['weap','Weapons'],['studio','Gun Studio'],['season','Seasons'],['modes','Modes'],['maps','Maps'],['brand','Branding'],['app','App & logo'],['match','Match & controls'],['code','Code & updates'],['music','Music'],['sec','Security & backup'],['raw','Raw JSON']];
const TILES=[['.','Floor','#16264a'],['#','Wall','#4f6fae'],['x','Low cover','#7a6842'],['X','Container / tree','#c4562a'],['~','Water','#0b4766'],['A','Spawn A','#19e6ff'],['B','Spawn B','#ff9d1a'],['F','FFA spawn','#c9a7ff'],['Z','Zone point','#fff'],['h','Health','#ff4d6d'],['a','Armor','#19e6ff'],['w','Weapon','#ffd166'],['c','Crate','#8ff0c3']];
const ABIL=['dash','cloak','surge','scan'],THEMES=['neon','dock','city','bridge','open'],MODELS=['launcher','pistol','revolver','smg','rifle','shotgun','lmg','sniper'],HEADS=['','cap','fila','helmet','gele','durag','beanie','mask','afro','braids','crown'],PATS=['solid','ankara','camo','stripes','gold','checker'],SLOTS=['neck','face','ear','wrist'];
function toast(m,bad){const t=$('#toast');t.textContent=m;t.className=bad?'bad':'';t.style.display='block';clearTimeout(toast.h);toast.h=setTimeout(()=>t.style.display='none',3500);}
async function api(path,method='GET',body){
  const r=await fetch('/api/dev/'+path,{method,headers:Object.assign({Authorization:'Bearer '+token},body!==undefined?{'Content-Type':'application/json'}:{}),body:body!==undefined?JSON.stringify(body):undefined});
  let j={};try{j=await r.json();}catch(e){}
  if(r.status===401&&path!=='login'){signOut();throw new Error('Signed out');}
  if(!r.ok)throw new Error(j.error||('HTTP '+r.status));return j;}
function signOut(){token='';sessionStorage.removeItem('vb_dev');$('#app').style.display='none';$('#login').style.display='flex';clearInterval(liveT);}
async function login(){$('#err').textContent='';try{const j=await api('login','POST',{pin:$('#pin').value});token=j.token;sessionStorage.setItem('vb_dev',token);$('#pin').value='';await boot();}catch(e){$('#err').textContent=e.message;}}
async function boot(){
  try{S=await api('state');}catch(e){return;}
  $('#login').style.display='none';$('#app').style.display='block';
  C=JSON.parse(JSON.stringify(S.config));orig=JSON.stringify(C);curMap=C.maps[curMap]?curMap:C.mapOrder[0]||Object.keys(C.maps)[0];
  nav();render();clearInterval(liveT);liveT=setInterval(poll,3000);poll();
}
async function poll(){try{const o=await api('orders');orders=o.orders;const n=orders.filter(x=>x.status==='pending').length;nav();if(tab==='orders')ordersR();if(tab==='live'||tab==='analytics'){S=Object.assign(S,await api('state'));S.config=C;anPush();tab==='live'?liveR():analyticsR();}}catch(e){}}
function nav(){const pend=orders.filter(x=>x.status==='pending').length;$('#nav').innerHTML=TABS.map(([id,n])=>`<button data-t="${id}" class="${id===tab?'on':''}">${n}${id==='orders'&&pend?`<span class="badge">${pend}</span>`:''}</button>`).join('');}
const dirty=()=>{const d=JSON.stringify(C)!==orig;$('#dirty').textContent=d?'● unsaved changes':'';return d;};
const R={analytics:analyticsR,studio:studioR,season:seasonR,live:liveR,orders:ordersR,players:playersR,store:storeR,daily:dailyR,ops:opsR,weap:weapR,modes:modesR,maps:mapsR,brand:brandR,app:appR,match:matchR,code:codeR,music:musicR,sec:secR,raw:rawR};
function render(){nav();$('#main').innerHTML=`<section class="tab on" id="tabbody"></section>`;R[tab]();dirty();}
/* ---- field helpers: data-p is a dotted path into C ---- */
const get=(o,p)=>p.split('.').reduce((a,k)=>a&&a[k],o);
function set(o,p,v){const k=p.split('.'),l=k.pop();k.reduce((a,x)=>a[x],o)[l]=v;}
const F=(p,label,type='text',o={})=>{const v=get(C,p);const w=o.w?` ${o.w}`:'';
  if(type==='bool')return`<label class="f${w}">${label}<input type="checkbox" data-p="${p}" data-ty="bool" ${v?'checked':''}></label>`;
  if(type==='color')return`<label class="f${w}">${label}<input type="color" data-p="${p}" data-ty="str" value="${esc(v||'#ffffff')}"></label>`;
  if(type==='area')return`<label class="f${w||' w4'}">${label}<textarea data-p="${p}" data-ty="str" rows="${o.rows||4}">${esc(v)}</textarea></label>`;
  if(type==='select')return`<label class="f${w}">${label}<select data-p="${p}" data-ty="str">${o.opts.map(x=>`<option value="${esc(x)}" ${x===v?'selected':''}>${esc(x||'(none)')}</option>`).join('')}</select></label>`;
  if(type==='csv')return`<label class="f${w}">${label}<input data-p="${p}" data-ty="csv" value="${esc((v||[]).join(', '))}"></label>`;
  if(type==='num')return`<label class="f${w}">${label}<input type="number" step="any" data-p="${p}" data-ty="num" value="${esc(v)}"></label>`;
  return`<label class="f${w}">${label}<input data-p="${p}" data-ty="str" value="${esc(v)}" ${o.max?`maxlength="${o.max}"`:''}></label>`;};
document.addEventListener('input',e=>{const t=e.target,p=t.dataset&&t.dataset.p;if(!p||!C)return;const ty=t.dataset.ty;
  let v=ty==='bool'?t.checked:ty==='num'?(t.value===''?0:+t.value):ty==='csv'?t.value.split(',').map(x=>x.trim()).filter(x=>x!=='').map(Number):t.value;set(C,p,v);dirty();});
document.addEventListener('change',e=>{const t=e.target;if(t.dataset&&t.dataset.rr)render();});
/* ---- actions ---- */
const act=async o=>{try{await api('act','POST',o);toast('Done');if(tab==='live')poll();}catch(e){toast(e.message,true);}};
async function save(){
  try{const j=await api('config','POST',{config:C});C=JSON.parse(JSON.stringify(j.config));orig=JSON.stringify(C);toast('Published. Players have the update now.');render();}catch(e){toast('Not saved: '+e.message,true);}}
document.addEventListener('click',async e=>{
  const t=e.target.closest('button');if(!t)return;
  if(t.id==='go')return login();if(t.id==='out')return signOut();if(t.id==='save')return save();
  if(t.id==='discard'){C=JSON.parse(orig);render();return;}
  if(t.dataset.t){tab=t.dataset.t;render();if(tab==='analytics')poll();return;}
  const d=t.dataset;
  if(d.act){const o=JSON.parse(d.act);if(o.confirm&&!confirm(o.confirm))return;delete o.confirm;return act(o);}
  if(d.fn&&FN[d.fn])return FN[d.fn](d,t);
});
$('#pin').addEventListener('keydown',e=>{if(e.key==='Enter')login();});
/* ===== LIVE ===== */
function liveR(){
  const el=$('#tabbody');if(!el||tab!=='live')return;
  el.innerHTML=`<div class="card"><h3>Server</h3><div class="row"><span class="pill">${S.online} players online</span><span class="pill">${S.rooms.length} rooms</span><span class="pill">${S.profiles} accounts</span><span class="pill pending">${S.pending} pending orders</span><span class="pill">uptime ${Math.round(S.uptime/60)} min</span><span class="pill">${esc(S.persist.dataDir)}</span></div>
  ${S.pinIsDefault?'<p class="bad" style="color:var(--rd)">You are still using the default PIN. Change it in Security.</p>':''}
  <div class="row" style="margin-top:10px"><input id="say" placeholder="Announcement to everyone" style="flex:1;min-width:200px"><button data-fn="say">Send</button><input id="ban" placeholder="Top banner text" value="${esc(S.banner||'')}" style="flex:1;min-width:200px"><button data-fn="banner">Set banner</button></div>
  <div class="row" style="margin-top:10px"><label class="row"><input type="checkbox" ${S.locked?'checked':''} onchange="fetch('/api/dev/act',{method:'POST',headers:{Authorization:'Bearer '+sessionStorage.getItem('vb_dev'),'Content-Type':'application/json'},body:JSON.stringify({a:'lock',v:this.checked})})"> Lock server (maintenance)</label><button data-act='{"a":"reload","confirm":"Force every player to reload the game?"}'>Force all players to reload</button></div></div>
  ${S.rooms.map(r=>`<div class="card"><div class="row"><h3>Room ${esc(r.code)}</h3><span class="pill">${esc(r.mode)}</span><span class="pill">${esc(r.map)}</span><span class="pill">${r.practice?'practice':r.priv?'private':'public'}</span><span class="pill">${esc(r.phase)} ${r.tl}s</span><span style="flex:1"></span><button class="sm" data-fn="fill" data-code="${r.code}">Rebalance bots</button><button class="sm" data-fn="restartRoom" data-code="${r.code}">Restart match</button><button class="sm bad" data-act='{"a":"closeRoom","code":"${r.code}","confirm":"Close this room and disconnect everyone?"}'>Close</button></div>
  <table><tr><th>Player</th><th>Team</th><th>K</th><th>D</th><th></th></tr>${r.players.map(p=>`<tr><td>${p.voice?'🎤 ':''}${esc(p.name)}${p.bot?' <span class="pill">bot</span>':''}</td><td>${p.team}</td><td>${p.k}</td><td>${p.d}</td><td>${p.bot?'':`<button class="sm" data-act='{"a":"kick","id":${p.id},"m":"Removed by an admin"}'>Kick</button> <button class="sm bad" data-act='{"a":"ban","id":${p.id},"confirm":"Ban this player's IP?"}'>Ban</button>`}</td></tr>`).join('')}</table></div>`).join('')||'<p class="muted">No rooms right now.</p>'}
  ${S.bans.length?`<div class="card"><h3>Banned IPs</h3>${S.bans.map(ip=>`<span class="pill">${esc(ip)} <button class="sm" data-act='{"a":"unban","ip":"${esc(ip)}"}'>unban</button></span> `).join('')}</div>`:''}`;
}
const FN={
  stSave(){if(!ST.item)return;const L=Object.assign({},ST.draft);if(!L.muzzle)delete L.muzzle;C.store.items[ST.item].look=L;dirty();toast('Skin updated. Press Save & Publish to release it.');},
  stNew(){const n=prompt('Name for the new weapon skin?','Custom Mythic');if(!n)return;const id='ws_custom_'+Date.now().toString(36).slice(-5),L=Object.assign({},ST.draft);if(!L.muzzle)delete L.muzzle;C.store.items[id]={type:'wskin',name:n.slice(0,30),rarity:'mythic',coins:12000,naira:0,op:'any',weapon:ST.wid,slot:'neck',exclusive:false,featured:false,desc:'Made in the Gun Studio.',season:C.activeSeason,look:L};ST.item=id;dirty();studioR();toast('Created. Set its price in Store, then publish.');},
  newSeason(){const ids=Object.keys(C.seasons),id='s'+(ids.length+1+Math.floor(Math.random()*90));const b=JSON.parse(JSON.stringify(C.seasons[C.activeSeason]));b.id=id;b.name='New Season';b.short='SEASON '+(ids.length+1);b.presented='';b.artist={name:'',spotify:'',blurb:''};b.draw.pool=id;C.seasons[id]=b;render();dirty();},
  say:()=>act({a:'say',m:$('#say').value}),banner:()=>act({a:'banner',m:$('#ban').value}),fill:d=>act({a:'fill',code:d.code}),restartRoom:d=>act({a:'restart',code:d.code}),
  async ordAct(d){try{const j=await api('order','POST',{id:d.id,a:d.a});orders=j.orders;ordersR();nav();toast(d.a==='approve'?'Approved. Player credited.':'Rejected.');}catch(e){toast(e.message,true);}},
  async find(){try{profs=(await api('profiles?q='+encodeURIComponent($('#pq').value))).profiles;playersR(true);}catch(e){toast(e.message,true);}},
  async grant(d){const pid=d.pid,coins=+$('#gc-'+pid).value||0,item=$('#gi-'+pid).value;try{const j=await api('grant','POST',{pid,coins:coins||undefined,item:item||undefined,remove:d.rm==='1'});profs=j.profiles;playersR(true);toast('Account updated');}catch(e){toast(e.message,true);}},
  addItem(){const id=prompt('New item id (letters, numbers, underscore):','sk_new_'+Date.now().toString(36).slice(-4));if(!id||!/^[a-z0-9_]{2,30}$/i.test(id))return id&&toast('Bad id',true);const ty=prompt('Type: skin, wskin or bling','skin');if(!['skin','wskin','bling'].includes(ty))return;
    C.store.items[id]={type:ty,name:'New item',rarity:'rare',coins:800,naira:0,op:'any',weapon:'any',slot:'neck',exclusive:false,featured:false,desc:'',look:ty==='skin'?{primary:'#1b3b63',secondary:'#101c2e',accent:'#19e6ff',head:'',pattern:'solid'}:ty==='wskin'?{c1:'#0a8f3c',c2:'#ffffff',pattern:'stripes'}:{color:'#ffc933'}};render();dirty();},
  delItem(d){if(confirm('Delete this item? Players who own it keep it in their list but it disappears from the game.')){delete C.store.items[d.id];render();dirty();}},
  addPack(){C.store.coinPacks.push({id:'pack'+Date.now().toString(36).slice(-4),name:'New Pack',coins:1000,naira:1000,bonus:''});render();dirty();},
  delPack(d){C.store.coinPacks.splice(+d.i,1);render();dirty();},
  addRar(){const id=prompt('Rarity id (e.g. ultra)');if(!id||!/^[a-z0-9_]{2,20}$/i.test(id))return;C.store.rarities[id]={name:id,color:'#ffffff'};render();dirty();},
  addDay(){C.daily.rewards.push({type:'coins',amount:100,label:''});render();dirty();},delDay(d){C.daily.rewards.splice(+d.i,1);render();dirty();},
  resetStore(){if(confirm('Reset the store and daily rewards to the built-in defaults? Unsaved edits there are lost.'))api('reset','POST',{what:'store'}).then(j=>{C=JSON.parse(JSON.stringify(j.config));orig=JSON.stringify(C);render();toast('Store reset');}).catch(e=>toast(e.message,true));},
  addOp(){const id=prompt('New operator id (letters/numbers):','op'+Date.now().toString(36).slice(-3));if(!id||!/^[a-z0-9_]{2,16}$/i.test(id))return;C.classes[id]={name:'New Operator',title:'Soldier',desc:'Describe the operator.',hp:100,speed:1,primary:'rifle',ability:'dash',cd:8,dur:.3,color:'#19e6ff',locked:false,look:{sex:'m',skin:'#8a5a3b',primary:'#1b3b63',secondary:'#101c2e',accent:'#19e6ff',head:'',pattern:'solid'}};render();dirty();},
  delOp(d){if(Object.keys(C.classes).length<2)return toast('Keep at least one operator',true);if(confirm('Delete this operator?')){delete C.classes[d.id];render();dirty();}},
  addWeap(){const id=prompt('New weapon id:','gun'+Date.now().toString(36).slice(-3));if(!id||!/^[a-z0-9_]{2,16}$/i.test(id))return;C.weapons[id]={name:'New Gun',model:'rifle',damage:20,rpm:400,mag:20,reload:1.8,spread:2,range:700,pellets:1,auto:true,moveSpeed:1,lootWeight:.5,color:'#ffffff'};render();dirty();},
  delWeap(d){if(Object.keys(C.weapons).length<2)return;if(confirm('Delete this weapon?')){delete C.weapons[d.id];render();dirty();}},
  addMode(){const id=prompt('New mode id:','mode'+Date.now().toString(36).slice(-3));if(!id||!/^[a-z0-9_]{2,16}$/i.test(id))return;const t=prompt('Base type: tdm, ffa, zone, gungame or br','ffa');if(!['tdm','ffa','zone','gungame','br'].includes(t))return;C.modes[id]=Object.assign({},JSON.parse(JSON.stringify(Object.values(C.modes).find(m=>m.type===t)||{type:t})),{name:'New Mode'});render();dirty();},
  delMode(d){if(Object.keys(C.modes).length<2)return;if(confirm('Delete this mode?')){delete C.modes[d.id];render();dirty();}},
  resetAll(){if(confirm('Reset gameplay settings (weapons, operators, modes, match, brand) to defaults? Maps, store, music and code are kept.'))api('reset','POST',{what:'else'}).then(j=>{C=JSON.parse(JSON.stringify(j.config));orig=JSON.stringify(C);render();toast('Reset');}).catch(e=>toast(e.message,true));},
  async pin(){try{await api('pin','POST',{current:$('#pc').value,next:$('#pn').value});toast('PIN changed. Sign in again.');setTimeout(signOut,800);}catch(e){toast(e.message,true);}},
  async backup(){try{const r=await fetch('/api/dev/backup',{headers:{Authorization:'Bearer '+token}});const b=await r.blob(),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='vector-blackout-backup.json';a.click();}catch(e){toast(e.message,true);}},
  async restore(){const f=$('#rf').files[0];if(!f)return toast('Choose a backup file first',true);if(!confirm('Restore this backup? It replaces settings, accounts and orders.'))return;try{await api('restore','POST',JSON.parse(await f.text()));toast('Restored');boot();}catch(e){toast(e.message,true);}},
  bump(){C.custom.version=(+C.custom.version||0)+1;render();dirty();toast('Version bumped. Save & Publish to push it to players.');},
  async logoUp(){const f=$('#lf').files[0];if(!f)return toast('Choose a picture first',true);const img=new Image();img.src=URL.createObjectURL(f);await img.decode().catch(()=>{});
    try{for(const sz of [192,512]){const c=document.createElement('canvas');c.width=c.height=sz;const x=c.getContext('2d');x.fillStyle='#05080f';x.fillRect(0,0,sz,sz);const s=Math.min(sz/img.width,sz/img.height);x.drawImage(img,(sz-img.width*s)/2,(sz-img.height*s)/2,img.width*s,img.height*s);await api('logo','POST',{size:sz,data:c.toDataURL('image/png')});}toast('Logo updated. Players see it after they reinstall or refresh.');$('#lp').src='/icons/icon-512.png?'+Date.now();}catch(e){toast(e.message,true);}},
  async logoReset(){try{await api('logo','DELETE');toast('Default logo restored');$('#lp').src='/icons/icon-512.png?'+Date.now();}catch(e){toast(e.message,true);}},
  async musicUp(){const f=$('#mf').files[0];if(!f)return toast('Choose an audio file',true);const ext=f.name.split('.').pop();try{const r=await fetch('/api/dev/music?ext='+encodeURIComponent(ext)+'&name='+encodeURIComponent(f.name.replace(/\.[^.]+$/,'')),{method:'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/octet-stream'},body:f});const j=await r.json();if(!r.ok)throw new Error(j.error);C.music=j.config.music;orig=JSON.stringify(Object.assign(JSON.parse(orig),{music:C.music}));render();toast('Track added');}catch(e){toast(e.message,true);}},
  async musicDel(d){if(!confirm('Delete this track?'))return;try{const j=await api('music/'+d.id,'DELETE');C.music=j.config.music;orig=JSON.stringify(Object.assign(JSON.parse(orig),{music:C.music}));render();}catch(e){toast(e.message,true);}},
  rawApply(){try{C=JSON.parse($('#raw').value);render();dirty();toast('Loaded into the editor. Save & Publish to apply.');}catch(e){toast('Invalid JSON: '+e.message,true);}},
  /* maps */
  selMap(d){curMap=d.id;mapsR();},
  newMap(d){const w=+prompt('Width in tiles (24-80)','48'),h=+prompt('Height in tiles (16-50)','30');if(!w||!h)return;const id='map'+Date.now().toString(36).slice(-4);
    const rows=[];for(let y=0;y<h;y++){let r='';for(let x=0;x<w;x++)r+=(x===0||y===0||x===w-1||y===h-1)?'#':'.';rows.push(r);}
    const sp=(r,x,y,c)=>rows[y]=rows[y].slice(0,x)+c+rows[y].slice(x+1);for(let i=0;i<3;i++){sp(rows,3,Math.floor(h/2)-1+i,'A');sp(rows,w-4,Math.floor(h/2)-1+i,'B');}sp(rows,w>>1,h>>1,'Z');for(let i=0;i<4;i++)sp(rows,4+i*((w-8)/3|0),3,'F');
    C.maps[id]={id,name:'New Map',desc:'',rows,theme:'neon'};C.mapOrder.push(id);curMap=id;mapsR();dirty();},
  async genMap(){const world=confirm('OK = generate an open-world Battle Royale map.\nCancel = generate a normal arena map.');const o=world?{world:true,seed:Math.floor(Math.random()*1e6)}:{seed:Math.floor(Math.random()*1e6),w:+prompt('Width (24-80)','48'),h:+prompt('Height (16-50)','30'),buildings:+prompt('Buildings (0-60)','16'),crates:+prompt('Crates (0-60)','20'),water:+prompt('Water patches (0-10)','2'),tall:true};
    try{const j=await api('genmap','POST',o),id=(world?'world':'gen')+Date.now().toString(36).slice(-4);C.maps[id]={id,name:world?'New World':'Generated Map',desc:'',rows:j.rows,theme:world?'open':'neon',br:world};if(!world)C.mapOrder.push(id);curMap=id;mapsR();dirty();}catch(e){toast(e.message,true);}},
  dupMap(){const m=JSON.parse(JSON.stringify(C.maps[curMap])),id='map'+Date.now().toString(36).slice(-4);m.id=id;m.name+=' copy';C.maps[id]=m;if(!m.br)C.mapOrder.push(id);curMap=id;mapsR();dirty();},
  delMap(){const m=C.maps[curMap];const arenas=Object.values(C.maps).filter(x=>!x.br);if(!m.br&&arenas.length<2)return toast('Keep at least one arena map',true);if(!confirm('Delete this map?'))return;delete C.maps[curMap];C.mapOrder=C.mapOrder.filter(i=>i!==curMap);curMap=C.mapOrder[0]||Object.keys(C.maps)[0];mapsR();dirty();},
  mapUp(){moveMap(-1);},mapDown(){moveMap(1);},
  undo(){const s=undo.pop();if(s){C.maps[curMap].rows=JSON.parse(s);drawMap();dirty();}},
  addToRot(){if(!C.mapOrder.includes(curMap))C.mapOrder.push(curMap);mapsR();dirty();},rmFromRot(){C.mapOrder=C.mapOrder.filter(i=>i!==curMap);mapsR();dirty();},
  resetMaps(){if(confirm('Replace all maps with the built-in set?'))api('reset','POST',{what:'maps'}).then(j=>{C=JSON.parse(JSON.stringify(j.config));orig=JSON.stringify(C);curMap=C.mapOrder[0];render();});}
};
/* ===== ORDERS ===== */
function ordersR(){
  const el=$('#tabbody');if(!el||tab!=='orders')return;const list=orders.slice().sort((a,b)=>(a.status==='pending'?0:1)-(b.status==='pending'?0:1)||b.ts-a.ts);
  el.innerHTML=`<div class="card"><h3>Payment orders</h3><p class="muted">When a player sends money to your account (${esc(C.store.payment.bank)} ${esc(C.store.payment.account)}) and submits an order, it appears here. Check your bank app, then press Approve. Coins or items are delivered to the player instantly.</p>
  <table><tr><th>Order</th><th>Player</th><th>Name / phone</th><th>Item</th><th>Amount</th><th>Status</th><th></th></tr>${list.map(o=>`<tr><td><b>${esc(o.id)}</b><br><span class="muted">${new Date(o.ts).toLocaleString()}</span></td><td>${esc(o.pname)}</td><td>${esc(o.name)}<br>${esc(o.phone)}</td><td>${esc(o.label)}</td><td><b>₦${(+o.naira).toLocaleString()}</b></td><td class="${o.status}">${o.status}</td><td>${o.status==='pending'?`<button class="pri sm" data-fn="ordAct" data-id="${o.id}" data-a="approve">Approve</button> <button class="sm bad" data-fn="ordAct" data-id="${o.id}" data-a="reject">Reject</button>`:''}</td></tr>`).join('')||'<tr><td colspan="7" class="muted">No orders yet.</td></tr>'}</table></div>`;
}
/* ===== PLAYERS ===== */
function playersR(keep){
  const el=$('#tabbody'),q=keep?$('#pq').value:'';
  el.innerHTML=`<div class="card"><h3>Find a player</h3><div class="row"><input id="pq" placeholder="Name or account id" style="max-width:320px" value="${esc(q)}"><button data-fn="find">Search</button></div></div>`+
  profs.map(p=>`<div class="card"><div class="row"><h3>${esc(p.name)}</h3><span class="pill">${p.coins} coins</span><span class="pill">${p.owned.length} items</span><span class="muted">${esc(p.id)}</span></div>
  <div class="row" style="margin-top:8px"><input id="gc-${p.id}" type="number" placeholder="Coins (+/-)" style="max-width:150px"><select id="gi-${p.id}" style="max-width:260px"><option value="">Item…</option>${Object.entries(C.store.items).map(([id,i])=>`<option value="${id}">${esc(i.name)} (${id})</option>`).join('')}</select><button class="sm pri" data-fn="grant" data-pid="${p.id}">Grant / add</button><button class="sm bad" data-fn="grant" data-pid="${p.id}" data-rm="1">Remove item</button></div></div>`).join('');
}
/* ===== STORE ===== */
function itemLook(id,it){const k='store.items.'+id+'.look.';
  if(it.type==='skin')return F(k+'primary','Shirt','color')+F(k+'secondary','Trousers','color')+F(k+'accent','Accent','color')+F(k+'glow','Glow (optional)','color')+F(k+'head','Headgear','select',{opts:HEADS})+F(k+'pattern','Pattern','select',{opts:PATS});
  if(it.type==='wskin')return F(k+'c1','Main colour','color')+F(k+'c2','Second colour','color')+F(k+'glow','Glow','color')+F(k+'pattern','Pattern','select',{opts:WPATS})+F(k+'spd','Pattern speed','num')+F(k+'vel','Aura velocity','num');
  if(it.type==='bling')return F(k+'color','Colour','color')+F(k+'glow','Glow','color');return'';}
function storeR(){
  const st=C.store,el=$('#tabbody'),rar=Object.keys(st.rarities);
  el.innerHTML=`<div class="card"><h3>Payment account (where players send money)</h3><div class="grid">${F('store.payment.bank','Bank / app','text')}${F('store.payment.account','Account number','text')}${F('store.payment.accountName','Account name (shown to players)','text')}${F('store.payment.note','Instructions shown at checkout','area',{rows:2})}${F('store.featuredText','Banner text on Featured tab','text',{w:'w4'})}</div><p class="muted">Change the number here any time. It is used the moment you press Save &amp; Publish.</p></div>
  <div class="card"><h3>Rarities</h3><div class="grid">${rar.map(r=>F('store.rarities.'+r+'.name',r+' name')+F('store.rarities.'+r+'.color',r+' colour','color')).join('')}</div><button class="sm" data-fn="addRar" style="margin-top:8px">+ Add rarity</button></div>
  <div class="card"><h3>Coin packs (sold for naira)</h3>${st.coinPacks.map((p,i)=>`<div class="grid" style="margin-bottom:8px">${F('store.coinPacks.'+i+'.name','Name')}${F('store.coinPacks.'+i+'.coins','Coins','num')}${F('store.coinPacks.'+i+'.naira','Price ₦','num')}${F('store.coinPacks.'+i+'.bonus','Bonus label')}<button class="sm bad" data-fn="delPack" data-i="${i}" style="align-self:end">Remove</button></div>`).join('')}<button class="sm" data-fn="addPack">+ Add pack</button></div>
  <div class="card"><div class="row"><h3>Items</h3><button class="sm pri" data-fn="addItem">+ New item</button><button class="sm bad" data-fn="resetStore">Reset store to defaults</button></div><p class="muted">Coins price = buy with coins (0 = not for coins). Naira price = player pays by transfer (0 = not for naira). Exclusive items should have naira only.</p>
  ${Object.entries(st.items).map(([id,it])=>`<details class="item"><summary><span class="sw" style="background:${esc((st.rarities[it.rarity]||{}).color)}"></span><b>${esc(it.name)}</b><span class="muted">${esc(it.type)} · ${esc(id)}${it.exclusive?' · exclusive':''}</span></summary><div><div class="grid">
  ${F('store.items.'+id+'.name','Name')}${F('store.items.'+id+'.rarity','Rarity','select',{opts:rar})}${F('store.items.'+id+'.coins','Price in coins','num')}${F('store.items.'+id+'.naira','Price in naira ₦','num')}
  ${it.type==='skin'||it.type==='operator'?F('store.items.'+id+'.op','Operator (or any)','select',{opts:['any',...Object.keys(C.classes)]}):''}${it.type==='wskin'?F('store.items.'+id+'.weapon','Weapon (or any)','select',{opts:['any',...Object.keys(C.weapons)]}):''}${it.type==='bling'?F('store.items.'+id+'.slot','Slot','select',{opts:SLOTS}):''}
  ${F('store.items.'+id+'.exclusive','Exclusive','bool')}${F('store.items.'+id+'.featured','Featured','bool')}${F('store.items.'+id+'.desc','Description','text',{w:'w2',max:160})}${itemLook(id,it)}</div><button class="sm bad" data-fn="delItem" data-id="${id}" style="margin-top:8px">Delete item</button></div></details>`).join('')}</div>`;
}
/* ===== DAILY ===== */
function dailyR(){
  const rw=C.daily.rewards,items=Object.keys(C.store.items);
  $('#tabbody').innerHTML=`<div class="card"><h3>Daily rewards (${rw.length} days)</h3>${F('daily.title','Title')}<p class="muted">Players claim one reward per day (Lagos time) and move to the next. After the last day it starts again.</p>
  <table><tr><th>Day</th><th>Type</th><th>Coins / Item</th><th>Label</th><th></th></tr>${rw.map((r,i)=>`<tr><td>${i+1}</td><td><select data-p="daily.rewards.${i}.type" data-ty="str" data-rr="1"><option ${r.type==='coins'?'selected':''}>coins</option><option ${r.type==='item'?'selected':''}>item</option></select></td><td>${r.type==='item'?`<select data-p="daily.rewards.${i}.item" data-ty="str">${items.map(x=>`<option value="${x}" ${x===r.item?'selected':''}>${esc(C.store.items[x].name)}</option>`).join('')}</select>`:`<input type="number" data-p="daily.rewards.${i}.amount" data-ty="num" value="${r.amount||0}">`}</td><td><input data-p="daily.rewards.${i}.label" data-ty="str" value="${esc(r.label||'')}" maxlength="14"></td><td><button class="sm bad" data-fn="delDay" data-i="${i}">✕</button></td></tr>`).join('')}</table><button class="sm" data-fn="addDay" style="margin-top:8px">+ Add day</button></div>`;
  $$('select[data-rr]').forEach(s=>s.addEventListener('change',()=>{const i=s.dataset.p.split('.')[2],r=C.daily.rewards[i];if(r.type==='item'&&!r.item)r.item=items[0];if(r.type==='coins'&&r.amount==null)r.amount=100;render();}));
}
/* ===== OPERATORS / WEAPONS / MODES ===== */
function opsR(){
  $('#tabbody').innerHTML=`<div class="card"><div class="row"><h3>Operators (characters)</h3><button class="sm pri" data-fn="addOp">+ New operator</button></div></div>`+Object.entries(C.classes).map(([id,c])=>{const k='classes.'+id+'.';return`<details class="item"><summary><span class="sw" style="background:${esc(c.color)}"></span><b>${esc(c.name)}</b><span class="muted">${esc(c.title)} · ${esc(id)}${c.locked?' · locked (sold in store)':''}</span></summary><div><div class="grid">
  ${F(k+'name','Name')}${F(k+'title','Title')}${F(k+'desc','Description','text',{w:'w2'})}${F(k+'hp','Health','num')}${F(k+'speed','Speed multiplier','num')}${F(k+'primary','Starting weapon','select',{opts:Object.keys(C.weapons)})}${F(k+'ability','Ability','select',{opts:ABIL})}${F(k+'cd','Ability cooldown (s)','num')}${F(k+'dur','Ability duration (s)','num')}${F(k+'color','UI colour','color')}${F(k+'locked','Locked (must be bought)','bool')}
  ${F(k+'look.sex','Body','select',{opts:['m','f']})}${F(k+'look.skin','Skin tone','color')}${F(k+'look.primary','Shirt','color')}${F(k+'look.secondary','Trousers','color')}${F(k+'look.accent','Accent','color')}${F(k+'look.head','Headgear','select',{opts:HEADS})}${F(k+'look.pattern','Pattern','select',{opts:PATS})}</div>
  <button class="sm bad" data-fn="delOp" data-id="${id}" style="margin-top:8px">Delete operator</button></div></details>`;}).join('');
}
function weapR(){
  $('#tabbody').innerHTML=`<div class="card"><div class="row"><h3>Weapons</h3><button class="sm pri" data-fn="addWeap">+ New weapon</button></div><p class="muted">Model decides how the gun looks in 3D. Damage, speed and range decide how it plays.</p></div>`+Object.entries(C.weapons).map(([id,w])=>{const k='weapons.'+id+'.';return`<details class="item"><summary><span class="sw" style="background:${esc(w.color)}"></span><b>${esc(w.name)}</b><span class="muted">${esc(id)} · dmg ${w.damage} · ${w.rpm} rpm</span></summary><div><div class="grid">
  ${F(k+'name','Name')}${F(k+'model','3D model','select',{opts:MODELS})}${F(k+'color','Colour','color')}${F(k+'damage','Damage','num')}${F(k+'rpm','Fire rate (rpm)','num')}${F(k+'mag','Magazine','num')}${F(k+'reload','Reload (s)','num')}${F(k+'spread','Spread (deg)','num')}${F(k+'range','Range','num')}${F(k+'pellets','Pellets per shot','num')}${F(k+'moveSpeed','Move speed multiplier','num')}${F(k+'lootWeight','Loot chance weight','num')}${F(k+'auto','Automatic','bool')}</div>
  <button class="sm bad" data-fn="delWeap" data-id="${id}" style="margin-top:8px">Delete weapon</button></div></details>`;}).join('');
}
function modesR(){
  $('#tabbody').innerHTML=`<div class="card"><div class="row"><h3>Game modes</h3><button class="sm pri" data-fn="addMode">+ New mode</button></div><p class="muted">A new mode copies the settings of a base type (tdm, ffa, zone, gungame, br).</p></div>`+Object.entries(C.modes).map(([id,m])=>{const k='modes.'+id+'.';return`<details class="item"><summary><b>${esc(m.name)}</b><span class="muted">${esc(id)} · ${esc(m.type)}</span></summary><div><div class="grid">
  ${F(k+'name','Name')}${F(k+'icon','Short icon text')}${F(k+'desc','Description','text',{w:'w2'})}${F(k+'scoreLimit','Score limit','num')}${F(k+'timeLimit','Time limit (s)','num')}
  ${m.type==='zone'?F(k+'zoneRadius','Zone radius','num')+F(k+'zoneMove','Zone moves every (s)','num'):''}${m.type==='gungame'?F(k+'ladder','Weapon ladder (ids, comma separated)','csv',{w:'w4'}).replace('data-ty="csv"','data-ty="strs"'):''}
  ${m.type==='br'?F(k+'radii','Circle radii per phase (px)','csv',{w:'w4'})+F(k+'wait','Wait before closing (s)','csv',{w:'w2'})+F(k+'shrink','Shrink time (s)','csv',{w:'w2'})+F(k+'dps','Storm damage per second','csv',{w:'w2'})+F(k+'startWeapon','Start weapon','select',{opts:Object.keys(C.weapons)})+F(k+'hpMul','Health multiplier','num')+F(k+'minBots','Fill with bots up to','num'):''}</div>
  <button class="sm bad" data-fn="delMode" data-id="${id}" style="margin-top:8px">Delete mode</button></div></details>`;}).join('');
}
/* ===== MAPS ===== */
function moveMap(d){const i=C.mapOrder.indexOf(curMap),j=i+d;if(i<0||j<0||j>=C.mapOrder.length)return;[C.mapOrder[i],C.mapOrder[j]]=[C.mapOrder[j],C.mapOrder[i]];mapsR();dirty();}
function mapsR(){
  const ids=Object.keys(C.maps);
  $('#tabbody').innerHTML=`<div class="card"><h3>Maps</h3><div class="row">${ids.map(id=>`<button data-fn="selMap" data-id="${id}" class="${id===curMap?'on':''}">${esc(C.maps[id].name)}${C.maps[id].br?' (BR)':''}</button>`).join('')}</div>
  <div class="row" style="margin-top:10px"><button class="pri sm" data-fn="newMap">+ Blank map</button><button class="sm" data-fn="genMap">+ Generate</button><button class="sm" data-fn="dupMap">Duplicate</button><button class="sm bad" data-fn="delMap">Delete</button><button class="sm bad" data-fn="resetMaps">Reset all maps</button></div>
  <p class="muted">Arena maps rotate in the order shown: ${C.mapOrder.map(i=>esc((C.maps[i]||{}).name)).join(' → ')}. Battle Royale uses the open-world map.</p></div><div class="card" id="mapcard"></div>`;mapEd();
}
function mapEd(){
  const m=C.maps[curMap];if(!m){$('#mapcard').innerHTML='';return;}const w=m.rows[0].length,h=m.rows.length,inRot=C.mapOrder.includes(curMap);
  $('#mapcard').innerHTML=`<div class="grid" style="margin-bottom:10px">${F('maps.'+curMap+'.name','Name')}${F('maps.'+curMap+'.theme','Look (theme)','select',{opts:THEMES})}${F('maps.'+curMap+'.desc','Description','text',{w:'w2'})}${F('maps.'+curMap+'.br','Battle Royale world','bool')}</div>
  <div class="row" style="margin-bottom:8px"><div class="pal">${TILES.map(([c,n,col])=>`<button data-fn="tool" data-c="${c}" class="${c===tool?'on':''}"><i style="background:${col}"></i>${n}</button>`).join('')}</div></div>
  <div class="row" style="margin-bottom:8px"><label class="row"><input type="checkbox" id="mirror" ${mirror?'checked':''}> Mirror left ↔ right</label><button class="sm" data-fn="undo">Undo</button>${m.br?'':inRot?'<button class="sm" data-fn="mapUp">Earlier in rotation</button><button class="sm" data-fn="mapDown">Later</button><button class="sm" data-fn="rmFromRot">Remove from rotation</button>':'<button class="sm" data-fn="addToRot">Add to rotation</button>'}<span class="muted">${w}×${h} tiles</span></div>
  <div id="mapwrap"><canvas id="mapcv" width="${w*CELL}" height="${h*CELL}"></canvas></div>
  <p class="muted">Paint with the mouse or your finger. Edge tiles must stay walls. A/B = team spawns, F = free-for-all spawns, Z = zone points. # blocks movement and sight; x blocks movement only; X is a tall container (or a tree on the open theme); ~ is water.</p>`;drawMap();
}
FN.tool=d=>{tool=d.c;$$('[data-fn=tool]').forEach(b=>b.classList.toggle('on',b.dataset.c===tool));};
function drawMap(){const cv=$('#mapcv');if(!cv)return;const m=C.maps[curMap],x=cv.getContext('2d'),w=m.rows[0].length,h=m.rows.length,col=Object.fromEntries(TILES.map(t=>[t[0],t[2]]));
  x.fillStyle='#04070d';x.fillRect(0,0,cv.width,cv.height);
  for(let ty=0;ty<h;ty++)for(let tx=0;tx<w;tx++){const c=m.rows[ty][tx];x.fillStyle=col[c]||'#f0f';x.fillRect(tx*CELL,ty*CELL,CELL,CELL);
    if(c==='.'){x.strokeStyle='#1d3566';x.strokeRect(tx*CELL+.5,ty*CELL+.5,CELL-1,CELL-1);}else if('ABFZhawc'.includes(c)){x.fillStyle='#04101a';x.font='700 10px sans-serif';x.textAlign='center';x.textBaseline='middle';x.fillText(c,tx*CELL+CELL/2,ty*CELL+CELL/2+1);}}
  x.strokeStyle='#19e6ff55';x.beginPath();x.moveTo(w/2*CELL,0);x.lineTo(w/2*CELL,h*CELL);x.stroke();}
function paint(ev){const cv=$('#mapcv'),r=cv.getBoundingClientRect(),m=C.maps[curMap],w=m.rows[0].length,h=m.rows.length;
  const tx=Math.floor((ev.clientX-r.left)/r.width*w),ty=Math.floor((ev.clientY-r.top)/r.height*h);if(tx<0||ty<0||tx>=w||ty>=h)return;
  const put=(x,y,c)=>{if(x<0||y<0||x>=w||y>=h)return;const border=x===0||y===0||x===w-1||y===h-1;if(border&&c!=='#')return;const row=m.rows[y];if(row[x]===c)return;m.rows[y]=row.slice(0,x)+c+row.slice(x+1);};
  put(tx,ty,tool);if(mirror&&!m.br){const mx=w-1-tx;put(mx,ty,tool==='A'?'B':tool==='B'?'A':tool);}drawMap();dirty();}
document.addEventListener('pointerdown',e=>{if(e.target.id==='mapcv'){undo.push(JSON.stringify(C.maps[curMap].rows));if(undo.length>40)undo.shift();painting=true;e.target.setPointerCapture(e.pointerId);paint(e);}});
document.addEventListener('pointermove',e=>{if(painting&&e.target.id==='mapcv')paint(e);});document.addEventListener('pointerup',()=>painting=false);
document.addEventListener('change',e=>{if(e.target.id==='mirror')mirror=e.target.checked;if(e.target.dataset&&e.target.dataset.p&&/\.theme$|\.br$/.test(e.target.dataset.p)&&tab==='maps')mapsR();});
/* ===== BRAND / APP / MATCH ===== */
function brandR(){$('#tabbody').innerHTML=`<div class="card"><h3>Branding</h3><div class="grid">${F('brand.title','Game title')}${F('brand.studio','Studio name')}${F('brand.year','Year')}${F('brand.tagline','Tagline','text',{w:'w2'})}${F('brand.motd','Message of the day (hub)','text',{w:'w2'})}${F('brand.accent','Main colour','color')}${F('brand.accent2','Second colour','color')}${F('brand.teamA','Team A name')}${F('brand.teamB','Team B name')}${F('brand.currency','Currency name')}${F('brand.rules','How to play text','area')}</div></div>`;}
function appR(){$('#tabbody').innerHTML=`<div class="card"><h3>App name & colour</h3><div class="grid">${F('app.name','App name (under the icon)')}${F('app.short','Short name (max 14)')}${F('app.theme','Browser bar colour','color')}</div></div>
  <div class="card"><h3>App logo (what shows when installed)</h3><div class="row"><img id="lp" src="/icons/icon-512.png?${Date.now()}" width="120" height="120" style="border-radius:22px;border:1px solid var(--ln)"><div><p class="muted">Upload a square PNG or JPG (at least 512×512). It is resized for you. Players who installed the app see the new logo after they reinstall.</p><input type="file" id="lf" accept="image/*"><div class="row" style="margin-top:8px"><button class="pri sm" data-fn="logoUp">Upload logo</button><button class="sm" data-fn="logoReset">Restore default logo</button></div></div></div></div>`;}
function matchR(){$('#tabbody').innerHTML=`<div class="card"><h3>Match</h3><div class="grid">${F('match.countdown','Countdown (s)','num')}${F('match.endScreen','End screen (s)','num')}${F('match.maxPlayers','Max players per room','num')}${F('match.botFill','Bots to fill with','num')}${F('match.spawnProtect','Spawn protection (s)','num')}${F('match.pickupRespawn','Pickup respawn (s)','num')}${F('match.pickupHeal','Health pickup','num')}${F('match.pickupArmor','Armor pickup','num')}</div></div>
  <div class="card"><h3>Bot difficulty (fairness)</h3><p class="muted">Skill 0 to 1: higher bots react faster and aim better. Damage multiplier scales how hard they hit.</p><div class="grid">${Object.keys(C.match.difficulty).map(k=>F('match.difficulty.'+k+'.name',k+' name')+F('match.difficulty.'+k+'.skill',k+' skill','num')+F('match.difficulty.'+k+'.dmg',k+' damage x','num')).join('')}</div></div>
  <div class="card"><h3>Rewards (coins)</h3><div class="grid">${['participate','perKill','win','perMinute','xpPerKill','xpWin','xpParticipate','practiceMul','botMatchMul','cap'].map(k=>F('match.reward.'+k,k,'num')).join('')}${F('match.reward.brPlace','Battle Royale placement coins','csv',{w:'w2'})}</div></div>
  <div class="card"><h3>Player</h3><div class="grid">${['hp','armorMax','speed','radius','respawn','dashSpeed','vision','hearing','armorAbsorb'].map(k=>F('player.'+k,k,'num')).join('')}</div></div>
  <div class="card"><h3>Touch control defaults</h3><div class="grid">${F('controls.aimAssist','Aim assist (0-1)','num')}${F('controls.fireSize','FIRE button size (px)','num')}${F('controls.defaultAutoFire','Auto-fire on by default','bool')}</div><p class="muted">Players can change all of these in their own Settings.</p></div>
  <button class="sm bad" data-fn="resetAll">Reset gameplay to defaults</button>`;}
/* ===== CODE ===== */
function codeR(){$('#tabbody').innerHTML=`<div class="card"><h3>Custom CSS (applies instantly to every player)</h3><p class="muted">Change how the menus look. Example: <code>.btn{border-radius:12px}</code></p>${F('custom.css','','area',{rows:10})}</div>
  <div class="card"><h3>Custom JavaScript (update the game)</h3><p class="muted">Runs once for each player when they load the game, with access to <code>G</code>, <code>UI</code>, <code>R3</code>, <code>AUD</code>. Raise the version number to ask players already in the game to reload. A mistake here can break the game for everyone, so keep a backup and test on your own phone first (Save &amp; Publish, then reload).</p>${F('custom.js','','area',{rows:12})}
  <div class="grid">${F('custom.version','Update version','num')}${F('custom.notice','Note to players (optional)')}</div><div class="row" style="margin-top:8px"><button class="sm" data-fn="bump">Bump version</button><button class="sm" data-act='{"a":"reload","confirm":"Force every connected player to reload now?"}'>Force reload everyone now</button></div></div>`;}
/* ===== MUSIC ===== */
function musicR(){$('#tabbody').innerHTML=`<div class="card"><h3>Music</h3><div class="grid">${F('music.useSynth','Use built-in synth music when no tracks','bool')}${F('music.volume','Music volume (0-1)','num')}</div>
  <table style="margin-top:10px"><tr><th>Track</th><th>Plays in</th><th></th></tr>${(C.music.tracks||[]).map((t,i)=>`<tr><td>${esc(t.name)}</td><td><select data-p="music.tracks.${i}.where" data-ty="str">${['both','menu','match'].map(w=>`<option ${w===t.where?'selected':''}>${w}</option>`).join('')}</select></td><td><button class="sm bad" data-fn="musicDel" data-id="${t.id}">Delete</button></td></tr>`).join('')||'<tr><td colspan="3" class="muted">No uploaded tracks.</td></tr>'}</table>
  <div class="row" style="margin-top:10px"><input type="file" id="mf" accept="audio/*"><button class="pri sm" data-fn="musicUp">Upload track</button></div></div>`;}
/* ===== SECURITY / RAW ===== */
function secR(){$('#tabbody').innerHTML=`<div class="card"><h3>Change developer PIN</h3><div class="grid">${'<label class="f">Current PIN<input id="pc" type="password"></label><label class="f">New PIN (4-32 characters)<input id="pn" type="password"></label>'}</div><button class="pri sm" data-fn="pin" style="margin-top:8px">Change PIN</button></div>
  <div class="card"><h3>Backup & restore</h3><p class="muted">The backup contains your settings, all player accounts and orders. Download one regularly, especially if your host has no permanent disk.</p><div class="row"><button class="pri sm" data-fn="backup">Download backup</button><input type="file" id="rf" accept=".json"><button class="sm bad" data-fn="restore">Restore from file</button></div></div>`;}
function rawR(){$('#tabbody').innerHTML=`<div class="card"><h3>Raw settings (advanced)</h3><textarea id="raw" rows="24" style="min-height:420px">${esc(JSON.stringify(C,null,1))}</textarea><button class="sm pri" data-fn="rawApply" style="margin-top:8px">Load into editor</button></div>`;}
/* ===== HAVOC: GUN DESIGN STUDIO, SEASON MANAGER, ANALYTICS ===== */
const WPATS=[...PATS,'damascus','diamond','aurora','wave','vinyl'];
const ST={wid:'rifle',item:'',draft:{c1:'#070a1c',c2:'#19e6ff',glow:'#19e6ff',pattern:'aurora',spd:1,vel:1,wob:0,crystals:true,aura:true,muzzle:'brake',trail:'#19e6ff'},raf:0,rot:.6,drag:null,three:null};
const rg=(label,attr,val,min,max,step,fmt)=>`<label class="f"><span style="display:flex;justify-content:space-between">${label}<b class="rv">${fmt?fmt(val):val}</b></span><input type="range" min="${min}" max="${max}" step="${step}" value="${val}" ${attr}></label>`;
function F2(key,label,type,val){return `<label class="f">${label}<input type="${type}" data-d="${key}" data-dt="str" value="${esc(val)}"></label>`;}
function studioR(){
  const ws=Object.keys(C.weapons),skins=Object.entries(C.store.items).filter(([,i])=>i.type==='wskin');
  if(!C.weapons[ST.wid])ST.wid=ws[0];const w=C.weapons[ST.wid],k=n=>`data-p="weapons.${ST.wid}.${n}" data-ty="num"`,d=ST.draft,dd=n=>`data-d="${n}" data-dt="num"`;
  const dps=Math.round(w.damage*(w.pellets||1)*w.rpm/60);
  $('#tabbody').innerHTML=`<div id="studio" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px;align-items:start">
  <div class="card" style="position:sticky;top:110px"><div class="row"><h3>Live preview</h3><span class="muted">drag to rotate · changes show instantly</span></div>
    <canvas id="stc" style="width:100%;height:340px;border-radius:8px;background:#0a1020;touch-action:none;cursor:grab"></canvas>
    <div class="row" style="margin-top:8px"><span class="pill">${dps} DPS</span><span class="pill">${w.mag} rounds · ${w.reload}s reload</span><span class="pill">${w.rpm} rpm</span><span class="pill">${Math.round(w.damage*w.mag*(w.pellets||1))} dmg / mag</span></div></div>
  <div>
  <div class="card"><h3>Weapon</h3><div class="grid"><label class="f w2">Weapon<select id="stw">${ws.map(i=>`<option value="${i}" ${i===ST.wid?'selected':''}>${esc(C.weapons[i].name)}</option>`).join('')}</select></label></div>
   <div class="grid" style="margin-top:8px">${rg('Model scale',k('scale'),w.scale||1,.5,2,.05,v=>(+v).toFixed(2)+'x')}${rg('Damage',k('damage'),w.damage,1,250,1)}${rg('Fire rate (rpm)',k('rpm'),w.rpm,20,1200,5)}${rg('Magazine',k('mag'),w.mag,1,120,1)}${rg('Reload (s)',k('reload'),w.reload,.3,6,.1)}${rg('Spread (deg)',k('spread'),w.spread,0,14,.1)}${rg('Range',k('range'),w.range,150,2000,10)}</div>
   <p class="muted">These edit the real weapon. Press <b>Save &amp; Publish</b> at the top to push damage, rate and scale to every player.</p></div>
  <div class="card"><h3>Skin / shader</h3><div class="grid"><label class="f w2">Load an existing weapon skin<select id="sti"><option value="">(draft)</option>${skins.map(([id,it])=>`<option value="${id}" ${id===ST.item?'selected':''}>${esc(it.name)} · ${esc(it.rarity)}</option>`).join('')}</select></label>
   ${F2('c1','Main colour','color',d.c1)}${F2('c2','Second colour','color',d.c2)}${F2('glow','Glow colour','color',d.glow||'#19e6ff')}${F2('trail','Aura / trail colour','color',d.trail||d.glow||'#19e6ff')}
   <label class="f w2">Animated pattern<select data-d="pattern" data-dt="str">${WPATS.map(p=>`<option ${p===d.pattern?'selected':''}>${p}</option>`).join('')}</select></label>
   <label class="f w2">Muzzle brake<select data-d="muzzle" data-dt="str"><option value="" ${!d.muzzle?'selected':''}>none</option><option value="brake" ${d.muzzle==='brake'?'selected':''}>glowing brake</option></select></label>
   ${rg('Pattern speed',dd('spd'),d.spd||1,.1,4,.1,v=>(+v).toFixed(1)+'x')}${rg('Aura velocity',dd('vel'),d.vel||1,.1,4,.1,v=>(+v).toFixed(1)+'x')}${rg('Vertex ripple (shader)',dd('wob'),d.wob||0,0,.02,.001,v=>(+v*1000).toFixed(0))}
   <label class="f">Crystal shards<input type="checkbox" data-d="crystals" data-dt="bool" ${d.crystals?'checked':''}></label><label class="f">Aura particles<input type="checkbox" data-d="aura" data-dt="bool" ${d.aura?'checked':''}></label></div>
   <div class="row" style="margin-top:10px"><button class="pri" data-fn="stSave" ${ST.item?'':'disabled'}>Save to this skin</button><button data-fn="stNew">Save as new weapon skin</button></div>
   <p class="muted">Shader patterns (damascus, diamond, aurora, wave, vinyl) run live on the GPU. Saving writes the look to the store item; publish to release it.</p></div></div></div>`;
  studioInit();
}
function studioInit(){
  const cv=$('#stc');if(!cv||typeof THREE==='undefined'||typeof MD==='undefined'){if(cv)cv.insertAdjacentHTML('afterend','<p style="color:var(--rd)">3D preview unavailable (Three.js did not load).</p>');return;}
  cancelAnimationFrame(ST.raf);if(ST.three){try{ST.three.r.dispose();}catch(e){}}
  const T=THREE,r=new T.WebGLRenderer({canvas:cv,antialias:true});r.setPixelRatio(Math.min(2,devicePixelRatio||1));r.setSize(cv.clientWidth||560,cv.clientHeight||340,false);r.outputColorSpace=T.SRGBColorSpace;r.toneMapping=T.ACESFilmicToneMapping;
  const sc=new T.Scene();sc.background=new T.Color('#0a1020');sc.add(new T.HemisphereLight('#bcd0ff','#3a2a50',1.9));const dl=new T.DirectionalLight('#fff',2.4);dl.position.set(-1,2,2);sc.add(dl);const bl=new T.PointLight('#19e6ff',2.2,6);bl.position.set(1.2,.3,-1);sc.add(bl);
  const grid=new T.GridHelper(4,28,0x19e6ff,0x1d2c52);grid.position.y=-.28;sc.add(grid);
  const cam=new T.PerspectiveCamera(34,(cv.clientWidth||560)/(cv.clientHeight||340),.05,40);cam.position.set(0,.18,1.7);cam.lookAt(0,0,0);
  const pivot=new T.Group();sc.add(pivot);ST.three={r,sc,cam,pivot,gun:null,fx:null,t0:performance.now()/1000,last:0};
  cv.onpointerdown=e=>{ST.drag={x:e.clientX,r:ST.rot};cv.setPointerCapture(e.pointerId);cv.style.cursor='grabbing';};cv.onpointermove=e=>{if(ST.drag)ST.rot=ST.drag.r+(e.clientX-ST.drag.x)*.01;};cv.onpointerup=()=>{ST.drag=null;cv.style.cursor='grab';};
  studioBuild();
  const loop=()=>{if(tab!=='studio'||!$('#stc')||$('#stc')!==cv){r.dispose();ST.three=null;return;}ST.raf=requestAnimationFrame(loop);const t=performance.now()/1000-ST.three.t0,dt=Math.min(.05,t-ST.three.last);ST.three.last=t;
    MD.uTime.value=t;if(ST.three.fx)ST.three.fx.update(t,dt);if(!ST.drag)ST.rot+=dt*.5;pivot.rotation.y=ST.rot;
    const w=Math.max(1,cv.clientWidth),h=Math.max(1,cv.clientHeight);if(cv.width!==Math.round(w*r.getPixelRatio())){r.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();}r.render(sc,cam);};
  loop();
}
function studioBuild(){
  const S3=ST.three;if(!S3)return;const w=C.weapons[ST.wid];if(!w)return;
  if(S3.gun){S3.pivot.remove(S3.gun);S3.gun.traverse(o=>{if(o.geometry)o.geometry.dispose();});}
  const sk=Object.assign({},ST.draft);if(!sk.muzzle)delete sk.muzzle;
  const bg=MD.buildGun(w.model||ST.wid,w.color,sk),sca=w.scale||1,hold=new THREE.Group();bg.g.scale.setScalar(sca);bg.g.position.x=-(bg.spec.len*.5)*sca;hold.add(bg.g);S3.pivot.add(hold);S3.gun=hold;S3.fx=bg.fx;
}
function studioLoadItem(id){
  ST.item=id;if(!id)return;const L=C.store.items[id].look||{};
  ST.draft={c1:L.c1||'#2a2f3a',c2:L.c2||'#19e6ff',glow:L.glow||'',pattern:L.pattern||'solid',spd:L.spd||1,vel:L.vel||1,wob:L.wob||0,crystals:!!L.crystals,aura:!!L.aura,muzzle:L.muzzle||'',trail:L.trail||L.glow||'#19e6ff'};
  const wp=C.store.items[id].weapon;if(wp&&wp!=='any'&&C.weapons[wp])ST.wid=wp;
}
document.addEventListener('input',e=>{const t=e.target;if(tab!=='studio'||!t.closest||!t.closest('#studio'))return;
  const rv=t.parentElement&&t.parentElement.querySelector('.rv');
  if(t.dataset.d){const v=t.dataset.dt==='num'?+t.value:t.dataset.dt==='bool'?t.checked:t.value;ST.draft[t.dataset.d]=v;
    if(rv){rv.textContent=t.dataset.d==='wob'?(v*1000).toFixed(0):(+v).toFixed(1)+'x';}studioBuild();}
  else if(t.dataset.p){if(rv)rv.textContent=t.dataset.p.endsWith('.scale')?(+t.value).toFixed(2)+'x':t.value;studioBuild();const w=C.weapons[ST.wid];const pills=$$('.pill',$('#studio'));if(pills.length>=4){pills[0].textContent=Math.round(w.damage*(w.pellets||1)*w.rpm/60)+' DPS';pills[1].textContent=w.mag+' rounds · '+w.reload+'s reload';pills[2].textContent=w.rpm+' rpm';pills[3].textContent=Math.round(w.damage*w.mag*(w.pellets||1))+' dmg / mag';}}});
document.addEventListener('change',e=>{const t=e.target;if(tab!=='studio')return;if(t.id==='stw'){ST.wid=t.value;studioR();}else if(t.id==='sti'){studioLoadItem(t.value);studioR();}});
/* ---- season manager ---- */
function seasonR(){
  const ids=Object.keys(C.seasons),al=C.lucky.odds;
  $('#tabbody').innerHTML=`<div class="card"><div class="row"><h3>Seasons</h3><label class="row">Active season <select data-p="activeSeason" data-ty="str" data-rr="1">${ids.map(i=>`<option value="${i}" ${i===C.activeSeason?'selected':''}>${esc(C.seasons[i].name)}</option>`).join('')}</select></label><button class="sm pri" data-fn="newSeason">+ New season</button></div>
  <p class="muted">The active season sets the lobby background, the season pass, the lucky draw and the artist banner. Lobby themes: neon (Neon Horizon), rust (Rust &amp; Dust), tokyo (Tokyo Escape).</p></div>`+
  ids.map(id=>{const s=C.seasons[id],k='seasons.'+id+'.';return `<details class="item" ${id===C.activeSeason?'open':''}><summary><b>${esc(s.name)}</b><span class="muted">${id}${id===C.activeSeason?' · ACTIVE':''}${s.presented?' · presented by '+esc(s.presented):''}</span></summary><div><div class="grid">
   ${F(k+'name','Season name')}${F(k+'short','Short label')}${F(k+'theme','Lobby theme','select',{opts:['neon','rust','tokyo']})}${F(k+'presented','Presented by (artist / sponsor)')}${F(k+'tagline','Tagline','text',{w:'w4'})}
   ${F(k+'artist.name','Artist name')}${F(k+'artist.spotify','Spotify / artist link','text',{w:'w2'})}${F(k+'artist.blurb','Artist blurb','text',{w:'w4'})}
   ${F(k+'pass.premiumNaira','Premium pass price (naira)','num')}${F(k+'pass.xpPerTier','XP per tier','num')}${F(k+'draw.cost','Lucky draw x1 (coins)','num')}${F(k+'draw.cost10','Lucky draw x10 (coins)','num')}</div>
   <p class="muted">Season items: ${Object.entries(C.store.items).filter(([,i])=>i.season===id).map(([iid,i])=>esc(i.name)+' ('+esc(i.rarity)+')').join(', ')||'none yet. Give store items a season id to put them in this season\'s draw pool.'}</p></div></details>`;}).join('')+
  `<div class="card"><h3>Lucky draw odds (shown to players)</h3><div class="grid">${Object.keys(al).map(r=>F('lucky.odds.'+r,r+' %','num')).join('')}${F('lucky.pity.mythic','Guaranteed mythic every N draws','num')}${F('lucky.pity.legendary','Guaranteed legendary every N draws','num')}${F('lucky.dupRefund','Duplicate refund (0-1)','num')}</div>
  <p class="muted">The draw pays out coins-only items. Odds are published to players in the game, and the pity counters are enforced by the server.</p></div>`;
}
/* ---- analytics ---- */
const AN={t:[],on:[],rtt:[],fps:[]};
function anPush(){if(!S||!S.rooms)return;const pl=S.rooms.flatMap(r=>r.players.filter(p=>!p.bot));const avg=a=>a.length?Math.round(a.reduce((x,y)=>x+y,0)/a.length):0;
  AN.t.push(Date.now());AN.on.push(S.online);AN.rtt.push(avg(pl.map(p=>p.rtt||0).filter(Boolean)));AN.fps.push(avg(pl.map(p=>p.fps||0).filter(Boolean)));for(const k in AN)if(AN[k].length>60)AN[k].shift();}
function spark(id,arr,col,unit){const c=$('#'+id);if(!c)return;const x=c.getContext('2d'),w=c.width,h=c.height;x.clearRect(0,0,w,h);const mx=Math.max(1,...arr);x.strokeStyle=col;x.lineWidth=2;x.beginPath();arr.forEach((v,i)=>{const px=arr.length>1?i/(arr.length-1)*w:0,py=h-4-(v/mx)*(h-14);i?x.lineTo(px,py):x.moveTo(px,py);});x.stroke();x.fillStyle='#8a9bb8';x.font='12px system-ui';x.fillText('max '+mx+unit,6,12);}
const lagos=ts=>new Date(ts).toLocaleString('en-GB',{timeZone:'Africa/Lagos',day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
function analyticsR(){
  if(!S||!$('#tabbody')||tab!=='analytics')return;
  const pl=S.rooms.flatMap(r=>r.players.filter(p=>!p.bot).map(p=>Object.assign({room:r.code,mode:r.mode},p)));const tx=S.tx||[];
  const naira=tx.filter(t=>t.type==='approved').reduce((a,t)=>a+(t.naira||0),0),pend=orders.filter(o=>o.status==='pending'),pendN=pend.reduce((a,o)=>a+(o.naira||0),0);
  const tm=new Date().toLocaleDateString('en-CA',{timeZone:'Africa/Lagos'}),today=tx.filter(t=>t.type==='approved'&&new Date(t.ts).toLocaleDateString('en-CA',{timeZone:'Africa/Lagos'})===tm).reduce((a,t)=>a+(t.naira||0),0);
  $('#tabbody').innerHTML=`<div class="card"><div class="row"><h3>Live analytics</h3><span class="muted">refreshes every few seconds · latency and FPS are measured from real players' devices</span></div>
  <div class="row" style="margin-top:8px"><span class="pill">${S.online} online</span><span class="pill">${S.rooms.length} rooms</span><span class="pill">${S.profiles} accounts</span><span class="pill approved">N${naira.toLocaleString()} approved (recent log)</span><span class="pill approved">N${today.toLocaleString()} today</span><span class="pill pending">${pend.length} pending · N${pendN.toLocaleString()}</span><span class="pill">uptime ${Math.round(S.uptime/60)} min</span></div>
  <div class="grid" style="margin-top:12px"><div><div class="muted">Players online</div><canvas id="sp1" width="320" height="70" style="width:100%"></canvas></div><div><div class="muted">Avg latency (ms)</div><canvas id="sp2" width="320" height="70" style="width:100%"></canvas></div><div><div class="muted">Avg client FPS</div><canvas id="sp3" width="320" height="70" style="width:100%"></canvas></div></div></div>
  <div class="card"><h3>Active player profiles</h3>${pl.length?`<table><tr><th>Player</th><th>Room</th><th>Mode</th><th>K/D</th><th>Latency</th><th>FPS</th><th>IP</th></tr>${pl.map(p=>`<tr><td>${esc(p.name)}</td><td>${esc(p.room)}</td><td>${esc(p.mode)}</td><td>${p.k}/${p.d}</td><td>${p.rtt||'-'} ms</td><td>${p.fps||'-'}</td><td class="muted">${esc(p.ip)}</td></tr>`).join('')}</table>`:'<p class="muted">Nobody is in a match right now.</p>'}</div>
  <div class="card"><h3>Transaction log</h3><p class="muted">Real orders only: a payment is logged as <b>order</b> when the player submits it and as <b>approved</b> when you approve it in Orders. Nothing is credited automatically.</p>
  ${tx.length?`<div style="max-height:420px;overflow:auto"><table><tr><th>Time (Lagos)</th><th>Type</th><th>Player</th><th>Detail</th><th>Naira</th><th>Coins</th></tr>${tx.map(t=>`<tr><td class="muted">${lagos(t.ts)}</td><td><span class="pill ${t.type==='approved'?'approved':t.type==='rejected'?'rejected':t.type==='order'?'pending':''}">${esc(t.type)}</span></td><td>${esc(t.name||'')}</td><td>${esc(t.detail||'')}</td><td>${t.naira?'N'+t.naira.toLocaleString():''}</td><td>${t.coins||''}</td></tr>`).join('')}</table></div>`:'<p class="muted">No transactions yet.</p>'}</div>`;
  spark('sp1',AN.on,'#19e6ff','');spark('sp2',AN.rtt,'#ffd60a',' ms');spark('sp3',AN.fps,'#8ff0c3','');
}

/* strs input type (comma separated strings) */
document.addEventListener('input',e=>{const t=e.target;if(t.dataset&&t.dataset.ty==='strs'){set(C,t.dataset.p,t.value.split(',').map(x=>x.trim()).filter(Boolean));dirty();}});
window.addEventListener('beforeunload',e=>{if(C&&dirty()){e.preventDefault();e.returnValue='';}});
if(token)boot().catch(()=>{});
})();
